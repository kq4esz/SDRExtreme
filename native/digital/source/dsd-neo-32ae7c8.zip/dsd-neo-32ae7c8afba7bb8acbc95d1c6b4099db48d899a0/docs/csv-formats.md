# CSV Input Formats

DSD-neo uses small, purpose-built CSV importers for trunking helpers (channel maps, group lists), source ID
labels, and key lists. These parsers are intentionally minimal and **not** full RFC 4180 CSV parsers.

If you want known-good starting points, see `examples/` in the repository.

Group, source, key, and P25 band-plan CSVs consume each physical line in full. Lines over 998 content bytes
(excluding LF/CRLF) or containing NUL are skipped once, without interpreting their tails as extra rows.
The mapping importers (DMR TG-to-key and Vertex keystream) reject such data rows and retain the previous mapping.
Channel maps retain their support for longer rows with mode/key options; a NUL byte rejects the import.

## General Rules (Unless A Format Says Otherwise)

- The **first line is treated as a header and is ignored**. Keep the header line (it can be any text).
- Fields are split on literal commas (`,`). Quoting/escaping is **not supported**.
  - Do not include commas inside a field.
- Avoid blank lines and comment-only lines (they may be parsed as data).
- Extra columns after the required ones are ignored, except where a format names an optional column by header (such as
  a channel map's `name` or key columns). Use the rest for notes/labels.
- Imported text fields are copied into fixed-size runtime buffers. Keep short fields concise; long `mode` and `name`
  values are truncated in runtime display/policy state.

## Importing on Android

The Android app does not take CLI flags directly. Import CSVs through the UI instead: **Settings → Imported files**
manages the library (import, update, remove), and the add/edit-system wizard's **Trunking data** panel assigns a
channel map, talkgroup list, key file, P25 band plan, or source ID list (**Radio IDs**, kind `src`) to a system.
Files are picked with the system document picker and copied into app-private storage (`files/imports/`), so the
original can live anywhere (Downloads, Drive, …) and is not read again
after import — use "Update from file" to pull in a changed original. Each import is validated immediately and the row
shows how many entries loaded ("412 talkgroups · 3 rows skipped"); a file whose rows all fail to parse is flagged
"No usable rows". While a session is running, open the monitor's session menu and choose **Edit saved system**; saving
applies the files that changed to the live session immediately, including clearing a field to "None" — that unloads the
channel map, talkgroup list, keys, or source ID list from the running session. This action is available
only for a session this app instance started (after the Activity is recreated while the service kept running, there is no
saved-system row to write back to).

Applying a channel map **replaces** the live one rather than merging into it, so anything the decoder learned on the
air is discarded along with the previous file's entries; a grant for a channel the new file omits stays unresolved
until the site announces it again.

The library validates against the kind you picked, by content rather than by file name. A channel map and a decimal key
file share the same `number,number` grammar and the header line is free text, so what separates them is the frequency
column: picking a key list as a channel map reports "No usable rows". Two files of the same kind are still
indistinguishable — nothing stops one site's map being picked for another. A group list (`id,mode,name`) and a
source ID list (`id,name`) are not distinguishable by content either; the library validates against the kind you
picked, so select **Radio IDs** for a source ID list.

Programmatic validation uses the same dry-run parser: `dsd_csv_validate_*` in `<dsd-neo/core/csv_validate.h>` reports
accepted/skipped/total row counts without touching live decoder state.

### Generated imports

The RadioReference import (`docs/radioreference-import.md`) writes into the same library through the same validator,
and its files are ordinary CSVs in the formats below — nothing reads them differently. Two things distinguish them:

- **Their header line names its origin.** `DEC,Mode,Name,Category,(generated from RadioReference)` for a group list; a
  trunked channel map gets `ChannelNumber(dec),frequency(Hz) (generated from RadioReference; do not delete this
  line)`. A **conventional** channel map's header differs —
  `ChannelNumber(dec),frequency(Hz),name,(generated from RadioReference; do not delete this line)` — because its
  third field is exactly `name`, which is what opts every row into the channel map's optional name column (see
  below); a trunked map has no per-channel name to offer, so its header stays two-field and the note stays free
  text. Headers are required: group categories and conventional channel names opt in through named columns,
  while deleting the header causes the parser to consume the first data row as the header.
- **Their library row records provenance**, so the file can be re-fetched later. In
  `files/imported_files.json` those rows carry five extra keys beyond the ordinary
  `name`/`path`/`type`/`importedAt`/`accepted`/`skipped`: `origin` (`"radioreference"`), `rrSid` (the RadioReference
  system ID), `rrSiteIds` (every selected site's RadioReference `siteId`, comma-joined in selection order — a
  Conventional Networked import selects several repeaters, and the RF site *number* cannot be used because a system
  numbers several sites the same), `rrKind` (`"group"` or `"chan"`), and `rrPartialEnc` (the "treat partly encrypted
  as encrypted" answer the import was given). A picked file has none of them, and a row missing any of them loads
  with it defaulted.

## Channel Map CSV (`-C <file>` / `[trunking] chan_csv`)

Purpose: Map a trunking channel number to an RF frequency.

Required columns:

1. `channel_number` (`0 <= channel_number < 65535`), in any of three spellings:
   - decimal: `10822`
   - hex with a `0x` prefix: `0x2A46` (what the P25 event history prints as `Active Ch: 2A46`)
   - `<iden>-<chan>`: `2-2630` (identifier `0..15`, dash, decimal channel `0..4095`; the form DSDPlus uses and the
     one printed in parentheses after every P25 channel in this program's event history)
2. `frequency_hz` (integer Hz)

Optional column:

3. `name` (free text) - a label for the channel, shown while you listen to it.

Notes:

- `frequency_hz` is parsed as an integer (no `K/M/G` suffixes).
- `frequency_hz` must be between 100000 (100 kHz) and 2147483647 (about 2.147 GHz) on every platform — the highest
  frequency a trunk channel is stored and tuned at, far above any trunking band. A row outside it (including `0`) is
  skipped with a warning, and its slot in the LCN list below is left at 0 so later rows keep their LCN numbers. This is
  what tells a channel map apart from a decimal key list, which has the same `number,number` shape.
- Optional headers after the two required columns are matched case-insensitively, with surrounding whitespace
  trimmed: `name`, `mode`, `keys_hex_csv`, `keys_dec_csv`, `single_key_hex`, `single_key_dec`, and `options` (`relevant_CLI_switches`). They may appear in
  any order, including after column 16. Unrecognized columns are ignored. The first `name` column wins; duplicate
  `mode`, key, or `options` headers reject the file, including `options` repeated through its
  `relevant_CLI_switches` alias. This preserves legacy free-text note columns, including notes with commas.
- Channel-map headers and data rows are read in full up to 1 MiB (including the line ending and terminating NUL).
  Longer rows reject the import with an error; they are never split into additional channels.
- `mode` accepts `p25`, `dmr`, `nxdn96`, `nxdn48`, `dpmr`, `dstar`, `ysf`, `m17`, `nfm` (analog narrowband FM) and
  `am` (analog AM), case-insensitively and trimmed. Empty or missing values inherit the configured global decoder
  settings. Invalid nonempty values reject the import with file and row diagnostics, including on rows whose channel
  number is invalid; the diagnostic lists the accepted modes. There are no aliases: `fm`, `analog`, `wfm`, `nbfm` and
  `fm-conventional` are rejected with the hint `use nfm`.
- An `nfm` row runs the analog FM monitor (the `-fA` receive path) while it is on air, and an `am` row the AM monitor
  (the `-fM` receive path, its envelope detector), on a digital session too, and the scanner puts the configured
  decoder back when it moves on. Their activity is carrier, not a decoded frame: see [Analog rows](#analog-rows)
  below. Key columns (`keys_hex_csv`, `keys_dec_csv`, `single_key_hex`, `single_key_dec`) on an `nfm` or `am` row
  reject the import, since an analog row decrypts nothing.
- Under `-Y`, a declared mode selects its decoder class even when the global preset excludes it. P25 enables both
  phases and excludes DMR and X2-TDMA. Fully declared mixed lists work without `-fa`; untyped lists retain their
  existing behavior. The initial input uses global settings until the first scheduled row entry. Explicit global
  modulation locks remain effective. Manual `L` cycling and avoid/advance use the same row-entry rules and visit
  same-frequency rows with different metadata. Zero-frequency placeholders change neither the mode nor keys.
  An NXDN48 row needs only `mode=nxdn48`, not an outer `-fi` or a decoder switch in `options`. Audio keeps the
  startup output layout; mono voice is duplicated into both channels when that layout is stereo.
- Modes are stored by scan-list slot: duplicate channel numbers and repeated frequencies remain distinct rows.
  Trunk-scan target `type` is authoritative; `mode` values inside a target's `chan_csv` are validated and discarded.
- A `name` is trimmed of surrounding whitespace, capped at 63 bytes (never splitting a UTF-8 character), and must not
  contain a comma. It is stored per row of the LCN list below, so a row whose frequency was skipped keeps its name and
  the rest stay aligned. A row whose *channel number* does not parse is different: it takes no LCN slot at all, so it
  stores no name either.
- A row skipped for an unusable frequency keeps its name in the file's numbering but is never shown, because the
  scanner parks on the frequency it is already on rather than tuning such a row.
- Two optional columns carry per-row key files for the `-Y` scanner: `keys_hex_csv` (loaded like `-K`) and
  `keys_dec_csv` (loaded like `-k`). They opt in by header name at any column position past the frequency (like
  `name`, matched case-insensitively); a duplicated key header rejects the file. A row may fill both columns;
  they load into one per-row key set.
- Each key cell names a key file path, resolved relative to the channel map. Blank cells store nothing, and a row
  whose channel number does not parse takes no slot and stores nothing. A file-only key path on such a row is not
  opened. Paths cannot contain commas: the splitter does no quote handling.
- `single_key_dec` embeds the `-b` Motorola Basic Privacy key number directly in a row. It accepts unsigned decimal
  `0..255`. `single_key_hex` embeds the `-H` key: an optional leading `0x`, embedded ASCII whitespace, and exactly
  10, 32, or 64 hexadecimal digits are accepted. Both direct columns may be filled together. They are also matched
  case-insensitively at any position past the frequency.
- A row must choose one source family: any nonblank `single_key_dec`/`single_key_hex` value together with a nonblank
  `keys_dec_csv`/`keys_hex_csv` path rejects the import. This source conflict and direct-key syntax are validated even
  when the channel number does not parse, although that row still takes no slot. Blank direct cells are absent; an
  explicit decimal `0` or an all-zero hex key is present. A direct-key row installs a complete replacement key set,
  so scalar key families not supplied by that row and all file-backed keyring entries are cleared while it is active.
- Row keys take effect only under `-Y`: hopping onto a keyed row installs its set, hopping back onto an unkeyed
  row restores the global keys. Under plain trunking `-C` they are stored but never applied (one warning); under
  trunk-scan per-target `chan_csv` they are discarded, like `name`.
- Validation opens key files and validates direct values, so an unloadable path or malformed direct key fails the
  import. Diagnostics name the field but never repeat a direct key value. The Qt/Android picker flow supports direct
  values because they are embedded in the copied channel map; it does not copy companion per-row key files.
- Where a name shows: the end of the `-Y` conventional scanner's **Scan Mode** row, a `Channel:` line at the top of
  the Call Info panel, and as a prefix on the event history rows recorded while that channel is tuned. Encrypted
  traffic that reports no talkgroup still says which channel it was heard on. While a `--trunk-scan` target is on
  air its id is the label instead, and the Scan Mode row shows no name.
- Every column is positional, so an empty middle field is an empty frequency: `1,,851000000` is a row with no
  frequency and is skipped, not a channel at 851 MHz.
- **P25 keys.** A P25 channel is a 16-bit number: the 4-bit band-plan identifier in the top nibble and the 12-bit
  channel in the rest, `(iden << 12) | chan`. `2A46` hex, `2-2630`, and `10822` are the same channel. A row whose
  key is a valid spelling but cannot be a channel (`16-0`, `2-4096`, `15-4095` = the `65535` sentinel) is skipped
  like an unparsable one. Sites that broadcast their band plan (`IDEN_UP`) purge the map entries of a band the
  moment the plan arrives; a map is the workaround for sites that never do, and a [P25 band plan CSV](#p25-band-plan-csv---p25-bandplan-file--trunking-p25_bandplan_csv)
  replaces it with one row per identifier.
- For EDACS-style workflows, DSD-neo also records the `frequency_hz` values in **row order** as an LCN frequency list,
  so keep rows in the LCN order you want. An imported LCN list has no length limit; it is bounded only by memory.
  Site broadcasts never write into an imported list or shorten it - the list is positional, so a skipped row's 0
  holds that LCN's place. Frequencies learned from site broadcasts (with no list imported) are capped at 26.

Example:

```csv
ChannelNumber(dec),frequency(Hz),note
999,862093750,default cc
1,863093750
2,862093750
```

Example with names (`examples/conventional_scan_named.csv`):

```csv
channel,frequency_hz,name
1,462562500,GMRS 1
2,462587500,GMRS 2
```

Example with file-backed and direct per-row keys (`examples/conventional_scan_keyed.csv`):

```csv
channel,frequency_hz,name,keys_hex_csv,keys_dec_csv,single_key_dec,single_key_hex
1,462562500,System A,multi_key_hex.csv,,,
2,462587500,System B,,multi_key.csv,,
3,462612500,Shared,,,1,0000001F00
```

Example mixing analog AM, analog NFM and digital rows (`examples/conventional_scan_analog.csv` is a runnable copy;
`examples/conventional_scan_modes.csv` carries every mode):

```csv
channel,frequency_hz,name,mode,options
1,118300000,Tower AM 8.33 kHz,am,--am-bandwidth-hz 8333 --squelch-db -55
2,121500000,Guard AM default width,am,--squelch-db -60 --scan-max-visit-ms 30000
3,154430000,Fire dispatch NFM 12.5 kHz,nfm,--nfm-bandwidth-hz 12500 --squelch-db -60
4,155475000,Mutual aid NFM auto squelch,nfm,--squelch auto
5,461000000,DMR repeater,dmr,--scan-max-visit-ms 20000
6,851012500,P25 conventional,p25,--squelch-db -55
7,150000000,Inherit configured decoder,,
8,453212500,Public works NFM noise squelch,nfm,--nfm-bandwidth-hz 12500 --squelch noise+12
```

### Scoped row options

Channel maps and trunk-scan targets accept an optional `options` column. `relevant_CLI_switches` is an alias;
headers match case-insensitively and naming both rejects the file. Combine `mode` and `options` in the same map
(`examples/conventional_scan_options.csv`); run it with `-Y -C examples/conventional_scan_options.csv`.

Options are parsed once when the list is loaded. They are a restricted argument list, with the following switches:

| Switch | Meaning and accepted modes |
| --- | --- |
| `-b <decimal>` | Motorola BP number, `0..255`; DMR. |
| `-H <hex>` | Hytera/AES key; DMR accepts 10/32/64 digits, P25 32/64, NXDN 64. |
| `-1 <hex>` | Direct RC4/DES key, 1..16 digits; DMR/P25/NXDN. |
| `-R <decimal>` | Direct scrambler key, `0..32767`; NXDN/dPMR. |
| `-k <file>`, `-K <file>` | Decimal/hex key files; DMR/P25/NXDN. |
| `-G <file>` | Group names and policy for this row or system; digital modes (an analog row rejects it). |
| `-4` | Force loaded privacy keys over signalling; DMR/NXDN. |
| `-0`, `--dmr-force-algid <hex>` | DMR algorithm fallback when identifiers are missing. `-0` means ALGID `21`. |
| `-F` | Relax CRC checks; DMR/P25/M17. |
| `-^` | Prefer learned P25 control-channel candidates for this target; P25. Restores the configured default on target exit. |
| `--strict-crc` | Restore strict CRC checks; every digital mode, including inherited mode. |
| `--no-force-key` | Disable privacy forcing and algorithm fallback for this row; digital modes. |
| `-e`, `--no-data-calls` | Enable/disable data-call tuning and conventional data-header holds; all digital modes. |
| `--enc-lockout`, `--enc-follow` | Disable/enable encrypted-call following; all digital modes. |
| `--scan-voice-only`, `--no-scan-voice-only` | Enable/disable the conventional voice gate; digital modes (an analog row holds on carrier instead). |
| `--scan-voice-qualify-ms`, `--scan-voice-hold-ms` | Conventional voice-gate intervals, `100..600000` milliseconds; digital modes. |
| `--scan-max-visit-ms <ms>` | Maximum time on this row or target per visit; `0` disables the cap for it, otherwise `1000..3600000` milliseconds. All modes, and every trunk-target type. |
| `--squelch-db <dB>` | This row's or target's squelch threshold, in whole dB from `-100` to `0`, the same units as `[input] rtl_sql` and the `sql` field of `-i rtl:`; `0` switches the squelch off for this row alone. All modes, and every trunk-target type. |
| `--squelch <setting>` | The same option in the squelch grammar: `off`, whole dB from `-100` to `0`, `auto[+N]`, the [auto squelch](cli.md#auto-squelch---squelch-auto) N dB (3 to 30, default 10) over the noise floor learned on this channel, or `noise[+N]`, the [noise squelch](cli.md#noise-squelch---squelch-noise) opening at N dB (3 to 30, default 10) of FM quieting. Levels and `off` on every row and trunk-target type; `auto` on `nfm` and `am` rows and `nfm-conventional` and `am-conventional` targets only; `noise` on `nfm` rows and `nfm-conventional` targets only. A row names one of `--squelch` and `--squelch-db`. |
| `--nfm-bandwidth-hz <Hz>` | This analog row's or target's NFM channel width, whole Hz from `8000` to `25000` (for example `12500`). `nfm` rows and `nfm-conventional` targets only; a digital or blank row is told it `needs mode nfm`, and an `am` row refuses it as `not supported for this mode/target`. |
| `--am-bandwidth-hz <Hz>` | This analog row's or target's AM channel width, whole Hz from `5000` to `20000` (for example `8333` for 8.33 kHz airband spacing). `am` rows and `am-conventional` targets only; a digital or blank row is told it `needs mode am`, and an `nfm` row refuses it as `not supported for this mode/target`. A row carries one width. |
| `--tone-allow <list>`, `--tone-block <list>`, `--no-tone-filter` | This analog row's or target's CTCSS/DCS receive policy (see [Analog rows](#analog-rows)): hear only traffic carrying a listed tone or code, mute it, or no filter on this row whatever is configured. `<list>` is standard CTCSS tones and DCS codes separated by `/`, such as `67.0/100.0/D023N`. One option in three spellings, so a row names one of them once. `nfm` rows and `nfm-conventional` targets only; a digital or blank row is told it `needs mode nfm`, and an `am` row refuses it as `not supported for this mode/target`. |

Protocol-specific options require a declared `mode`; trunk targets use their `type`. A channel map whose rows carry
`options` but no `mode` still runs through the typed scanner (blank rows inherit the configured decoder), since the
legacy `-Y` scanner applies row keys but not row options, so a legacy list always uses the global
`--scan-max-visit-ms`. Trunk-system targets reject voice-gate options: their existing `dwell_ms` and
`activity_hold_ms` columns retain their roles, while a conventional target's voice-gate intervals replace those two
columns while the gate is on (see `docs/trunk-scan.md`). `--scan-max-visit-ms` is the one scan-timing switch
trunk-system targets do accept, since the per-visit cap applies to every target type. Input/output, frontend
selection, decoder flags and scanner-wide `-t` are not accepted in `options`.

`--squelch-db` (or `--squelch`) sets the channel squelch while the row or target is on air and restores the
configured default when the scanner moves on or stops. A row that omits it inherits the default (`--squelch`,
`[input] rtl_sql`, the `sql` field of `-i rtl:...`, or whatever the squelch control last set, an auto squelch
included); `0` or `off` switches the squelch off for that row only; any other value is a threshold in dB.
Positive numbers (the legacy linear form some CLI inputs accept), values below `-100` and fractional dB are rejected
with a row diagnostic, and so is `auto` on a digital or blank row: a digital channel runs no auto squelch, so an
inherited one is off there. On an RTL-SDR, rtl_tcp, SoapySDR or Airspy input the threshold
gates the demodulator, so a row set well above its signal level decodes nothing: on a trunk-system target it gates
the control channel too, and a high threshold there makes the whole system look dead. On any other input (rigctl
tuning a PCM, UDP or TCP audio source) there is no demodulator for it to gate, so it cannot gate digital
acquisition: it only gates the analog input monitor (`-8`, with audio output on) and the carrier activity that
monitor stamps, and scan start logs one warning per affected digital row or target. On an analog row that monitor
and its carrier are exactly what the squelch is for, so an analog row draws no such warning. Frontends show
the value in force first and, while a row overrides it, the configured default beside it
(`SQL: -60.0 dB (row; default -80.0 dB)`, `SQL: auto +6 dB (floor -81.0 dB; row; default -60.0 dB)`); the Qt/Android
channel-map review and target preview list each row's squelch, or `inherit`. The squelch controls and Config->Save work
on the configured default, never the row's value; a squelch edit made while a row overrides it says so.

While a scan runs, a row's `--squelch-db`, its channel width and its tone policy (and a trunk-scan target's `rtl_gain`)
can be changed for the rest of the session from the frontends' "this channel" editors, or made to follow the configured
default whatever the row says; the file is never written, and Config->Save never saves such an edit. See [Live
per-channel edits](trunk-scan.md#runtime-behavior).

### Analog rows

`nfm` and `am` channel-map rows and `nfm-conventional` and `am-conventional` trunk-scan targets accept only the options
that mean something for an analog channel: `--scan-max-visit-ms`, `--squelch-db` or `--squelch` (an auto squelch
included) and the width option of their own kind,
`--nfm-bandwidth-hz` on NFM and `--am-bandwidth-hz` on AM, and on NFM the tone policy (`--tone-allow`, `--tone-block`,
`--no-tone-filter`). Key switches (`-b`, `-H`, `-1`, `-R`, `-k`, `-K`, `--dmr-tg-key-csv`, `--dmr-tg-key-clear`,
`--no-decryption-keys`, `--key-profile-ref`), forcing (`-4`, `-0`, `--dmr-force-algid`, `--no-force-key`), CRC policy
(`-F`, `--strict-crc`), `-^`, `-G`, data- and encrypted-call policy (`-e`, `--no-data-calls`, `--enc-*`) and the
voice-gate switches describe digital frames an analog channel never carries, and are rejected with
`not supported for this mode/target`.

`--nfm-bandwidth-hz` and `--am-bandwidth-hz` are the full RF channel width the analog channel filter protects while the
row is on air (the same contracts as the receiver's NFM and AM widths); a row without one uses the configured width of
its kind (NFM 16 kHz, AM 6 kHz by default; on audio input with a rigctl peer an unset NFM width asks for `-B`, below).
The width is applied when the row is tuned and restored when the scanner moves on, and Config->Save never writes it (nor
the row's analog class) as a default. The Qt/Android channel-map review and target preview list it
(`NFM bandwidth: 12.5 kHz`, `AM bandwidth: 8.333 kHz`), or `inherit` on an analog row without one. The status line shows
it with the configured width it overrides, `Analog: NFM 12.5 kHz (row; default 16 kHz)` or `Analog: AM 8.333 kHz (row;
default 6 kHz)`, and the width controls of that kind (the terminal rows, the Radio sheet, and on audio input with a
rigctl peer the Passband sheet) keep editing the configured width: while the row is on air the edit waits for it to
leave, and the message says the channel overrides it. An edit of the other kind's width is not shadowed: an AM width
edit under an `nfm` row, or an NFM width edit under an `am` row, is the configured width's at once. A width the running
DSP rate cannot filter (the channel filter needs `width / 2 + 600 Hz` within 0.45 of the DSP rate: at a 24 kHz DSP
bandwidth the widest is 20.4 kHz, at 16 kHz 13.2 kHz) is named with the fix the input allows (an RTL DSP bandwidth that
fits; on a SoapySDR or Airspy device a wider DSP bandwidth or a narrower width; on an I/Q replay a narrower width) in
the log and on the status line when the scan starts, against the rate the running stream publishes, and again whenever
that rate changes. A channel map imported while DSD-neo runs (the terminal menu, Qt, Android) is held to the DSP rate
known then: the running stream's, or on an RTL-SDR or rtl_tcp input with no stream running the one its DSP bandwidth
sets. The map still loads, since the DSP bandwidth that fits it can be set afterwards, and the import message names the
first row that rate cannot run and how many more there are. A SoapySDR or Airspy device, or an I/Q replay, delivers its
rate only once its stream runs, so its rows are held to it at scan start; the Qt/Android review before an import, like a
trunk-scan list's preview, checks the width's range only. A row the rate cannot filter is skipped at every visit rather
than received without its filter, and so is every row with a width of its own while `DSD_NEO_CHANNEL_LPF=0` turns off
the channel filter each explicit width needs. A row without a width of its own is held to the rate with the configured
width of its kind it runs, and is named again whenever that configured width changes; the AM default always runs its
channel filter, so an `am` row on it is held like an explicit width. While the scan has such a row, the configured width
of its kind is in use on any session, as under `-fA` or `-fM`: a width edit or a loaded config that sets a width the DSP
rate cannot filter, and a DSP bandwidth or an input switch that would open an RTL-SDR or rtl_tcp device at a rate that
cannot filter the configured width, is refused, whichever row is on air (a SoapySDR or Airspy device's start checks only
the width in force against the rate it delivers).
While a row with its own width is on air, an RTL DSP bandwidth that cannot filter the width is refused rather than
reopening the stream on it, from the DSP bandwidth control, Input > Switch source and a loaded config alike.

On audio input (rigctl tuning a PCM, UDP or TCP source) the rigctl peer demodulates, so each row's tune asks it for the
row's demodulator and passband before the frequency: an `am` row sends `M AM <width>` with the AM width it runs (its
own, else the configured one), and an `nfm` row sends `M NFM <width>` (`M FM <width>` to a peer that refuses the `NFM`
token) with its own width, else, as a row without a mode of its own does under `-fA`, with the configured NFM width when
one is set (issue #621). A peer that refuses either skips the row, as any row it cannot tune. SDR++ and GQRX take a
passband of `0` as "leave it unchanged", and SDR++ keeps each passband it is sent, even across restarts, so before a row
first changes the peer's AM or FM passband DSD-neo asks the peer what it runs (`m`; a peer on the other demodulator is
first switched to this one at passband `0`, which keeps its own, and asked again). Every other row asks for `-B` (a
digital row, or under `-fA` a row without a width, where `-B` stands in for the unset NFM width): on audio input that
too is a passband DSD-neo sets on the peer, the one the row is heard through, so the peer's own is read first and kept
for the later return (issue #621). Without `-B`, where an earlier row changed the peer, such a row asks for FM at the
passband it read, which returns the peer to FM at its own passband; that request is best-effort, except that a peer
still on an `am` row's AM that
refuses it skips the row, since the row would be heard through AM, as does one that may be on AM because the reply to a
request for AM was lost. A row's tune that fails after the peer took the row's demodulator or passband (its frequency
refused, say) asks the peer for what it ran before, or for the passband it read where DSD-neo had set none, so the row
still on air is not heard through the other demodulator or the failed row's passband. Leaving `-Y` (the scanner toggled
off, a map imported or cleared, shutdown) puts back the AM passband an `am` row changed, then asks the peer once more
for what the session runs (under `-fA` its configured NFM width, else `-B`, a passband DSD-neo sets, so the reading of
the peer's own passband stays for the session's later return to it), so it is left on neither an am row's demodulator
nor a row's passband. An untyped list's step asks for that same passband of the session, and a peer that refuses the
configured NFM width there abandons the step, as a refused `-B` always did; where the session runs the peer's own
passband (`-B` 0, or `-fA` with neither a width nor `-B`), the step asks for FM at it, best-effort, which undoes a
passband DSD-neo set and sends nothing to a peer it never changed. A peer that cannot answer `m` is sent passband `0`
instead, which only a peer that takes it as its normal passband (Hamlib's meaning) returns to it. Audio input without a
rigctl peer applies no width, and scan start says so; nothing demodulates an `am` row's AM there, so scan start names
each `am` row as skipped at every visit, whatever its width. On an RTL-family input DSD-neo demodulates the I/Q itself
and a rigctl peer beside it only follows the frequency: it is asked for `-B`, best-effort, whatever the row runs and
whatever demodulator the peer is on. On audio input, a rigctl reconnect during the scan (the `9` key, or the menu's host
and port) to the same host and port keeps what the scan needs to put the peer back; one to another host or port, while
the old peer may be on an `am` row's AM, asks the new peer for FM at the next FM or digital row, a refusal skipping that
row, and leaves the old peer as the scan last set it. A reconnect that fails keeps the connection in use.

An analog row holds while its carrier is open: the squelch is open over the monitor audio (above the input's level
floor, through a 200 ms hangover, at any input rate), whether or not audio is played, so `-o null` or a muted frontend
no longer lets the scanner leave an active channel. A retune that has not landed, or one that failed and left the
receiver on another channel, holds nothing. A `-Y` row holds for `-t` after the last carrier; an `nfm-conventional` or
`am-conventional` target holds for its `activity_hold_ms` after the last carrier and rotates after its `dwell_ms` of
silence. The per-visit cap and the hold, advance and avoid controls apply as for any row, and the voice gate never
applies to an analog row, so a global `--scan-voice-only` does not block one. That includes the rows of an untyped
list scanned under `-fA` or `-fM` (AM), which hold on their carrier under `-t` as well. Scan start warns once about an
analog row whose squelch is off or at -100 dB or below: noise then keeps its carrier open, re-arming the hold with every
block, so only the visit cap or a manual advance or avoid moves on. The auto and noise squelches (`--squelch auto`,
`--squelch noise`, the row's own or inherited) close on noise on a radio input, so a row running one draws no warning.
On audio input the noise squelch closes an `nfm` row on noise too (it learns its reference from the input; see "Noise
squelch on audio input" in `docs/cli.md`); the auto squelch, and the noise squelch on an `am` row, are off there and
the row is warned about as an open one.

On an `nfm` row or `nfm-conventional` target the tone policy (issue #527) is the configured receive policy
(`--tone-allow`, `--tone-block`, `[analog] tone_filter` and `tone_list`; see "Tone filter" in `docs/cli.md`) for this
row alone: a row without one runs the configured policy, `--no-tone-filter` turns it off on this row, and the list is
written as on the command line, `/` between entries. A comma ends the `options` cell (the splitter has no quoting), so a
list written with commas is refused rather than imported short: when the cell ends with the list and the field after the
comma lies past the header's last column, or is one of the file's own columns whose whole field is a run of
`/`-separated entries with no space, starting with a standard tone or code (`67.0`, `67.0/D023N`), alone or followed by
another row option the same comma cut off (`67.0 --squelch-db -60`), the row is refused with
`--tone-allow: use / between entries, not commas`, and the text after the comma is not repeated. Any other name with a
space in it (`100 Main St`, `D023 Repeater`) is its column's own, but a one-word name that is itself a standard tone or
code (`100`, or `150` now that 150.0 Hz is a supported tone) reads as the list's rest. A code matches by its signal:
`D023I` passes traffic received as
`DCS D047N / D023I`. The polarity is part of the signal, so on a source whose audio is inverted a `D023N` transmitter
arrives as that same `DCS D047N / D023I` and a listed `D023N` does not match it: fix the audio's polarity or list the
spelling the monitor shows (see [Received code (DCS)](cli.md#received-code-dcs-on-the-analog-monitor)). The row's policy
applies when the row is tuned and the configured one is restored when the scanner moves on, and Config->Save never
writes it. The Qt/Android channel-map review and target preview list it (`Tone filter: allow 100.0 Hz/D023N`,
`Tone filter: off`), or `Tone filter: inherit` on an nfm row without one. An `am` row or `am-conventional` target has
none: the AM monitor hears no CTCSS or DCS, so the options are refused there, and while it is on air the configured
policy judges nothing and mutes nothing; its carrier holds it as `Carrier`. The policy is a setting, and frontends show
it apart from the tone or code received: the `Tone filter:` line (terminal) and `TONE FILTER` row (Qt/Android) read
`allow 100.0 Hz/D023N (row; default off)` while the row's own policy is on air over a configured policy that is off,
beside the `Rx tone:` line or `RECEIVED TONE` row that only ever shows what was received. Under a list policy each
transmission starts muted while it is checked (800 ms, to 1,600 ms while the list holds a DCS code and a received code
is still being confirmed); the row holds while its carrier lasts, with the stay reason `Tone check` and no countdown
meanwhile: a `-Y` pass keeps it then even when `-t` has run out, and so does the trunk-scan tick. The check is not
activity: it restarts no `-t` or `activity_hold_ms` and leaves a target's idle dwell running, so one that ends before a
verdict leaves no tail, and repeated short bursts the policy never passes (kerchunks, noise) cannot park the scanner on
a muted row. Traffic the policy allows is activity like any carrier and leaves the ordinary tail. Traffic the policy
rejects is muted and holds nothing: a `-Y` row moves on at the next no-carrier pass and an `nfm-conventional` target at
the next tick, without waiting out `-t` or its `activity_hold_ms`, and traffic that was passing and turns out to carry a
blocked (or, under allow, an unlisted) tone or code is released the same way, as is traffic rejected and ended before
that pass or tick came (the rejection outlives its carrier for the scanner until the next carrier opens or the row
changes). An operator hold keeps the row, muted. A `-Y` row on the same frequency is somewhere to take rejected traffic
only when it would judge it otherwise: a row of another class (a `dmr` row for a mixed-mode repeater's DMR traffic), or
an `nfm` row whose own or configured policy passes the traffic's tone or code (a repeater listed once per user group,
each row with its own `--tone-allow`). A row that would reject it too is not, and with nowhere else to go the row keeps
the traffic, muted, under `Carrier` with no countdown, until it ends and the ordinary tail runs. Example:

```csv
channel,frequency_hz,name,mode,options
1,154430000,County fire,nfm,--squelch-db -60 --tone-allow 156.7/D023N
2,155475000,Public works,nfm,--tone-block 100.0
3,155520000,Shared repeater,nfm,--no-tone-filter
```

A list may mix analog and digital rows: each row switches the receiver between the FM monitor, the AM monitor and the
digital decoder at its own width when it is tuned, without reopening the device, and opens the audio output the row
plays through. The monitor stays silent while a retune is in flight, and after one that failed once the scanner had
moved on, until a later retune lands or the scan ends, since the receiver may then still be on another row's channel.

Omitted settings inherit the outer CLI/configuration, including forcing. Use `--no-force-key` on a normal mixed
clear/BP channel when forcing is configured globally. `-b 1` with normal signalling processes clear and BP calls;
`-4` deliberately applies loaded privacy keys even to frames marked clear and can corrupt those clear calls.
There is no automatic choice between forced Motorola and Hytera privacy.

The existing `single_key_dec` and `single_key_hex` columns load the `-b` and `-H` key values, respectively.
They do not claim an encrypted-audio mute override by themselves. Direct switches in `options` (`-b`, `-H`,
`-1`, `-R`) arm decryption for every accepted value, including zero: DMR encrypted-audio mute flags clear,
and undecodable P25 audio stays muted, matching standalone and live direct-key entry. Material-only columns
and key CSV files preserve the inherited mute policy. Use `options=-R 1` for a direct NXDN scrambler and
`options=-1 0123456789` for direct RC4. Loading a key does not itself enable forcing. A
direct source replaces the row's complete key set; unspecified families and keyring entries are cleared.
Explicit zero is a supplied value. Direct and file-backed key sources cannot be mixed, including across
columns and options. Compatible direct families may be combined, but duplicate definitions reject the import.

Within a row, repeated settings reject the import, even with identical values or different switch spellings:
`-4 -4`, `-b 1 -b 2`, and `-F --strict-crc` are errors. Conflicting force settings also reject the import. The
only accepted redundancy is one `-0` paired with one `--dmr-force-algid 21`, in either order, because both
request the same fallback. ALGIDs are hexadecimal, with or without `0x`: `0x00` disables fallback; `0x01` and
`0x16` are rejected because they are reserved non-algorithm markers internally. Received DMR algorithm/key
identifiers retain precedence over algorithm fallback.

Separate switches with whitespace; quote an argument with single or double quotes to retain spaces.
Backslashes are literal, so `-G "C:\Radio Lists\groups.csv"` works without shell escaping. Hex keys may
include an optional `0x` prefix and whitespace inside a quoted argument. Long switches that take an argument
also accept `--name=value`; argument-free switches reject it (for example, `--scan-voice-only=yes`). An
argument must not start with `-`; use `./-name.csv` for a filename that starts with a dash. The one exception is
`--squelch-db` (and `--squelch`), whose value is negative: a following token that reads as a negative number, a minus
sign and a digit followed only by digits, `.`, `e`, `E`, `+` or `-` (`--squelch-db -60`), is its value, while anything
else starting with `-` (`--squelch-db --strict-crc`) is still refused as a missing value. A malformed number such as
`--squelch-db -5.5` is therefore reported as an out-of-range value, the same as `--squelch-db=-5.5`. The digit
switches `-0`, `-1` and `-4` read as numbers there too: `--squelch-db -4` sets -4 dB and is never the `-4` switch.
`--squelch-db=-60` also works. CSV commas remain field separators, including inside quotes. Unknown switches,
positional text, malformed quotes and duplicate settings are errors. Diagnostics name the row and option without
repeating raw option text or key values.

File paths resolve relative to the containing CSV. Key-file paths (`-K`, `-k` and the legacy columns) are
limited to 2047 bytes for channel maps and 1023 bytes for trunk targets, after resolution and excluding the
terminating NUL. A `-G` path is limited to 1023 bytes, the same as the global group file it replaces.
Companion paths in a nonempty `options` cell are resolved and loaded even when the row's channel number is
invalid and takes no scan slot. Keys and group policies are loaded before scanning starts; switching rows
never reads these files. A group file row the importer cannot store is skipped with a warning, exactly as for
a global `-G` import. `-G` replaces the active group policy while parked. Labels and session policy edits
remain with that row's policy; unconfigured rows use the global policy. Global group imports and scoped
setting changes from the frontend (forcing, CRC policy, mutes, voice gate) update the saved baseline beneath
the active row. Changes to inherited settings take effect immediately; explicit row overrides continue to
apply, and temporary suspension preserves active-call priority bookkeeping. Direct-key menu commands keep editing the live keys while their unmute decision updates the saved
defaults; an explicit row mute still takes precedence. The existing Relaxed CRC checks menu toggle changes
frame CRC checks only; it preserves the separately configured DMR CSBK CRC default. Leaving or replacing the
scan restores that baseline. Frontend configuration saves preserve configured defaults, not temporary row
overrides.

The Qt/Android picker supports embedded values. Companion files named by `-G`, `-k` or `-K` have the same limitation
as existing key-file columns: the picker does not copy companion files alongside the imported list.

Declared modes use these symbol profiles:

| Mode | Symbols per second | Levels |
| --- | ---: | ---: |
| P25 (both phases) | 4800 and 6000 | 4 |
| DMR, NXDN96, YSF, M17 | 4800 | 4 |
| NXDN48, dPMR | 2400 | 4 |
| D-STAR | 4800 | 2 |

An analog (`nfm` or `am`) row has no symbol profile: it runs the analog monitor at its channel width.

## Trunk Scan Target CSV (`--trunk-scan <file>` / `[trunk_scan] targets_csv`)

Purpose: Rotate one tuner across explicit P25 trunk, DMR trunk, NXDN trunk, and one-frequency P25, DMR, NXDN96,
NXDN48, analog NFM and analog AM conventional targets. Qt/Android can import this format as a playable scan list with a
read-only preview and privately stored companion files. See `docs/trunk-scan.md` for the full setup workflow and
troubleshooting guide.

The header must start with this exact prefix:

```csv
id,type,frequency_hz,chan_csv,dwell_ms,activity_hold_ms,notes
```

- Optional columns are allowed after `notes`; recognized optional columns are matched by header name.
- Every data row must contain the first seven fields, even when optional values are empty. Missing trailing optional
  fields are treated as empty.
- Blank data rows are skipped.

Columns:

| Column | Required | Behavior |
|--------|----------|----------|
| `id` | Yes | Unique short name shown in the terminal status row and Call Info, as the `[id]` prefix on event-history rows, `-J` log lines and the rdio `talkgroup_tag` fallback, and in log messages. Empty or too-long IDs are rejected. |
| `type` | Yes | One of `p25-trunk`, `p25-conventional`, `dmr-trunk`, `dmr-conventional`, `nxdn-trunk` (NXDN96, 12.5 kHz), `nxdn48-trunk` (NXDN48, 6.25 kHz), `nxdn-conventional` (NXDN96, 12.5 kHz), `nxdn48-conventional` (NXDN48, 6.25 kHz), `nfm-conventional` (one analog NFM channel) or `am-conventional` (one analog AM channel); see [Analog rows](#analog-rows). Exact case. |
| `frequency_hz` | Yes | Decimal Hz only. Builds with a 64-bit `long` (Linux, macOS, Android) accept `1..4294967295`; Windows builds, whose `long` is 32-bit, and other 32-bit targets reject values above `LONG_MAX` (2147483647). Do not use `K`/`M`/`G` suffixes in CSV. |
| `chan_csv` | No | Optional channel-map path for trunk targets (`p25-trunk`, `dmr-trunk`, `nxdn-trunk`, `nxdn48-trunk`). Paths are resolved relative to this CSV. Leave empty for conventional DMR, P25, both conventional NXDN types and the analog types. |
| `dwell_ms` | No | Per-target idle dwell (`250..600000`). Empty uses `--trunk-scan-dwell-ms` or `[trunk_scan] idle_dwell_ms`. |
| `activity_hold_ms` | No | Per-target conventional DMR/P25/NXDN (NXDN96 and NXDN48) activity hold (`250..600000`), and an analog target's hold after its carrier drops. Empty uses `--trunk-scan-activity-hold-ms` or `[trunk_scan] activity_hold_ms`. P25 holds from allowed voice starts, not PDU data; `-e` has no effect on P25 conventional holds. |
| `notes` | No | Ignored. Use for local notes. |
| `modulation` | No | Per-target demod hint. Empty preserves global/default handling. `auto` uses target defaults and overrides global `-m` locks for that target. Both P25 types accept `auto`, `c4fm`, `cqpsk`; DMR and both NXDN rates accept `auto`, `gfsk`. An analog (`nfm-conventional`, `am-conventional`) target takes none. |
| `rtl_gain` | No | Per-target RTL-family tuner gain. Empty uses the configured gain, including one set live during the scan. `0` or `auto` requests device automatic gain. `1..49` requests manual dB gain. Ignored for non-RTL retuning paths. |
| `keys_hex_csv` | No | Per-target hex key file (`-K` format), resolved relative to this CSV. A row may fill both key columns; they load into one per-target key set. Empty uses the global keys. |
| `keys_dec_csv` | No | Per-target decimal key file (`-k` format), resolved relative to this CSV. Empty uses the global keys. |
| `single_key_dec` | No | Embedded `-b` Motorola Basic Privacy key number (`0..255`). Explicit `0` is present and overrides the global key. May be combined with `single_key_hex`, but not either key-file column. |
| `single_key_hex` | No | Embedded `-H` key: optional `0x`, whitespace ignored, exactly 10, 32, or 64 hex digits. May be combined with `single_key_dec`, but not either key-file column. |
| `options` | No | Scoped switches described above; target `type` determines which protocol options apply. |
| `p25_bandplan_csv` | No | Per-target [P25 band plan CSV](#p25-band-plan-csv---p25-bandplan-file--trunking-p25_bandplan_csv) for a `p25-trunk` target, resolved relative to this CSV. Leave empty for conventional targets, including `p25-conventional`. The rows are parked in the trunk target's snapshot, so one exported multi-system file can be named on every `p25-trunk` row: each target seeds only the rows that carry its own WACN/SYS (and rows that carry none). |

Validation notes:

- No fixed target-count limit. Each parked target reserves a snapshot of decoder state (~80 KB), and the list is
  capped by a 256 MB budget for those snapshots - a few thousand targets. A CSV past the cap is rejected while
  parsing, with an error naming the budget.
- Duplicate IDs and duplicate `(type, frequency_hz)` rows are rejected. `nxdn-trunk`/`nxdn48-trunk` and
  `nxdn-conventional`/`nxdn48-conventional` are distinct types, so one frequency may appear once as each.
- Optional column names match ASCII case-insensitively in this format. Duplicate direct-key headers, malformed direct values, and
  rows that mix a direct value with a key-file path are rejected without echoing the key value.
- `chan_csv` and `p25_bandplan_csv` on conventional
  (`p25-conventional`/`dmr-conventional`/`nxdn-conventional`/`nxdn48-conventional`/`nfm-conventional`/`am-conventional`)
  rows are rejected; a duplicated `p25_bandplan_csv` header is rejected, and a band plan that fails to load fails
  the whole import.
- An `nfm-conventional` or `am-conventional` row also rejects a `modulation` value and every key column
  (`keys_hex_csv`, `keys_dec_csv`, `single_key_dec`, `single_key_hex`), without echoing a key. `nfm-trunk` and
  `am-trunk` are rejected with `analog targets are conventional only` (use `nfm-conventional`/`am-conventional`),
  `am` with the hint to use `am-conventional`, and the analog FM spellings (`nfm`, `fm-conventional`, ...) with the
  hint to use `nfm-conventional`; any other unknown type, including a miscased one, lists the accepted ones.
- Global `-C`/`[trunking] chan_csv` and `--p25-bandplan`/`[trunking] p25_bandplan_csv` are rejected in trunk scan
  mode so channel maps and band plans do not leak across systems.
- One tuner can only monitor the active target; traffic on other targets can be missed.
- This parser can handle a quoted `chan_csv` field containing a comma, but it is not a full RFC 4180 parser and does not
  support escaped quotes.

Example:

```csv
id,type,frequency_hz,chan_csv,dwell_ms,activity_hold_ms,notes,modulation,rtl_gain
county-p25,p25-trunk,851012500,,3000,,primary P25 control channel,cqpsk,18
field-p25,p25-conventional,851500000,,1500,1200,one-frequency P25,c4fm,
city-dmr,dmr-trunk,452012500,dmr_channels.csv,3000,,DMR Tier III control channel,auto,
plant,dmr-conventional,461112500,,1500,1200,one-frequency DMR,gfsk,auto
site-nxdn,nxdn-trunk,461037500,,3000,,NXDN Type-C control channel,auto,
site-nxdn48,nxdn48-trunk,461556250,nxdn_chan_map.csv,3000,,NXDN48 Type-C control channel (6.25 kHz),gfsk,
field-nxdn,nxdn-conventional,461550000,,1500,1200,one-frequency NXDN96 channel,gfsk,
field-nxdn48,nxdn48-conventional,461556250,,1500,1200,one-frequency NXDN48 (6.25 kHz) channel,gfsk,
```

A list mixing analog AM and NFM channels with digital ones (the `options` column carries each analog target's width,
spelled for its kind, and squelch):

```csv
id,type,frequency_hz,chan_csv,dwell_ms,activity_hold_ms,notes,options
tower,am-conventional,118300000,,2000,3000,airband tower (8.33 kHz spacing),--am-bandwidth-hz 8333 --squelch-db -55
fire-dispatch,nfm-conventional,154430000,,2000,3000,county fire dispatch,--nfm-bandwidth-hz 12500 --squelch-db -60
city-dmr,dmr-conventional,461112500,,1500,1200,one-frequency DMR,
guard,am-conventional,121500000,,2000,3000,airband guard (default 6 kHz AM width),--squelch-db -60
public-works,nfm-conventional,155475000,,2000,3000,wideband 25 kHz channel,--nfm-bandwidth-hz 16000 --squelch-db -55
county-p25,p25-conventional,851500000,,1500,1200,one-frequency P25,
```

## P25 Band Plan CSV (`--p25-bandplan <file>` / `[trunking] p25_bandplan_csv`)

Purpose: Give the decoder a P25 site's band plan (its `IDEN_UP` identifier table) when the site never broadcasts
one, so grants can be turned into frequencies without a per-channel map. The same file is what **Export learned
P25 band plan...** and `--p25-bandplan-export` write, so a plan learned on one run (or one site of a system)
can be loaded on the next.

Required columns (positional):

1. `iden` (`0..15`) - the band-plan identifier, the top hex digit of a P25 channel number
2. `base_hz` (integer Hz, a multiple of 5)
3. `spacing_hz` (integer Hz, a multiple of 125, at most 127875)

Optional columns (matched by header name; the first three keep their positional meaning when unnamed):

4. `type` - the P25 channel type as `IDEN_UP` carries it: `1` FDMA (default), `3` two-slot TDMA, `4` four-slot TDMA;
   types `0..2` are treated as FDMA, anything else as TDMA
5. `tx_offset_hz` (signed integer Hz, default `0`) - the mobile transmit offset; a multiple of `spacing_hz` on a row
   that gives a `bandwidth_hz` or has a TDMA `type` (the `IDEN_UP_VU`/`IDEN_UP_TDMA` encoding), a multiple of 250000
   on a standard FDMA row (the `IDEN_UP` encoding). Informational: the decoder tunes the repeater output
6. `bandwidth_hz` - `6250` or `12500` for a VHF/UHF (`IDEN_UP_VU`) identifier, empty or `0` for the standard form
7. `wacn` / `sysid` (hex, no prefix, as the UI prints them: `W:BEE00 S:3A1`) - both or neither. A row that names a
   system applies only while the receiver is on that WACN/SYS; a row without applies everywhere

Notes:

- Rows seed the identifier table at trust `prov` (unconfirmed). A real `IDEN_UP` from the site replaces the row the
  moment it arrives, and the table is re-seeded from the file whenever the receiver moves to another system (rows
  for the new system and rows without a system). When a file has both a row that names the current system and a
  row without one for the same identifier, the system's row wins.
- A row with a bad value is skipped with a warning naming the row; a duplicate identifier (same `iden`, FDMA/TDMA
  class and system) replaces the earlier row; a file with no usable row is refused and leaves the previous plan in
  place. At most 64 rows are kept.
- `--p25-bandplan` and `[trunking] p25_bandplan_csv` are refused with `--trunk-scan`; use the target list's
  `p25_bandplan_csv` column instead (see above).
- Under trunk scan, targets that turn out to be sites of the same system (same WACN/SYS) also share what one of
  them learned over the air: an identifier the parked target is missing is copied from another target's table at
  trust `prov` when the WACN/SYS match, and never otherwise.
- Terminal: **Trunking -> Channels & groups -> Import P25 band plan CSV...** loads one into the running decoder and
  **Export learned P25 band plan...** writes the current tables (every target's, under trunk scan) with their
  WACN/SYS. `--p25-bandplan-export <file>` writes the same file once at clean shutdown, which suits a headless run.
- Android: the imports library takes the file as the **P25 band plan** kind, and a saved system can name one; it is
  passed to the session as `--p25-bandplan`.
- Uniden Sentinel's custom band plan (base, spacing, offset, bandwidth per identifier) maps onto columns 1-6;
  SDRTrunk's identifier table (type/slots, base, spacing, bandwidth, transmit offset) onto the same columns.

Example (`examples/p25_bandplan.csv`):

```csv
iden,base_hz,spacing_hz,type,tx_offset_hz,bandwidth_hz,wacn,sysid
0,851006250,6250,1,-45000000,12500,,
1,762006250,6250,1,-30000000,12500,,
2,762006250,6250,3,-30000000,,BEE00,3A1
```

## Group List CSV (`-G <file>` / `[trunking] group_csv`)

Purpose: Provide labels and allow/block behavior for talkgroups.

Required columns:

1. `id` (decimal integer; talkgroup ID or radio ID depending on protocol context). For radio ID names without
   policy, use the [Source ID List CSV](#source-id-list-csv---src-csv-file--trunking-src_csv) below.
2. `mode` (string)
3. `name` (string)

Notes:

- The first line is treated as header text and is required.
- Basic/default behavior uses the first 3 columns. A fourth header field named `tag`, `tags`, or `category`
  (case-insensitive, surrounding whitespace ignored) retains that column as a category; other extra columns,
  including `metadata`, are ignored. Categories are trimmed and capped at 49 bytes, like names.
- `mode` is matched literally by features that consult it:
  - `A` usually means allow/normal.
  - `B` and `DE` are treated as locked out.
- Names are not CSV-escaped; avoid commas and line breaks in fields.
- Exact IDs are decimal `uint32_t` values (`0..4294967295`). Runtime policy lookups import all valid exact
  rows that fit memory.

Extended policy columns are supported only when the header opts into this exact ordered prefix starting at column 4:

1. `priority` (0..100, default `0`)
2. `preempt` (`true`/`false`, default `false`)
3. `audio` (`on`/`off`, default from `mode`)
4. `record` (`on`/`off`, default from `mode`)
5. `stream` (`on`/`off`, default from `mode`)
6. `tags` (free text category retained for frontend filtering and round-tripping; never a policy condition)

Important behavior:

- The header must contain `priority` in column 4 and continue in that order for the available policy columns.
- If the header is basic/unknown (for example `id,mode,name,metadata`), optional policy parsing is disabled and extra
  columns remain metadata-only values.
- `id` supports exact IDs (`1201`) and ranges (`1200-1299`).
  - Exact rows populate the runtime policy table used for labels and decisions.
  - Range rows are policy entries that match IDs within the configured range.
- `preempt`, `audio`, `record`, and `stream` accept `true`/`false`, `yes`/`no`, `on`/`off`, or `1`/`0`.
- Exact duplicates preserve first-match behavior.
- `audio=off` forces `record=off` and `stream=off`.
- `mode=B`/`DE` forces media fields off regardless of optional values.
- `record` covers every recording: the per-call WAV (`-P`), the static WAV (`-w`) and MBE capture (`-d`).
- Rows, `-W` and the Hold match numeric talkgroup IDs. M17 addresses calls by callsign, so M17 traffic is not
  matched by them; use the M17 CAN filter to select M17 traffic.
- Android: **TG list** on the live monitor lists configured talkgroups/ranges plus voice talkgroups heard this
  session that no listed row covers. Tap a card to choose **Listening** (`A`) or **Not tuned** (`B`); the screen
  waits for the decoder snapshot before showing the change. Search matches names or IDs; category chips use the
  retained tags (RadioReference imports supply their category names).
- **Listen all** and **Do not tune all** edit listed rows in the selected category, or every listed row under
  **All**. Search text does not narrow bulk edits. Learned radio-ID alias rows and mode `D` rows are excluded.
  In allow-list mode, heard-but-unlisted talkgroups remain blocked until individually allowed.
- A listening edit preserves a row's name, category, priority and preemption setting, but resets its media flags
  from the selected mode. The monitor's **Lock out** uses the same name-preserving block path. **Skip** leaves the
  call without editing the list.
- When a group file is configured, edits atomically rewrite that file in table order, preserving ranges and
  modeled fields. Existing extended policy headers remain extended; otherwise the output is `id,mode,name,tags`
  when categories exist, or `id,mode,name`. Unmodeled metadata/note columns are discarded. Android rewrites its
  app-private imported copy, not the original document.
- A basic group-file header is promoted to the extended policy header when any canonical row has
  `priority != 0`, `preempt` enabled, or audio/record/stream flags that differ from the mode defaults,
  so those settings survive saving and reloading even to a new file.
- The decoder's talkgroup-list export writes the canonical table, including aliases, all modes and ranges,
  to the requested path. After a successful write, subsequent edits persist there. Export refuses scan-row
  contexts and stale context/generation pairs, as do row edits after the policy changes.
  App-control retains the export result separately from toasts: `dsd_app_tg_export_result_get` copies its
  sequence, success/failure, request context/generation, and destination path. A frontend keeps one export
  outstanding and waits for a newer matching successful result before registering the file; unrelated
  commands, toast updates, or session stops cannot erase that result.
- Without a group file, edits last only for the session. A scan row's own effective list is also edited only
  in memory, never written into the global group file. If saving fails, the decoder keeps the live edit and
  reports that it is session-only; the previous file remains intact.
- `--tg-lockout-session` (or `[trunking] persist_tg_lockouts = false`) makes terminal `!`/`@` temporary avoids
  and changes Qt/Android **Lock out** to **Avoid TG**. They block tuning and all media without editing policy rows or the file. Later
  list edits, exports and configuration saves cannot serialize these avoids. `--tg-lockout-persist` restores
  the default behavior for subsequent lockouts; switching modes never converts existing entries.
- Qt/Android **Settings → Listening → Save avoided talkgroups** and the terminal **Save user TG lockouts**
  menu setting take effect immediately. Explicit **Listening**, **Not tuned**, and bulk list edits still
  modify the canonical list, and temporary avoids continue to override it, including when a talkgroup Hold
  matches. The TG list shows temporary counts separately from its saved listening controls. **Skip** is unaffected
  by the setting: its expiring blocks never change policy rows or appear in saves or exports. See
  [Skip lifetimes](cli.md#trunking--scanning).
- Temporary avoids also mark the terminal's active-channel lockout indicator. The preference controls quick
  user lockouts only; existing over-the-air radio-alias learning can still append alias rows to the groups file.
- Qt/Android **Clear temporary avoids and call skips — current list** (terminal **Clear temporary TG avoids - current
  list**) clears only the active list's temporary avoids and call skips. It leaves saved blocks, encryption lockouts,
  and channel/target avoids intact. Retunes and scan visits preserve avoids and unexpired call skips; reloading,
  replacing, or clearing a list resets both in that scope. Stopping the decoder clears the session; reopening the
  Android Activity while its service runs does not.

Example:

```csv
DEC,Mode(A=Allow; B=Block; DE=Enc),Name,Tag
1449,A,Fire Dispatch,Fire
22033,DE,Law Dispatch,Law
```

Extended policy example:

```csv
id,mode,name,priority,preempt,audio,record,stream,tags
1201,A,Dispatch 1,80,true,on,on,on,primary
1202,A,Dispatch 2,40,false,on,off,on,secondary
1300-1399,A,Ops Range,10,false,on,on,on,wide
```

## Source ID List CSV (`--src-csv <file>` / `[trunking] src_csv`)

Purpose: Provide names for source radio IDs (unit IDs), shown as `SName:` in event history and in the terminal
call display: after `SRC:` on the NXDN target/source line, and on the slot's `D XTRA` line beside the talkgroup
label for DMR and P25 Phase 2. This list supplies labels only, with no allow/block or media policy. Private-call
destination radio IDs still use the group list.

Required columns:

1. `id` (decimal `uint32_t`, `0..4294967295`; exact `1234567` or inclusive range `2000000-2000999`, using the
   same grammar as the group list's `id`)
2. `name` (free text, trimmed and truncated to **49 bytes**; truncation may cut a multi-byte UTF-8 tail)

Optional column:

3. `tags` (free text; accepted and ignored). Further columns are ignored.

Notes:

- The first physical line is always consumed as a header. Blank lines are skipped.
- A row with fewer than two fields, an unparsable ID or reversed range, or an empty name is warned and skipped.
- A physical line with more than **998 bytes of content** (excluding its LF or CRLF terminator), or one that contains
  a NUL byte, is warned, its remainder discarded, and counted as one skipped row. Continuation fragments are never parsed as extra rows,
  and the following line is not consumed. An overlong header is still consumed as the header and is excluded
  from the validator's accepted/skipped/total counts, as are all headers and blank lines. It does not emit a
  skipped-row warning.
- Exact matches beat ranges; the **first row wins** for duplicate exact IDs. Among ranges, the narrowest
  range wins, with the **last row winning** equal-width ties, matching the group-list grammar.
- Names are not CSV-escaped; avoid commas and line breaks in fields.
- Source labels prefer this list, then fall back to the active group list's **exact-row** label. A CSV alias
  therefore wins over an OTA talker alias learned for the same RID as the `SName:` label; the OTA alias text itself
  is kept unchanged. Source `Mode:` still comes only from a group-list exact row, never from this list.
- Import replaces the current list. A missing or unreadable file, a read error, or an allocation failure fails
  the import and keeps the current list. All entry points accept zero usable rows as a loaded empty list.
  At engine startup a source-list load failure logs a warning and decoding continues without imported aliases.
- Qt/Android call views show the resolved source label alongside its radio ID or callsign; history preserves
  that label across sessions and includes it in text searches. Talkgroup names remain separate.
- The list is global, loads even when trunking is disabled, and is allowed with `--trunk-scan`. It survives scan
  target changes; its group-list fallback follows whichever policy table is active.
- Terminal: **Trunking → Channels & groups → Import source ID list CSV...** imports the list. There is no terminal
  clear row. Qt/Android uses the **Radio IDs** kind (`src`) and can clear the list by selecting **None**.

Example (`examples/src.csv`):

```csv
id,name,tags
1234567,Engine 21,Fire
1234568,Ladder 4,Fire
2000000-2000999,Dispatch consoles,Ops
```

## Decimal Key List CSV (`-k <file>`)

Purpose: Import decimal key IDs and values for basic privacy/scrambler helpers.

Required columns:

1. `key_id` (decimal integer)
2. `value` (decimal integer)

Notes:

- The value is stored as a 40-bit quantity (higher bits are discarded).
- If `key_id` exceeds 16 bits, it is truncated to 24 bits and hashed down to 16 bits for storage.
- Extra columns are ignored.
- A channel-map row (`keys_dec_csv`) or trunk-scan target (`keys_dec_csv`) can name a file in this format to
  override the global keyring on that row or target; see the Channel Map and Trunk Scan Target sections above.

Example:

```csv
key id or tg id (dec),key number or value (dec)
2,70
12,48713912656
```

## Hex Key List CSV (`-K <file>`)

Purpose: Import hex key IDs and values.

Required columns:

1. `key_id` (hex integer)
2. `value0` (hex integer)

Optional columns (for longer multi-part keys):

3. `value1` (hex integer)
4. `value2` (hex integer)
5. `value3` (hex integer)

Notes:

- Each `valueN` is parsed as a hex integer. For long keys, DSD-neo stores the additional parts at internal offsets.
- Extra columns beyond these are ignored.
- A channel-map row (`keys_hex_csv`) or trunk-scan target (`keys_hex_csv`) can name a file in this format to
  override the global keyring on that row or target; see the Channel Map and Trunk Scan Target sections above.

Example:

```csv
keyid(hex),value0,value1,value2,value3
C197,A753BC945DE5E0F1,EC1970F8565154E6,D9DF2FAC6278FA93,B531D2CC046E93A2
```

## Vertex Key->Keystream Map CSV (`--dmr-vertex-ks-csv <file>`)

Purpose: Interim decrypt support for Vertex DMR ALG `0x07` by mapping an entered key value to a known AMBE keystream.

Required columns:

1. `key_hex` (hex key value; same representation as `-1`, optional `0x` prefix)
2. `keystream_spec` in `bits:hex[:offset[:step]]` format

Notes:

- Header row is ignored (required by importer convention).
- `keystream_spec` format matches the `-S` option exactly:
  - `bits` is decimal and must be `1..882`
  - `hex` is packed keystream bytes
  - Optional `offset` and `step` are decimal bit positions for frame-aligned application
- Duplicate keys are allowed; the last occurrence replaces earlier rows.
- Maximum rows: `64`.

Example:

```csv
key_hex,keystream_spec,notes
1234567891,49:ED0AED4AED4AED4A,Vertex sample key
0xA1B2C3D4E5,168:0123456789ABCDEF0123456789ABCDEF0123456789:0:49,frame aligned
```

## DMR Talkgroup->Key ID Map CSV (`--dmr-tg-key-csv <file>`)

Purpose: Select the decryption key by talkgroup instead of the OTA-signaled key ID. A row here is an
explicit per-talkgroup override: the mapped key ID is used in place of the signaled one for the whole
call, and unmapped talkgroups keep normal signaled-key-ID behavior. Keys themselves still come from
`-K`/`-k`; this file only picks which key ID a talkgroup uses.

Required columns:

1. `tg` (decimal talkgroup ID, `1..16777215`)
2. `keyid` (hex key ID, `00..FF`; indexes the `-K`/`-k` keyring)

Notes:

- Header row is ignored (required by importer convention).
- DMR only, and it needs the CSV keyring (`-K`/`-k`) loaded plus a known ALG ID (signaled, or via
  `--dmr-force-algid` on systems that don't signal one). Loading the map without `-K`/`-k` warns and
  does nothing. With `--dmr-force-algid`, the row is already consulted at the call's first voice LC —
  before the forced ALG ID has been written to the slot — so a mapped talkgroup is never classified
  or locked out against the key the slot happened to carry from the previous call.
- Applies everywhere a DMR call's effective key ID is resolved: voice, encrypted data bursts (PDUs),
  crypto classification, the `--enc-lockout` release decision, and sdrtrunk JSON replay input.
- Group voice calls only. Private (unit-to-unit) calls put the destination radio ID where the
  talkgroup would be, and DMR radio IDs share the talkgroup's 24-bit address space, so an individually
  addressed call or data PDU is never matched against this file. For data, the header's group/individual
  bit is recorded alongside the target so the PDU can still be classified after the header itself is
  gone.
- The OTA key ID is never rewritten: logs, event history, and the UI keep showing the signaled key ID,
  and the printed data-PDU header leads with it too, appending the override only when one applied.
- A row applies only when the mapped key ID holds the kind of key material the call's algorithm
  actually consumes: a scalar for RC4/DES/Hytera Enhanced, the AES segments for AES-128/AES-256 (P25
  TDEA needs three), or a complete, non-zero quartet for Kirisun (`0x36`/`0x37`). A key ID that holds
  material of some other kind — an AES quartet mapped to an RC4 talkgroup, a scalar mapped to an
  AES-128 one — does not apply, for the same reason an unimported key ID doesn't.
- A mapped key ID with no imported key material, or with material of the wrong kind for the call's
  algorithm, always falls back to the signaled key ID instead of blocking the talkgroup outright, so a
  typo in the key ID column — or a row that names a real but mismatched key — never silently kills
  decryption for that talkgroup.
- Console visibility of this differs by consumer: voice announces both an applied override and a
  fallback, once per call, except for algorithms that consume no keyring material, where the row is
  inert and silent (e.g. Vertex); data PDUs show an applied override in the PDU header line but stay
  silent on a fallback; crypto classification, the `--enc-lockout` decision, and sdrtrunk replay apply
  the map with no console notice either way.
- In sdrtrunk JSON replay, a map row wins over the older implicit "key indexed by talkgroup"
  convention; with no matching row, that older behavior is unchanged. This holds regardless of the
  order in which fields appear in the JSON record.
- Duplicate talkgroups are allowed; the last occurrence replaces earlier rows.
- Maximum rows: `256`.
- CLI-only: there's no TUI or Android import path to load this map, only `--dmr-tg-key-csv` at startup.
  Clearing keys from the TUI clears the map along with them, with no runtime path to reload it.

Example (the key IDs are the ones in `examples/multi_key_hex.csv`; a mapped key ID with no imported
key material falls back to the signaled key ID instead of blocking the talkgroup):

```csv
tg (dec),keyid (hex)
123,02
4567,0C
```

## DMR Tier III LCN Calculator Input (`--calc-lcn <file>`)

The `--calc-lcn` one-shot tool is more flexible than the CSV imports above:

- It scans each line for the first numeric field and treats it as a frequency.
- Frequencies may be in **Hz** (e.g., `451237500`) or **MHz** (e.g., `451.2375`).
- The output is printed to stdout as `lcn,freq` CSV.

### Frontend-generated scan lists

Qt/Android scan lists generate the trunk-scan target format described in
[trunk-scan.md](trunk-scan.md#qt-and-android-scan-lists). Per-system group lists use
scoped `-G`, and direct keys use scoped `-b`/`-H`/`-1`/`-R` so their activation and
mute/force semantics match standalone sessions. Key CSVs use `keys_hex_csv` or
`keys_dec_csv`; frontend generation never uses `single_key_*`.

The generator refuses comma, double quote and line breaks in file paths. Spaces
are supported: an options cell contains `-G "absolute path/group list.csv"`
directly, without CSV-doubling those quotes. The engine target parser strips outer
CSV quotes but does not perform RFC-style doubled-quote unescaping. Generated
files containing keys are private internal inputs and are not shared exports.

### Scoped decryption maps and companion files

The `options` column of supported conventional channel maps and trunk-scan targets
accepts `--dmr-tg-key-csv <file>` or `--dmr-tg-key-clear` for DMR rows. Map files are
resolved relative to the containing CSV, validated before installation, and restored
with the target's key/force scope on exit. An explicit clear differs from inheritance.
`--no-decryption-keys` selects an empty key set and rejects simultaneous key material.
`--key-profile-ref <opaque-id>` carries an optional nonsecret profile revision.

Android channel-map imports copy referenced `keys_hex_csv`, `keys_dec_csv` and
`-k`/`-K`/`-G`/`--dmr-tg-key-csv` option files into a private bundle and rewrite their
paths. Target CSV imports also copy channel maps (including their nested companions)
and P25 band plans. Desktop imports continue resolving existing relative paths beside
the original document; Android document references use the host's document importer.

When a companion cannot be resolved, the Qt import sheet offers stored library files
of the required kind, with name and row count, and **Choose a file…**. Decimal and hex
keys are separate kinds. Basename matches rank first but never silently link a file:
only a sole candidate with a matching basename is visibly preselected, and the user
can change it before confirming. Multiple candidates require an explicit choice;
same-name files of the wrong kind are explained in the sheet. Nested references and
roles have separate selection identities even when their names match. Each slot
names its expected kind alongside the reference path, so two roles using the same
path remain distinguishable. Library choices announce their plain name and checked
state to accessibility services.

If a desktop file pick identifies a stored library entry of the wrong kind, that
slot shows the expected and found kinds and becomes unresolved. The sheet stays
open with the other selections intact, allowing another pick. Android SAF
`content://` selections have no canonical local path and cannot reach this library
metadata check; document copying and bundle validation still use the host importer.

Selecting a library entry passes its private stored path to the existing bundle
stager. At each host-copy boundary, the stager converts absolute local paths to
`file://` URLs for Android compatibility; existing `file://` and SAF `content://`
references and the opaque selection identities remain unchanged.
The stager copies the file into the new bundle revision, rewriting nested paths;
it neither adopts nor moves the library entry. These independent copies let either
library entry be removed without breaking the other. The complete bundle is validated
before registration or replacing an existing map; a rejected update retains the prior
files. Removing the bundle removes its owned copies. Target replacement and removal
remain unavailable during an active or transitioning decoder session.

`CsvImportFlow.pick()` (primary picker) and `begin()` (already selected document)
start an import. `finished(result)` fires exactly once when it succeeds, fails, or
is cancelled. Cancel, Back/Escape, scrim dismissal, and primary picker rejection
all complete with `{ok:false, error:"cancelled"}`. Rejecting a companion picker
clears only that slot and returns to the still-active sheet: it does **not** finish
the import. The user can choose again or cancel the sheet. Abandoning the flow leaves
the library unchanged. The Home scan-list shortcut changes the draft to CSV mode only
after successful import, so cancellation preserves the editor's prior draft and
clean/dirty state. Cancelling the Home shortcut leaves its new editor in entries
mode with its initial clean fingerprint; closing it does not ask to discard changes.

The file library also accepts **DMR key mappings** and **Vertex keystreams** as
separate kinds. Vertex files are used by standalone vendor profiles, not by the
standard scoped key set. See [decryption profiles](decryption-profiles.md).
