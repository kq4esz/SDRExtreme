# Third-Party Notices

This file summarizes third-party, vendored, and upstream-derived material known
in the source tree. Per-file headers and embedded notices remain authoritative
for file-specific license/provenance details.

## Vendored Libraries

- **ezpwd Reed-Solomon** (`src/third_party/ezpwd`, target `dsd-neo_ezpwd`; Hard Consulting Corporation; vendored from https://github.com/arancormonk/ezpwd-reed-solomon) - GPL-3.0-or-later; `rs_base` is LGPL-2.1-or-later (per upstream notice). LGPL text: `src/third_party/ezpwd/lesser.txt` (installed as `share/doc/dsd-neo/licenses/ezpwd-LGPL-2.1-or-later.txt`).
- **PFFFT** (target `dsd-neo_pffft`; Julien Pommier and contributors, based on FFTPACKv4 by Dr Paul Swarztrauber/NCAR) — downloaded from <https://github.com/arancormonk/pffft> at the immutable revision and SHA-256 in `tools/ci-dependency-pins.env`. The BSD-like license and compiled backend notices are installed as `share/doc/dsd-neo/licenses/pffft-LICENSE.txt` and `pffft-NOTICES.txt`. See `docs/dependencies.md` for offline builds and updates.
- **Tiny AES** (`src/crypto/crypt-aes.c`) - Unlicense/public domain; original upstream https://github.com/kokke/tiny-AES-c.
- **librtlsdr** (`android/third_party/librtlsdr`; osmocom, https://gitea.osmocom.org/sdr/rtl-sdr) - GPL-2.0-or-later;
  license text `android/third_party/librtlsdr/COPYING`. Trimmed v2.0.3 snapshot (library sources only) built into the
  Android app; carries one project patch adding `rtlsdr_open_fd()` for USB-OTG descriptor injection, kept as
  `android/third_party/patches/0001-librtlsdr-add-rtlsdr_open_fd.patch`. Not part of any non-Android build.
- **libusb** (`android/third_party/libusb`; https://github.com/libusb/libusb) - LGPL-2.1-or-later; license text
  `android/third_party/libusb/COPYING`. Trimmed v1.0.30 snapshot (the `linux_usbfs` backend and POSIX shims upstream's
  own Android build uses) built into the Android app. Not part of any non-Android build.

## Bundled Assets

- **IBM Plex Sans / IBM Plex Mono** (`src/ui/qt/fonts/IBMPlexSans-*.ttf`, `src/ui/qt/fonts/IBMPlexMono-*.ttf`;
  (c) IBM Corp., https://github.com/IBM/plex) - SIL Open Font License 1.1. License text
  `src/ui/qt/fonts/IBMPlex-LICENSE.txt` (installed as `share/doc/dsd-neo/licenses/ibm-plex-OFL-1.1.txt`).
  Compiled into the Qt Quick frontend's resource bundle, so it is redistributed by any build with `DSD_ENABLE_QT_UI=ON`
  — today that is the Android app.

## Embedded Provenance-Bearing Code

- **EDACS-FME / EDACS helpers** (`src/protocol/edacs/edacs-fme.c`) - source comments credit EDACS-FM, sp5wwp/ledacs,
  XTAL Labs, Robert Morelos-Zaragoza, LWVMOBILE, and ilyacodes.
- **Binary BCH v3.1** (`src/protocol/edacs/edacs-bch3.c`) - source comments credit Robert Morelos-Zaragoza and note
  portions from Simon Rockliff's Reed-Solomon code. The file also contains a non-commercial/commercial-permission notice
  that should be reviewed before changing its license characterization.
- **NXDN OP25-derived tables and helpers** (`include/dsd-neo/protocol/nxdn/nxdn_const.h`,
  `src/protocol/nxdn/nxdn_frame.c`, `src/protocol/nxdn/nxdn_deperm.c`) - source comments credit Osmocom OP25, Max H.
  Parke, and Mathias Weyland under GPL notices.
- **NXDN convolution helper** (`src/protocol/nxdn/nxdn_convolution.c`) - source comments credit Jonathan Naylor,
  Edouard Griffiths, and Louis HERVE under a GPL-2.0-or-later notice.
- **FEC helpers outside `src/third_party`** (`include/dsd-neo/fec/ReedSolomon.hpp`,
  `include/dsd-neo/fec/Golay24.hpp`, `src/fec/fec.c`) - source comments credit Simon Rockliff, Hank Wallace, and
  Edouard Griffiths respectively.
- **OP25/GNU Radio/Yair Linn-derived DSP and protocol snippets** (`src/dsp/costas.cpp`, `src/dsp/ted.cpp`,
  `src/protocol/p25/phase2/p25p2_frame.c`, `src/protocol/p25/p25_crc.c`) - source comments identify OP25, GNU Radio,
  KA1RBI, Free Software Foundation, and Yair Linn provenance for selected algorithms/tables.
- **Miscellaneous embedded provenance** (`src/core/util/dsd_misc.c`, `src/io/control/dsd_rigctl.c`,
  `src/protocol/ysf/ysf.c`) - source comments identify OP25, libM17, NedSimao/FilteringLibrary, gqrx-scanner, DSDcc,
  gr-ysf, and Munaut-derived code or ideas.

## Test Fixtures

- **I/Q decode fixtures** (`tests/fixtures/iq/*.iq`) - derived from public sample recordings, converted to cu8
  baseband by `tools/build_iq_fixtures.py`, which records the upstream URL for every fixture.
  - Most fixtures derive from user-contributed off-air sample recordings hosted on the
    [Signal Identification Wiki](https://www.sigidwiki.com/). The wiki does not publish an explicit content license
    (its MediaWiki rights metadata is empty), so no CC compatibility claim is made; the fixtures are short excerpts
    of off-air radio transmissions redistributed for testing with attribution to Signal Identification Wiki
    contributors, with per-fixture upstream URLs recorded in `tools/build_iq_fixtures.py`. If upstream licensing is
    clarified, update this entry.
  - The `provoice` fixture is the wiki's `Provoice.mp3` receiver-audio recording of one ProVoice transmission,
    redistributed on the same terms. `tools/build_iq_fixtures.py` records its URL and pinned SHA-256, and undoes the
    receiver's de-emphasis before converting it to baseband.
  - The analog fixtures `am_airband_real`, `nfm_ctcss_real`, `nfm_squelch_real_a` and `nfm_squelch_real_b` are short
    excerpts of the wiki's `AM_IQ.zip`, `IQ_CTCSS_example_482768kHz_IQ.zip` and `Unknown_NFM_squelch_IQ.zip` I/Q
    recordings, redistributed on the same terms as the other wiki-derived fixtures. `tools/build_iq_fixtures.py`
    records their URLs and pinned SHA-256 hashes. `nfm_tone_synth` and `nfm_adjacent_synth` are generated by that
    script from a seeded tone and noise and contain no recorded material.
  - The `nxdn48_after_retune` fixture is the `nxdn48` excerpt of the wiki's `NXDN_IQ.zip`, preceded by a lead-in cut
    from the seeded `noise_floor` fixture (no recorded material) and joined byte for byte by
    `tools/build_iq_fixtures.py`. It is redistributed on the same terms as `nxdn48`.
  - The `ysf_gap` fixture is a sidecar alone, written by `tools/build_iq_fixtures.py`, that replays the `ysf` data
    file with a capture gap added. It carries no recorded material of its own.
  - The M17 fixture derives from `samples/m17_clear_voice_wav.wav` in [lwvmobile/m17-fme](https://github.com/lwvmobile/m17-fme),
    licensed GPL.
  - The `dmr_t3_ras_cc` fixture derives from a DSDPlus raw discriminator capture of a DMR Tier III control
    channel contributed by the reporter of [issue #348](https://github.com/arancormonk/dsd-neo/issues/348)
    for regression testing (short excerpt of off-air control-channel signalling, no voice content; the source
    file has no stable URL, so `tools/build_iq_fixtures.py` pins its SHA-256 under `LOCAL_SOURCES`).

The project `LICENSE`, `COPYRIGHT`, and this notice file are installed with binary packages. Installed third-party
license texts currently include the ezpwd and pinned PFFFT notices under `share/doc/dsd-neo/licenses/`, plus the
IBM Plex font notice for builds that bundle the Qt frontend and the librtlsdr/libusb notices for the Android package.

Native Airspy support links libairspy (BSD-3-Clause for `airspy.c`, `airspy.h`, and `airspy_commands.h`; MIT for `filters.h` and `iqconverter_*`), from https://github.com/airspy/airspyone_host. Android library sources, Windows overlay builds, and AppImage builds are pinned to `bd15be38e91ebaa3e0bebb1e320255bde4ccf059`; the upstream notice, prefixed with the copyright lines from the source headers, is retained in `android/third_party/libairspy/LICENSE` and distributed as `licenses/libairspy-LICENSE.txt`.
