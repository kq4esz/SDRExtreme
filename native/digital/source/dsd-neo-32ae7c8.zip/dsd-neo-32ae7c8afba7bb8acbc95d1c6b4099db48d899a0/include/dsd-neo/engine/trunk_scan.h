// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Engine-owned single-tuner trunk scan coordinator.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_ENGINE_TRUNK_SCAN_H_
#define DSD_NEO_INCLUDE_DSD_NEO_ENGINE_TRUNK_SCAN_H_

#include <dsd-neo/core/key_set.h>
#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>
#include <dsd-neo/runtime/scan_mode.h>
#include <dsd-neo/runtime/scan_options.h>
#include <dsd-neo/runtime/scan_row_edit.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#else
/* C needs a file-scope tag before the parameter declaration below. */
struct p25_bandplan_row;
#endif

enum {
    DSD_TRUNK_SCAN_DWELL_MIN_MS = 250,
    DSD_TRUNK_SCAN_DWELL_MAX_MS = 600000,
    DSD_TRUNK_SCAN_IDLE_DWELL_DEFAULT_MS = 3000,
    DSD_TRUNK_SCAN_ACTIVITY_HOLD_DEFAULT_MS = 1200,
    /* Ceiling on the memory the parked-target snapshots may occupy. See
     * dsd_trunk_scan_max_targets(). */
    DSD_TRUNK_SCAN_TARGET_MEMORY_BUDGET_BYTES = 256 * 1024 * 1024,
};

/**
 * @brief Largest number of trunk scan targets that fits in the target memory budget.
 *
 * There is no target-count limit as such: each parked target reserves a snapshot of decoder
 * state, and the cap is DSD_TRUNK_SCAN_TARGET_MEMORY_BUDGET_BYTES divided by that snapshot's
 * size, so it tracks the struct instead of being a constant that goes stale. Enforced while the
 * targets CSV is parsed - an unbounded row count would otherwise ask for a single allocation
 * large enough that Linux overcommit grants it and the process is killed while faulting the
 * pages in, rather than failing with a message the operator can act on.
 */
size_t dsd_trunk_scan_max_targets(void);

typedef enum {
    DSD_TRUNK_SCAN_TARGET_P25_TRUNK = 0,
    DSD_TRUNK_SCAN_TARGET_DMR_TRUNK = 1,
    DSD_TRUNK_SCAN_TARGET_DMR_CONVENTIONAL = 2,
    DSD_TRUNK_SCAN_TARGET_NXDN_TRUNK = 3,
    DSD_TRUNK_SCAN_TARGET_NXDN_CONVENTIONAL = 4,
    DSD_TRUNK_SCAN_TARGET_NXDN48_CONVENTIONAL = 5,
    DSD_TRUNK_SCAN_TARGET_NXDN48_TRUNK = 6,
    DSD_TRUNK_SCAN_TARGET_P25_CONVENTIONAL = 7,
    /** One analog NFM channel (issue #526): carrier activity, no frames, keys or symbol clock. */
    DSD_TRUNK_SCAN_TARGET_NFM_CONVENTIONAL = 8,
    /** One analog AM channel (issue #526): the AM monitor (-fM), otherwise as an nfm-conventional target. */
    DSD_TRUNK_SCAN_TARGET_AM_CONVENTIONAL = 9,
} dsd_trunk_scan_target_type;

typedef enum {
    DSD_TRUNK_SCAN_MODULATION_UNSET = DSD_SCAN_MODULATION_INHERIT,
    DSD_TRUNK_SCAN_MODULATION_AUTO = DSD_SCAN_MODULATION_AUTO,
    DSD_TRUNK_SCAN_MODULATION_C4FM = DSD_SCAN_MODULATION_C4FM,
    DSD_TRUNK_SCAN_MODULATION_CQPSK = DSD_SCAN_MODULATION_CQPSK,
    DSD_TRUNK_SCAN_MODULATION_GFSK = DSD_SCAN_MODULATION_GFSK,
} dsd_trunk_scan_modulation;

typedef struct {
    char id[64];
    dsd_trunk_scan_target_type type;
    uint32_t frequency_hz;
    char chan_csv[1024];
    /* Per-target key files, resolved relative to the targets CSV at parse time.
     * Loaded into the target's key set at init; empty means the global keys. */
    char keys_hex_csv[1024];
    char keys_dec_csv[1024];
    /* Parsed direct `-H`/`-b` equivalents. Kept as fixed metadata so raw key
     * text never survives parsing or reaches a diagnostic. */
    dsd_key_scalars single_key_scalars;
    uint8_t single_keys_present;
    /** Nonsecret, validated per-target overrides. Group path is relative-resolved at import. */
    dsd_scan_option_values row_options;
    /* Per-target P25 band plan CSV (trunk targets only), resolved relative to the targets CSV at
     * parse time and loaded into the target's own band-plan store at init; empty means none. */
    char p25_bandplan_csv[1024];
    int dwell_ms;
    int activity_hold_ms;
    int dwell_is_set;
    int activity_hold_is_set;
    unsigned int csv_row;
    dsd_trunk_scan_modulation modulation;
    int rtl_gain_is_set;
    int rtl_gain_db;
} dsd_trunk_scan_target;

typedef struct {
    dsd_trunk_scan_target* targets; /**< Owned heap array; NULL when empty. */
    size_t count;
    size_t capacity;
} dsd_trunk_scan_target_list;

/**
 * @brief Release a target list's owned storage and zero it.
 *
 * The list returned by a successful dsd_trunk_scan_load_targets_csv() owns its
 * `targets` array; callers must reset it once the coordinator has copied the
 * targets out. A failed load never writes `*out`, so nothing to reset there.
 *
 * @param list List to clear; NULL is ignored.
 */
void dsd_trunk_scan_target_list_reset(dsd_trunk_scan_target_list* list);

int dsd_trunk_scan_load_targets_csv(const char* path, const dsd_opts* opts, dsd_trunk_scan_target_list* out, char* err,
                                    size_t err_sz);

/** Shared lexical splitter for target import/relocation. Modifies line in place. */
int dsd_trunk_scan_split_csv_fields(char* line, char** fields, size_t max_fields, size_t* out_count);

int dsd_engine_trunk_scan_init(dsd_opts* opts, dsd_state* state, char* err, size_t err_sz);
void dsd_engine_trunk_scan_shutdown(dsd_opts* opts, dsd_state* state);
void dsd_engine_trunk_scan_tick(dsd_opts* opts, dsd_state* state);
/** Maintain the visit clock and report expiry without tuning or releasing the call.
 * Decoder thread only; the caller must hold the SM guard. Used by long protocol loops
 * to unwind before the next coordinator tick performs the advance. */
int dsd_engine_trunk_scan_visit_expired(const dsd_opts* opts, dsd_state* state);
/**
 * @brief Apply an operator scan control (a dsd_trunk_scan_control_op from
 * runtime/trunk_scan_hooks.h) to the parked target list.
 *
 * Hold pauses the idle dwell on the active target without stopping its state machine;
 * avoid flags the active target for the session and moves on; clear puts every avoided
 * target back; advance moves now. Returns the codes documented beside the op enum.
 * Decoder thread only: avoid and advance retune.
 */
int dsd_engine_trunk_scan_control(dsd_opts* opts, dsd_state* state, int op);
void* dsd_engine_trunk_scan_active_p25_ctx(void);
void* dsd_engine_trunk_scan_active_dmr_ctx(void);
/**
 * @brief Channel-map path of the currently parked scan target, or NULL when it has none.
 *
 * Backs the `active_chan_csv` runtime hook: per-target `chan_csv` files are imported through
 * throwaway options, so this is the only place the path survives for protocol code to name.
 */
const char* dsd_engine_trunk_scan_active_chan_csv(const dsd_state* state);
/**
 * @brief Report decoded conventional activity so the active target keeps its park.
 *
 * Each entry point only acts when the target currently parked belongs to its own
 * conventional family; anything else (including trunk targets, or trunk scan not
 * being installed) is ignored. The NXDN entry point serves both NXDN conventional
 * types: NXDN48 and NXDN96 share a sync word and every decoded element, so the
 * protocol layer cannot tell them apart and must not have to. The call identity is run through the global
 * talkgroup policy, and only an allowed call refreshes the target's
 * activity hold, so allow/block lists, private-call, data-call and
 * encrypted-call tuning controls all apply to the park decision.
 *
 * Callers must pass identity that has already cleared the protocol's own
 * FEC/CRC gate: an unverified header would park the coordinator on noise.
 *
 * @param opts       Decoder options (policy and hold controls).
 * @param state      Decoder state owning the scan coordinator.
 * @param target     Destination talkgroup (group call) or destination unit (private call).
 * @param source     Source unit id, or 0 when unknown.
 * @param is_private Non-zero for a private/individual call, zero for a group call.
 * @param encrypted  Non-zero when the call is encrypted; pass the protocol's corroborated
 *                   classification, not a single frame's raw cipher field.
 * @param data_call  Non-zero for data traffic rather than voice.
 */
void dsd_engine_trunk_scan_dmr_conventional_activity(const dsd_opts* opts, const dsd_state* state, uint32_t target,
                                                     uint32_t source, int is_private, int encrypted, int data_call);
/** @copydoc dsd_engine_trunk_scan_dmr_conventional_activity */
void dsd_engine_trunk_scan_nxdn_conventional_activity(const dsd_opts* opts, const dsd_state* state, uint32_t target,
                                                      uint32_t source, int is_private, int encrypted, int data_call);
/** @copydoc dsd_engine_trunk_scan_dmr_conventional_activity */
void dsd_engine_trunk_scan_p25_conventional_activity(const dsd_opts* opts, const dsd_state* state, uint32_t target,
                                                     uint32_t source, int is_private, int encrypted, int data_call);
size_t dsd_engine_trunk_scan_target_count(const dsd_state* state);
/**
 * @brief Whether the scan running now visits an analog row that runs the configured NFM width (issue #526).
 *
 * True while the trunk-scan coordinator holds an nfm-conventional target, or the conventional -Y scanner runs a channel
 * map with an nfm row, that sets no --nfm-bandwidth-hz of its own: such a row runs the configured NFM width whenever it
 * is on air, on any session. The width controls, a loaded config, the RTL DSP bandwidth and Input > Switch source hold
 * the configured width to the DSP rate while this holds, as they do under -fA, so a row is not skipped for a width an
 * edit made while another row was on air. Read-only; 0 when @p opts or @p state is NULL.
 */
int dsd_engine_scan_runs_configured_nfm_width(const dsd_opts* opts, const dsd_state* state);
/**
 * @brief dsd_engine_scan_runs_configured_nfm_width() for the configured AM width: whether the scan running now visits
 * an am row or am-conventional target that sets no --am-bandwidth-hz of its own, and so runs the configured AM width
 * (its 6 kHz default when none is set, which a DSP rate holds too) whenever it is on air, on any session (issue #526).
 */
int dsd_engine_scan_runs_configured_am_width(const dsd_opts* opts, const dsd_state* state);
/**
 * @brief Whether anything in the session runs received-tone detection, so the configured tone policy can act (#527).
 *
 * Under the trunk-scan coordinator, an nfm-conventional target: every target runs its own type's mode, never the
 * configured one. Otherwise dsd_channel_modes_conventional_hear_tones(): on the conventional -Y scanner with a channel
 * map, a row that runs the FM monitor (dsd_channel_modes_hear_tones()); without rows, the configured decode mode is the
 * analog FM monitor (dsd_scan_mode_configured_fm_monitor()). A --trunk-scan session whose coordinator has not started
 * counts as hearing them: its targets are judged when the scan starts. Read-only; 0 when @p opts or @p state is NULL.
 */
int dsd_engine_scan_hears_tones(const dsd_opts* opts, const dsd_state* state);
/**
 * @brief The tuner autogain a target without its own manual gain runs: the session's at scan start, or the latest
 * live edit (dsd_engine_trunk_scan_set_configured_autogain()). Returns 1 with @p out_on set, 0 when no trunk scan runs
 * or the value was never known (@p out_on 0).
 */
int dsd_engine_trunk_scan_saved_tuner_autogain(const dsd_state* state, int* out_on);
/**
 * @brief Make @p gain the tuner gain the trunk scan restores at every target switch and at shutdown (issue #518
 * follow-up: a live gain edit used to be put back to the scan-start value at the next switch).
 *
 * The configured gain is what targets without an rtl_gain column run; a target with its own keeps it while it is on
 * air, as a row's --squelch-db overrides the configured squelch. Publishes the result for the frontends. Decoder
 * thread, with the P25 SM tick guard held: the watchdog's control-channel returns read the configured gain and
 * autogain through the retune gain profile under it.
 *
 * @return 1 when the gain is in force now (written to opts->rtl_gain_value), 0 when the parked target's own rtl_gain
 *         overrides it (@p opts unchanged), -1 when no trunk scan runs (nothing changed).
 */
int dsd_engine_trunk_scan_set_configured_gain(dsd_opts* opts, dsd_state* state, int gain);
/**
 * @brief Make @p on the tuner autogain the trunk scan restores at every retune (the same rule as the configured gain).
 * Decoder thread, with the P25 SM tick guard held.
 *
 * @return 1 when it is in force now (the gain in force is AGC; the caller applies it to the stream), 0 when a manual
 *         gain suspends it (every trunk-scan retune forces the supervisor off then), -1 when no trunk scan runs.
 */
int dsd_engine_trunk_scan_set_configured_autogain(const dsd_opts* opts, dsd_state* state, int on);
int dsd_engine_trunk_scan_active_p25_cqpsk_request(const dsd_state* state, int* out_enable);
/**
 * @brief Symbol rate of the parked four-level GFSK scan target, or 0 when there is none.
 *
 * The tuning layer cannot derive this on its own. `state->rf_mod == 2` is true for both the
 * 4800 sym/s targets (DMR, NXDN96) and the 2400 sym/s ones (NXDN48), and `state->sps_hunt_idx`
 * is rotated by the no-sync SPS hunt, so a plain `-T` session can be sitting on the 2400 profile
 * during dead air. The coordinator's own target type is the only stable answer.
 *
 * The tuning layer treats a non-zero answer as authoritative for the RTL chain regardless of
 * `rf_mod`, so a target whose modulation column is empty under a global `-m` lock still gets its
 * own symbol rate and channel filter.
 *
 * @param state Decoder state owning the scan coordinator.
 * @return 2400 or 4800 for a parked GFSK-family target; 0 when trunk scan is not installed or the
 *         parked target is P25.
 */
int dsd_engine_trunk_scan_active_gfsk_symbol_rate(const dsd_state* state);
/**
 * @brief Non-zero while the parked target is p25-trunk or p25-conventional.
 *
 * Identifies the demodulation class, not ownership of a P25 trunk state machine.
 * Returns 0 when no target is parked for the supplied decoder state.
 */
int dsd_engine_trunk_scan_active_is_p25_class(const dsd_state* state);
/**
 * @brief Append the parked targets' learned IDEN entries as band-plan rows.
 *
 * Walks every target except the active one (whose tables are live in @p state and are the
 * caller's to collect) and appends each parked snapshot's ready FDMA/TDMA entries through
 * dsd_p25_bandplan_append_tables(), which de-duplicates by identifier, table and WACN/SYS.
 * Serves the band-plan export; a session without a coordinator returns @p count unchanged.
 *
 * @param state Decoder state owning the scan coordinator.
 * @param rows  Row array of at least @p cap entries.
 * @param count Rows already in @p rows.
 * @param cap   Capacity of @p rows.
 * @return The new row count.
 */
int dsd_engine_trunk_scan_append_p25_idens(const dsd_state* state, struct p25_bandplan_row* rows, int count, int cap);

/**
 * @brief Edit one field of a target's own settings for the rest of the session ("this channel", issue #518).
 *
 * @p session and @p target_id name the target as the frontends saw it (dsd_state::scan_row_session and
 * trunk_scan_active_id): an edit opened on one coordinator never lands on the next, and one that outlives the visit
 * still reaches the target it named. @p field is one DSD_SCAN_ROW_FIELD_*, which the target's type must take
 * (dsd_scan_row_edit_fields(): the gain only on an RTL-family input other than an Airspy); @p action a
 * dsd_scan_row_edit_action, with @p value for SET. A width the published DSP rate cannot filter is refused, as it would
 * skip the target at every visit.
 *
 * A parked target runs the edit at once: its scope takes the merged options again (the squelch reaches the demod), and
 * @p out says whether the caller must hand the front end the new width (publish_width) or reopen the stream for the
 * new gain (restart_gain), and holds the edit before this one for dsd_engine_trunk_scan_restore_target_edit() should
 * that fail. Any other target runs it from its next visit. Nothing is written to the list or saved.
 *
 * Takes the P25 SM tick guard (try-enter) around the change, so the caller must not hold it; decoder thread only. A
 * width or gain edit of the parked target waits for its retune to land: only the request the caller makes after this
 * call can be put back should the front end refuse it.
 *
 * @return a dsd_scan_row_edit_status: APPLIED, STORED, REFUSED (with @p out->err), STALE, UNAVAILABLE (no trunk scan)
 * or BUSY (the guard was held, or the parked target is still retuning; nothing changed).
 */
int dsd_engine_trunk_scan_edit_target(dsd_opts* opts, dsd_state* state, uint32_t session, const char* target_id,
                                      uint32_t field, int action, const dsd_scan_row_edit_value* value,
                                      dsd_scan_row_edit_result* out);

/**
 * @brief Put the @p fields (DSD_SCAN_ROW_FIELD_*) of a target's session edit back to those of @p edit (the previous
 * one dsd_engine_trunk_scan_edit_target() returned), keeping its other fields as they are now, and apply it as that
 * call does. For a caller whose follow-up -- the width request, the stream restart -- failed: an edit of another field
 * made since stays. Same session and thread rules, no checks of the values beyond those, but the P25 SM tick guard is
 * waited for (entered, not tried): the rollback must not be left undone because a watchdog tick held it.
 */
int dsd_engine_trunk_scan_restore_target_edit(dsd_opts* opts, dsd_state* state, uint32_t session, const char* target_id,
                                              uint32_t fields, const dsd_scan_row_edit* edit,
                                              dsd_scan_row_edit_result* out);

/**
 * @brief dsd_engine_trunk_scan_restore_target_edit() for a caller that holds the P25 SM tick guard already: the
 * rollback of a gain inside the one hold that covers a failed stream reopen and the recovery start after it.
 */
int dsd_engine_trunk_scan_restore_target_edit_locked(dsd_opts* opts, dsd_state* state, uint32_t session,
                                                     const char* target_id, uint32_t fields,
                                                     const dsd_scan_row_edit* edit, dsd_scan_row_edit_result* out);

#ifdef __cplusplus
}
#endif

#endif /* DSD_NEO_INCLUDE_DSD_NEO_ENGINE_TRUNK_SCAN_H_ */
