// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Voice-gated scan for -Y and --trunk-scan (issue #381).
 *
 * The -Y scanner used to treat any sync as activity, so a repeater streaming
 * DMR IDLE/CSBK parked the scan indefinitely. This gate steps on unless decoded
 * voice frames hold it: qualify = window after sync in which voice must appear
 * or the scan moves on; hold = time to stay after the last voice frame.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_ENGINE_SCAN_VOICE_GATE_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_ENGINE_SCAN_VOICE_GATE_H_H

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Policy-allowed decoded voice media visible to a scanner tick. */
typedef struct {
    /** Newest media time on an active call with media latched, or < 0 when none. */
    double active_media_m;
    /** Newest media time on an active or ended call, or < 0 when none. */
    double retained_media_m;
} dsd_scan_voice_probe_result;

/**
 * Probe both call slots for policy-allowed decoded voice media.
 *
 * The returned timestamps are raw call-state anchors and may predate the current
 * scanner visit or hold window. Callers must apply their own freshness bound.
 * Both result fields are initialized to -1. Returns -1 for invalid arguments,
 * 0 when no qualifying media exists, and 1 when retained media exists.
 */
int dsd_scan_voice_probe(const dsd_opts* opts, const dsd_state* state, dsd_scan_voice_probe_result* out);

/**
 * Non-zero while the analog channel on air has carrier (issue #526), the activity that holds an analog
 * row in both scanners.
 *
 * It reads the received-tone tap's carrier (dsd_state::analog_rx, issue #522) rather than deriving one:
 * the squelch open over the monitor audio, above the tap's level floor, held through its 200 ms hangover,
 * at every input rate, and dropped at every reset the tap makes -- a retune, a stream generation or
 * receive-profile change, a stream pause -- and while a retune is unresolved, so a block that straddles a
 * retune never counts for the new channel (dsd_analog_rx_carrier_open_now()). So it holds only
 * while the analog monitor runs, FM or AM (dsd_analog_monitor_tap_active(), issue #524), never on a
 * publication past its stale_after_ms, never while a digital carrier is flagged (dsd_state::carrier) and
 * never while a trunking state machine owns the channel. Whether audio is played has no part in it: -o null
 * or a muted UI still holds the row. Under the CTCSS/DCS receive policy (issue #527) it is only the traffic the policy
 * passes (dsd_analog_tone_gate_passes(): no policy in force, or ALLOWED), the one rule the monitor's -Y hangtime stamp
 * follows too: traffic it rejected holds nothing, and traffic it is still checking is no activity either -- it holds
 * the row while it lasts through its verdict (dsd_scan_analog_tone_gate()), but restarts no hold and leaves no tail.
 * Read-only and null-safe.
 */
int dsd_scan_analog_carrier_open(const dsd_opts* opts, const dsd_state* state);

/**
 * The CTCSS/DCS receive policy's verdict (dsd_analog_tone_gate, issue #527) on the analog carrier on air: OFF when
 * there is no such carrier by the rules of dsd_scan_analog_carrier_open() before the verdict is weighed (or no policy
 * is in force), else the verdict the tap published for it (dsd_analog_tone_gate_in_force()). PENDING holds a row while
 * its carrier lasts, with the stay reason DSD_SCAN_STAY_TONE_PENDING and no window: the -Y step holds it at every
 * pass, whatever -t says, and the trunk-scan tick holds it with the idle dwell running as on a quiet channel (armed at
 * the check's first tick past an activity or operator hold that had disarmed it). It is no activity: the monitor
 * stamps no hangtime anchor for it and the tick restarts no activity hold, so a check its carrier ends before a verdict
 * leaves the -t, hold and dwell clocks where they were, and short bursts the policy never passed cannot park a
 * scanner. The policy's window bounds each check. ALLOWED is activity like any carrier, and the -Y step holds it at
 * every pass too: the monitor stamps the anchor only as a block ends, and a verdict that turns ALLOWED part-way
 * through one would otherwise meet an anchor from before the check. REJECTED holds nothing and, on the scanner's next
 * pass, advances it unless the operator holds the row or there is nowhere else to go. Read-only and null-safe.
 */
int dsd_scan_analog_tone_gate(const dsd_opts* opts, const dsd_state* state);

/**
 * Non-zero when traffic the CTCSS/DCS receive policy rejected (issue #527) has ended on the channel on air with no
 * carrier heard since, by the rules of dsd_scan_analog_carrier_open() before the verdict is weighed: its carrier's
 * hangover ran out, or its input paused (dsd_analog_rx_rejection_ended_now()), or an input that stopped delivering left
 * a rejection published past its deadline. A scanner whose pass or tick comes after such traffic ended releases the
 * row as it would have while the carrier lasted, when there is somewhere else to go, rather than waiting out a window
 * still running from before it: -t since the row landed or since traffic the policy passed (earlier traffic, or this
 * traffic before a blocked or unlisted value was confirmed), or a trunk-scan activity hold. Read-only and null-safe.
 */
int dsd_scan_analog_tone_rejection_ended(const dsd_opts* opts, const dsd_state* state);

/**
 * Non-zero when the operator's talkgroup hold is on a call that is being followed right now:
 * some slot carries an active, non-data call whose target -- after policy remapping -- is the
 * held talkgroup, or, on a private call, whose source is.
 *
 * Both scanners suspend the per-visit limit while this holds (issue #507), so the limit cannot
 * cut short the very call the hold exists to follow, and a fresh limit starts once that call
 * ends. Read-only and null-safe.
 */
int dsd_scan_tg_hold_call_active(const dsd_state* state);

/**
 * Restart the per-visit gate memory on a scan hop, and open the visit the per-visit cap
 * measures (issue #507): this is the one place a successful park stamps that anchor.
 */
void dsd_scan_voice_gate_note_retune(dsd_state* state, double now_m);

/** Per-frame tick while parked on a -Y row; a no-op unless scanner_mode is on. The gate never owns an analog
 * row (the analog FM monitor): there is no decoded voice to wait for, and the row's carrier holds it under the
 * hangtime rule instead, so a global --scan-voice-only does not block analog rows. */
void dsd_scan_voice_gate_tick(const dsd_opts* opts, dsd_state* state, int synced, double now_m);

/** Non-zero when the gate has a visit anchor and owns the scanner's step timing. */
int dsd_scan_voice_gate_owns_step(const dsd_opts* opts, const dsd_state* state);

/** Non-zero when the gate says the -Y visit is over and the scan should step. */
int dsd_scan_voice_gate_should_step(const dsd_opts* opts, const dsd_state* state, double now_m);

/** Take the scan timing publication back down (scan off, shutdown, between targets). */
void dsd_scan_timing_clear(dsd_state* state);

/** Publish one scan timing report for the row on air (issue #508). */
void dsd_scan_timing_publish(dsd_state* state, const dsd_scan_timing_publication* report);

/**
 * Publish the -Y scanner's stay reason and step deadline. A no-op unless
 * scanner_mode == 1 && trunk_scan_enabled != 1: under --trunk-scan the coordinator owns
 * the publication, exactly as it owns scan_voice_gate_phase.
 *
 * The legacy hangtime rule anchors on the wall-clock last_cc_sync_time (which NXDN can
 * stamp two seconds into the future), so the publisher takes both clocks, sampled
 * together, to express that anchor as a monotonic deadline the renderer can difference.
 */
void dsd_engine_scan_y_timing_tick(const dsd_opts* opts, dsd_state* state, double now_m, double now_wall_s);

/**
 * Maintain the -Y per-visit anchor (issue #507). A no-op unless
 * scanner_mode == 1 && trunk_scan_enabled != 1: under --trunk-scan the coordinator keeps its
 * own per-target anchor.
 *
 * Separate from dsd_scan_voice_gate_tick() because the cap applies with the voice gate off as
 * well as on, and that tick returns early there. Parking and operator hold release also reset
 * the anchor; sync and voice activity never touch it. While the limit cannot count -- suspended
 * by a hold, or with no second row to advance to -- it remembers the suspension. The first
 * eligible tick starts a fresh interval even if input stalled since the last suspended tick.
 */
void dsd_engine_scan_visit_tick(const dsd_opts* opts, dsd_state* state, double now_m);

/**
 * The monotonic instant the visit on air runs out, or < 0 when no cap is counting: the cap is
 * disabled, no visit is anchored, a hold suspends it, a row transaction is outstanding, the row on
 * air has changed since the last tick, or there is no second eligible row to advance to. Pure; the
 * predicate and the publication both read it so the countdown on screen is the one that fires.
 */
double dsd_engine_scan_visit_deadline_m(const dsd_opts* opts, const dsd_state* state);

/** Non-zero when the per-visit cap says the -Y visit is over and the scan must advance. */
int dsd_engine_scan_visit_expired(const dsd_opts* opts, const dsd_state* state, double now_m);

#ifdef __cplusplus
}
#endif

#endif /* DSD_NEO_INCLUDE_DSD_NEO_ENGINE_SCAN_VOICE_GATE_H_H */
