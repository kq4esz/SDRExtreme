// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_PLATFORM_FILE_COMPAT_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_PLATFORM_FILE_COMPAT_H_H

/**
 * @file
 * @brief Cross-platform file descriptor compatibility for DSD-neo.
 */

#include <dsd-neo/platform/platform.h>
#include <stdio.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

#if DSD_PLATFORM_WIN_NATIVE
#include <sys/stat.h>
typedef struct _stat dsd_stat_t;
#else
#include <sys/stat.h>
typedef struct stat dsd_stat_t;
#endif

/* ssize_t definition for Windows */
#if DSD_PLATFORM_WIN_NATIVE && !defined(_SSIZE_T_DEFINED)
#include <BaseTsd.h>
typedef SSIZE_T ssize_t;
#define _SSIZE_T_DEFINED
#endif

/**
 * @brief Get file descriptor from FILE stream.
 *
 * @param fp    FILE pointer.
 * @return File descriptor, or -1 on error.
 */
int dsd_fileno(FILE* fp);

/**
 * @brief Check if file descriptor refers to a terminal.
 *
 * @param fd    File descriptor.
 * @return Non-zero if terminal, 0 otherwise.
 */
int dsd_isatty(int fd);

/**
 * @brief Disable text translation on an open descriptor used for raw bytes.
 *
 * Selects binary mode on Windows; POSIX descriptors already carry raw bytes.
 * Flush any buffered stdio output before changing its descriptor's mode.
 *
 * @param fd    Open file descriptor.
 * @return 0 on success, -1 on error with errno set.
 */
int dsd_set_binary_mode(int fd);

/**
 * @brief Duplicate a file descriptor.
 *
 * @param oldfd     File descriptor to duplicate.
 * @return New file descriptor, or -1 on error.
 */
int dsd_dup(int oldfd);

/**
 * @brief Duplicate a file descriptor to a specific number.
 *
 * @param oldfd     Source file descriptor.
 * @param newfd     Target file descriptor number.
 * @return newfd on success, -1 on error.
 */
int dsd_dup2(int oldfd, int newfd);

/**
 * @brief Close a file descriptor.
 *
 * @param fd    File descriptor to close.
 * @return 0 on success, -1 on error.
 */
int dsd_close(int fd);

/**
 * @brief Flush file data to disk.
 *
 * @param fd    File descriptor.
 * @return 0 on success, -1 on error.
 */
int dsd_fsync(int fd);

/**
 * @brief Get file status.
 *
 * @param fd    File descriptor.
 * @param st    Output stat struct.
 * @return 0 on success, -1 on error.
 */
int dsd_fstat(int fd, dsd_stat_t* st);

/**
 * @brief Get file status for a path.
 *
 * @param path  File path.
 * @param st    Output stat struct.
 * @return 0 on success, -1 on error.
 */
int dsd_stat_path(const char* path, dsd_stat_t* st);

/**
 * @brief Check whether file status describes a regular file.
 *
 * @param st    File status struct.
 * @return Non-zero if regular file, 0 otherwise.
 */
int dsd_stat_is_regular(const dsd_stat_t* st);

/**
 * @brief Set file permissions (best effort on Windows).
 *
 * @param fd    File descriptor.
 * @param mode  POSIX permission bits.
 * @return 0 on success, -1 on error.
 */
int dsd_fchmod(int fd, int mode);

/**
 * @brief Open a file for writing/appending with owner-only permissions when created.
 *
 * Supports standard write/append modes such as "w", "wb", "a", "ab", "w+",
 * and "a+". Read-only modes fall back to normal fopen semantics. An "x" after a
 * write mode ("wx", "wbx") creates the file exclusively, as C11 fopen() does:
 * the open fails with EEXIST when @p path already exists, which is left untouched.
 *
 * @param path  File path.
 * @param mode  fopen-compatible mode string.
 * @return FILE stream, or NULL on error.
 */
FILE* dsd_fopen_private(const char* path, const char* mode);

/**
 * @brief dsd_fopen_private(), also reporting whether it opened @p path.
 *
 * A write mode creates or empties the file once its descriptor opens, before the stream over that descriptor is made,
 * so an open whose stream cannot be made (fdopen() out of memory) returns NULL with the file already created or
 * emptied. A caller that must know whether it touched the file (the I/Q capture writer, which reports writing over an
 * earlier recording) reads @p out_opened. A read mode opens as fopen() does.
 *
 * @param path       File path.
 * @param mode       fopen-compatible mode string.
 * @param out_opened Set to 1 once @p path was opened, whether or not the stream over it was then made, and 0
 *                   otherwise. May be NULL.
 * @return FILE stream, or NULL on error.
 */
FILE* dsd_fopen_private_ex(const char* path, const char* mode, int* out_opened);

/**
 * @brief Create a private temporary sibling file for atomic replacement.
 *
 * The temporary file is created in the same directory as @p final_path with
 * owner-only permissions and exclusive creation. On success, @p tmp_path
 * receives the created file path and the returned stream owns the descriptor.
 *
 * @param final_path     Destination path that will later be replaced.
 * @param tmp_path       Output buffer for the created temporary path.
 * @param tmp_path_size  Output buffer size.
 * @param mode           fopen-compatible write mode such as "w" or "wb".
 * @return FILE stream, or NULL on error with errno set.
 */
FILE* dsd_fopen_private_temp_for_replace(const char* final_path, char* tmp_path, size_t tmp_path_size,
                                         const char* mode);

/**
 * @brief Atomically replace a destination path with a sibling temporary file.
 *
 * @param tmp_path    Existing temporary file created in the destination directory.
 * @param final_path  Destination path to replace.
 * @return 0 on success, -1 on error with errno set.
 */
int dsd_replace_file_with_temp(const char* tmp_path, const char* final_path);

/**
 * @brief Rename @p from to @p to unless @p to already exists.
 *
 * Never replaces an existing @p to: the call fails with EEXIST and leaves both files as they were. The rename is
 * atomic where the platform and filesystem offer a no-replace rename (Linux renameat2(RENAME_NOREPLACE), macOS
 * renamex_np(RENAME_EXCL), a hard link then an unlink on other POSIX systems; Windows' rename() refuses an existing
 * name). On a POSIX filesystem that supports neither (no no-replace rename, no hard links) it claims @p to with an
 * exclusive create and renames onto that claim: @p to briefly exists as an empty file, and only a process that deletes
 * the claim in between can still be replaced.
 *
 * @param from              Existing file.
 * @param to                New name, in the same directory as @p from.
 * @param out_source_left   Optional. Set to 1 when @p to was created but @p from could not be removed afterwards (a
 *                          hard link whose unlink failed): the call still succeeds, and @p from names the same file.
 *                          Set to 0 otherwise.
 * @return 0 on success, -1 on error with errno set (EEXIST when @p to exists).
 */
int dsd_rename_noreplace(const char* from, const char* to, int* out_source_left);

/**
 * @brief Resolve a user-supplied local file name to an existing file in the current directory.
 *
 * The requested name must be a bare file name: no path separators, absolute
 * paths, empty names, or ".." segments. On success, @p out receives the
 * directory entry name for the existing regular file.
 *
 * @param requested  User-supplied bare file name.
 * @param out        Output buffer.
 * @param out_size   Output buffer size.
 * @return 0 on success, -1 on error with errno set.
 */
int dsd_resolve_existing_local_file(const char* requested, char* out, size_t out_size);

/**
 * @brief Open an existing regular file from the current directory by bare local file name.
 *
 * The requested name must be a bare file name: no path separators, absolute
 * paths, empty names, or ".." segments. On success, @p out receives the
 * directory entry name used to open the file.
 *
 * @param requested  User-supplied bare file name.
 * @param out        Output buffer.
 * @param out_size   Output buffer size.
 * @return Read stream for the existing regular file, or NULL with errno set.
 */
FILE* dsd_fopen_existing_local_file(const char* requested, char* out, size_t out_size);

/**
 * @brief Open an existing regular file by path for read-only access.
 *
 * The final path is opened without following symlinks/reparse points where the
 * platform exposes that protection. Only read modes such as "r" and "rb" are
 * accepted.
 *
 * @param path  Existing file path.
 * @param mode  fopen-compatible read-only mode.
 * @return Read stream for the existing regular file, or NULL with errno set.
 */
FILE* dsd_fopen_existing_regular_file(const char* path, const char* mode);

/**
 * @brief Callback invoked once per regular file found by dsd_dir_list().
 *
 * @param name  Directory entry name with no path prefix.
 * @param user  Opaque pointer forwarded from the caller.
 * @return 0 to continue the walk, non-zero to stop it.
 */
typedef int (*dsd_dir_list_cb)(const char* name, void* user);

/**
 * @brief List the regular files in a directory.
 *
 * Entries are reported by bare name with no path prefix; "." and ".." and every
 * subdirectory are skipped. The order is whatever the platform returns, so a
 * caller that needs a stable order must sort. Stopping the walk by returning
 * non-zero from @p cb is not an error.
 *
 * @param dir   Directory to walk.
 * @param cb    Per-entry callback.
 * @param user  Opaque pointer forwarded to @p cb.
 * @return 0 when the directory was walked to the end or the callback stopped it;
 *         -1 with errno set when the directory cannot be opened or reading it
 *         failed part-way (entries already reported are not retracted).
 */
int dsd_dir_list(const char* dir, dsd_dir_list_cb cb, void* user);

/**
 * @brief Read from a file descriptor.
 *
 * @param fd        File descriptor.
 * @param buf       Output buffer.
 * @param count     Bytes to read.
 * @return Number of bytes read, 0 on EOF, or -1 on error.
 */
ssize_t dsd_read(int fd, void* buf, size_t count);

/**
 * @brief Write to a file descriptor.
 *
 * @param fd        File descriptor.
 * @param buf       Data buffer.
 * @param count     Bytes to write.
 * @return Number of bytes written, or -1 on error.
 */
ssize_t dsd_write(int fd, const void* buf, size_t count);

/** What dsd_write_frames() did with a buffer. */
typedef enum {
    DSD_WRITE_FRAMES_OK = 0,      /**< every byte was written */
    DSD_WRITE_FRAMES_WOULD_BLOCK, /**< the descriptor would block at a frame boundary: the frames before it went out,
                                       the rest of the buffer did not, and the stream is still frame-aligned */
    DSD_WRITE_FRAMES_ERROR,       /**< a write failed (errno says why); the stream may end in the middle of a frame */
} dsd_write_frames_status;

/**
 * @brief Write a buffer of whole sample frames to a file descriptor.
 *
 * Retries interrupted writes and continues after short counts. On a non-blocking descriptor that is full it never
 * spins: at a frame boundary it returns DSD_WRITE_FRAMES_WOULD_BLOCK at once, and only when a short count left part of
 * a frame written does it wait (a bounded time) for room to finish that frame. A write that returns 0 is an error
 * (EIO). A reader that has gone away is an error (EPIPE) and never raises SIGPIPE: on POSIX the signal the write
 * raises in the calling thread is blocked and consumed (macOS: the descriptor's no-SIGPIPE flag is set), leaving the
 * process's signal dispositions and any SIGPIPE already pending alone.
 *
 * @param fd          File descriptor.
 * @param buf         Data buffer.
 * @param bytes       Bytes to write.
 * @param frame_bytes Bytes per sample frame (0 is taken as 1).
 * @param written     Optional; receives the bytes written.
 * @return What happened; errno is set when the result is DSD_WRITE_FRAMES_ERROR.
 */
dsd_write_frames_status dsd_write_frames(int fd, const void* buf, size_t bytes, size_t frame_bytes, size_t* written);

/**
 * @brief Get the null device path for this platform.
 *
 * @return "/dev/null" on POSIX, "NUL" on Windows.
 */
const char* dsd_null_device(void);

/**
 * @brief Standard file descriptor numbers.
 */
#if DSD_PLATFORM_WIN_NATIVE
#include <io.h>
#define DSD_STDIN_FILENO  0
#define DSD_STDOUT_FILENO 1
#define DSD_STDERR_FILENO 2
#else
#include <unistd.h>
#define DSD_STDIN_FILENO  STDIN_FILENO
#define DSD_STDOUT_FILENO STDOUT_FILENO
#define DSD_STDERR_FILENO STDERR_FILENO
#endif

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_PLATFORM_FILE_COMPAT_H_H */
