// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Compact decoder status for surfaces outside the single-consumer snapshot.
 *
 * The snapshot accessors in @ref snapshot.h are single-consumer: exactly one thread may
 * call them, and on Android that thread is Qt's. The foreground service needs the same
 * facts with no Qt in the picture -- Android can destroy the Activity while the engine
 * keeps decoding, which is precisely when the notification is the only visible surface.
 *
 * So this is a second, far smaller publication: a fixed-size POD copied out under a short
 * mutex, safe to read from any thread and any number of them. It is fed by the telemetry
 * hooks, which run on the decode thread for the whole session (see
 * dsd_app_frontend_runtime_start()), so it keeps updating with no frontend attached.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_APP_CONTROL_NOTIFICATION_STATUS_H_
#define DSD_NEO_INCLUDE_DSD_NEO_APP_CONTROL_NOTIFICATION_STATUS_H_

#include <dsd-neo/app_control/call_view.h>
#include <dsd-neo/core/call_state.h>
#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

enum {
    /** Longest label dsd_synctype_to_string() returns, plus room and a NUL. */
    DSD_APP_NOTIFICATION_PROTOCOL_SIZE = 24,
};

typedef struct {
    uint64_t revision; /**< Advances on every publish; 0 before the first. */
    /** dsd_synctype_to_string() for the current sync, or "" when NONE/UNKNOWN. */
    char protocol[DSD_APP_NOTIFICATION_PROTOCOL_SIZE];
    int64_t vc_freq_hz;     /**< Voice channel; 0 when none resolves. */
    int64_t cc_freq_hz;     /**< Control channel; 0 when none is known. */
    int64_t center_freq_hz; /**< Tuner centre; 0 unless the input is a radio. */
    uint8_t radio_input;    /**< Non-zero for RTL-family input only. */
    uint8_t trunking;       /**< opts->trunk_enable. */
    uint8_t trunk_tuned;    /**< opts->trunk_is_tuned. */
    dsd_app_slot_call slots[DSD_CALL_STATE_SLOT_COUNT];
    /**
     * @brief Index into @c slots of the call that should headline, or -1 for none.
     *
     * Carried rather than left to the reader: the notification has room for one call and
     * so does the Qt hero panel, and a reader deciding for itself is how the two came to
     * name different units at the same instant. See dsd_app_lead_slot().
     */
    int8_t lead_slot;
    /**
     * @brief The audible-audio stamp: when the decoder last emitted audio the app plays, in real-time monotonic
     * milliseconds, or 0 for none (see <dsd-neo/core/audio_activity.h>). The value is its own identity, so a reader
     * that sees it change knows new audio was heard.
     *
     * Not stored by the publishers: dsd_app_notification_publish_state() and dsd_app_notification_publish_opts() never
     * write it, and the published snapshot they fill leaves it 0. dsd_app_notification_get() reads it on every call,
     * whether anything has been published or not, together with @c audible_age_ms from one dsd_audio_activity_read(),
     * so the two always describe the same stamp; dsd_app_notification_encode() writes both into the record it encodes.
     * It stays 0 unless dsd_app_notification_encode() has armed the stamp.
     */
    uint64_t audible_stamp;
    /** Milliseconds since @c audible_stamp; -1 when there is none or it is older than DSD_AUDIO_ACTIVITY_MAX_AGE_MS. */
    int32_t audible_age_ms;
} dsd_app_notification_status;

/**
 * @brief Publish the state-derived half. Called on the decode thread.
 *
 * A no-op until something has called dsd_app_notification_get() at least once. Deriving
 * the record is not free -- the voice-channel chain copies the recent-activity snapshot
 * under the canonical call-state lock -- and these publishers hang off the telemetry
 * hook, which fires at protocol frame rate on the decode thread of every frontend. The
 * record's readers are the Android service and, while a client is connected, the JSON
 * API feed, so a run with no reader pays one atomic load.
 */
void dsd_app_notification_publish_state(const dsd_state* state);

/** @brief Publish the options-derived half. Called on the decode thread. Same gate. */
void dsd_app_notification_publish_opts(const dsd_opts* opts);

/**
 * @brief Copy the latest status out.
 *
 * Safe from any thread, and from any number of them concurrently -- unlike the snapshot
 * accessors. Zeroes @p out when nothing has been published yet, except for @c lead_slot,
 * which is left at its -1 "no slot" sentinel rather than at a zero that names slot 0, and
 * the audible-audio pair, which every call reads afresh (0 and -1 when there is none).
 *
 * Also arms the publishers, which stay dormant until a reader has asked once. The first
 * call therefore reports nothing on a session that is already decoding; the next one, a
 * poll interval later, has a record. It does not arm the audible-audio stamp; only
 * dsd_app_notification_encode() does.
 *
 * @return 1 when @p out holds a published status, 0 otherwise.
 */
int dsd_app_notification_get(dsd_app_notification_status* out);

/**
 * @brief Forget everything published, so the next get() reports nothing again.
 *
 * The published record is a module static and outlives the session that filled it. The
 * Android service starts its status poll before the engine reaches
 * dsd_app_frontend_runtime_start(), so without this a second session's first poll would
 * render the previous session's last call for as long as a poll interval.
 *
 * Clears the audible-audio stamp too (dsd_audio_activity_reset()), for the same reason;
 * it stays armed.
 *
 * Called from dsd_app_frontend_runtime_stop(). Safe from any thread.
 */
void dsd_app_notification_reset(void);

enum {
    /**
     * @brief Comfortably larger than any record the encoder produces.
     *
     * The worst case is less than 1400 bytes: the fixed header, its audible stamp up to
     * 20 digits, plus two slots each carrying a full-length @c name
     * (@ref DSD_APP_CALL_NAME_SIZE), @c tg_text and @c src_text alongside their numeric
     * fields. Rounded well past that, because a record that outgrows this buffer is not
     * truncated -- it is dropped, and the notification would silently stop updating.
     */
    DSD_APP_NOTIFICATION_RECORD_SIZE = 2048,
};

/**
 * @brief Encode the latest status as one versioned, tab-separated record.
 *
 * Version "v3", 33 fields: an 11-field header -- version, protocol, radio_input, trunking,
 * trunk_tuned, cc_freq_hz, vc_freq_hz, center_freq_hz, lead_slot, audible_stamp (unsigned
 * decimal), audible_age_ms (signed decimal, -1 for none) -- then 11 fields per slot:
 * state, name, tg_text, src_text, tg_id, enc, algid, kid, elapsed_ms, emergency, priority.
 * android/.../DecoderStatus.kt reads it; change both together, version included.
 *
 * One record per call so a reader cannot tear its view across fields. Text fields have
 * control characters replaced with spaces: they arrive from CSV imports and off the air,
 * and an embedded tab would invent a field and desynchronise everything after it.
 *
 * Arms the audible-audio stamp (dsd_audio_activity_arm()) whenever it is given a buffer,
 * even before anything has been published. Its one caller is the Android JNI accessor
 * nativeNotificationStatus(), from the decoder service's status poll and ScreenSupport's
 * synchronous samples, which makes it the stamp's one reader: desktop, CLI and API-only
 * sessions never turn the stamp on.
 *
 * @return Characters written excluding the NUL, or 0 when nothing is published, @p out is
 *         NULL, or @p out_size cannot hold the whole record. Never truncates -- a partial
 *         record is one a reader would happily parse as a shorter one.
 */
size_t dsd_app_notification_encode(char* out, size_t out_size);

#ifdef __cplusplus
}
#endif

#endif /* DSD_NEO_INCLUDE_DSD_NEO_APP_CONTROL_NOTIFICATION_STATUS_H_ */
