// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Common lightweight math utilities used across DSP modules.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_DSP_MATH_UTILS_H_
#define DSD_NEO_INCLUDE_DSD_NEO_DSP_MATH_UTILS_H_

#include <math.h>

/**
 * @brief Compute the greatest common divisor using the Euclidean algorithm.
 *
 * Handles negative inputs by using their absolute values. If both inputs are
 * zero, returns 1.
 *
 * @param a First integer.
 * @param b Second integer.
 * @return Greatest common divisor of |a| and |b|, or 1 if both are zero.
 */
static inline int
gcd_int(int a, int b) {
    if (a < 0) {
        a = -a;
    }
    if (b < 0) {
        b = -b;
    }
    while (b != 0) {
        int t = a % b;
        a = b;
        b = t;
    }
    return (a == 0) ? 1 : a;
}

/**
 * @brief Normalized sinc function.
 *
 * Computes sinc(x) = sin(pi*x)/(pi*x) with the special case sinc(0) = 1
 * implemented to avoid division by zero.
 *
 * @param x Input value.
 * @return Normalized sinc evaluated at x.
 */
static inline double
dsd_neo_sinc(double x) {
    if (x == 0.0) {
        return 1.0;
    }
    const double kPiLocal = 3.14159265358979323846;
    return sin(kPiLocal * x) / (kPiLocal * x);
}

#endif /* DSD_NEO_INCLUDE_DSD_NEO_DSP_MATH_UTILS_H_ */
