// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Runtime configuration API and environment documentation.
 *
 * Exposes typed configuration parsed from environment variables and accessors
 * to initialize and retrieve the immutable configuration.
 */

#ifndef DSD_NEO_RUNTIME_CONFIG_H
#define DSD_NEO_RUNTIME_CONFIG_H

#include <dsd-neo/core/airspy_config.h>
#include <dsd-neo/core/analog_tone.h>
#include <dsd-neo/platform/platform.h>

/* Include schema types first (before extern "C" for C++ compat) */
#include <dsd-neo/core/frontend_types.h>
#include <dsd-neo/runtime/config_schema.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Ensure dsd_opts type is visible to prototypes below */
#include <dsd-neo/core/opts_fwd.h>

/* Forward-declare decoder state for user-config helpers */
#include <dsd-neo/core/state_fwd.h>
#include <stdio.h>

/*
 * Runtime configuration (environment variables)
 *
 * Precedence: CLI/opts > environment > built-in defaults. This module parses
 * environment variables once (during open) and exposes a typed config.
 *
 * Realtime scheduling and CPU affinity
 * - DSD_NEO_RT_SCHED
 *     Enable best-effort realtime scheduling (SCHED_FIFO). Requires CAP_SYS_NICE or root.
 *     Values: "1" to enable, unset/other to disable. Default: disabled.
 * - DSD_NEO_RT_PRIO_USB | DSD_NEO_RT_PRIO_DONGLE | DSD_NEO_RT_PRIO_DEMOD
 *     Optional per-thread priorities (1..99, clamped to system limits). Used only if RT_SCHED=1.
 *     Example: export DSD_NEO_RT_PRIO_DEMOD=85
 * - DSD_NEO_CPU_USB | DSD_NEO_CPU_DONGLE | DSD_NEO_CPU_DEMOD
 *     Optional CPU core pinning for each thread. Integer CPU id (>=0). Example: export DSD_NEO_CPU_DEMOD=2
 *
 * Frontend/decimation/upsampling
 * Rational resampler (polyphase upfirdn L/M)
 * - DSD_NEO_RESAMP
 *     Target output sample rate in Hz (RTL/RTL-TCP). The RTL demod pipeline
 *     enables resampling by default to keep the output rate at ~48 kHz.
 *     Values: "off" or "0" to disable; integer Hz (e.g., 48000) to enable/override.
 *
 * CQPSK/OP25 Gardner timing recovery
 * - DSD_NEO_TED_GAIN
 *     Native-float CQPSK Gardner timing gain override (OP25-style; typical 0.01..0.1).
 *
 * Audio processing
 * These controls apply to monitor/non-symbol discriminator audio, not the
 * RTL-family digital FSK symbol stream.
 * - DSD_NEO_DEEMPH
 *     Post-demod deemphasis time constant. Applies only when the active demod preset enables deemphasis.
 *     Values: "75" (75µs, default), "50" (50µs), "nfm" (~750µs), "off" (disable).
 * - DSD_NEO_AUDIO_LPF
 *     Optional one-pole low-pass filter after demod. Approximate cutoff in Hz.
 *     Values: "off" or "0" to disable; integer (e.g., 3000, 5000) to enable. Default: off.
 *
 * Complex DC offset removal (baseband)
 * - DSD_NEO_IQ_DC_BLOCK
 *     Enable a leaky integrator high-pass on I/Q before FM discrimination: dc += (x-dc)>>k; y=x-dc.
 *     Values: 1 enable, 0 disable. Default: off.
 * - DSD_NEO_IQ_DC_SHIFT
 *     k in the above relation (10..14 typical, larger=k -> slower). Default: 11.
 *
 * Channel complex low-pass (RTL baseband)
 * - DSD_NEO_CHANNEL_LPF
 *     Optional complex low-pass on the RTL DSP baseband after half-band/CIC
 *     decimation. Intended to narrow out-of-channel noise when running at
 *     higher baseband rates (e.g., 24 kHz). By default this is enabled for
 *     RTL baseband rates >=20 kHz and uses a mode-appropriate passband.
 *     Values: 0 to force off; non-zero to force on regardless of mode.
 * Frontend tuning behavior
 * - DSD_NEO_DISABLE_FS4_SHIFT
 *     Disable +fs/4 capture frequency shift when offset_tuning is off. Useful for trunking where exact
 *     LO=center is desired by controller logic. Values: 1 to disable, else enabled. Default: 0 (enabled).
 * - DSD_NEO_OUTPUT_CLEAR_ON_RETUNE
 *     Force clearing the output audio ring on retune/hop. When disabled, audio drains naturally to avoid
 *     cutting off transmissions. Values: 1 to clear, else drain. Default: 0 (drain).
 * - DSD_NEO_RETUNE_DRAIN_MS
 *     Maximum time in milliseconds to wait for output ring to drain on retune/hop when not clearing.
 *     Default: 50ms.
 * - DSD_NEO_RETUNE_MUTE_MS
 *     Input sample mute duration around RTL retunes. This drops tuner-settling samples before they can train
 *     CQPSK recovery state. Values: integer 10..1000. Default: 120ms.
 *
 * TCP audio input
 * - DSD_NEO_TCPIN_BACKOFF_MS
 *     Backoff time (milliseconds) before attempting to reconnect when TCP audio input stalls/disconnects.
 *     Values: integer 50..5000. Default: 300.
 *
 * Symbol window debug/testing
 * - DSD_NEO_WINDOW_FREEZE
 *     Freeze symbol decision window selection and disable auto-centering nudges. Useful for A/B testing.
 *     Values: 1 freeze, else dynamic. Default: 0 (dynamic).
 *
 * Intra-block multithreading
 * - DSD_NEO_MT
 *     Enable a minimal 2-thread worker pool for certain CPU-heavy inner loops.
 *     Values: 1 enable, else disabled. Default: 0 (disabled).
 *
 * Debug/advanced knobs (centralized for maintainability)
 * - DSD_NEO_DEBUG_SYNC, DSD_NEO_DEBUG_CQPSK
 * - DSD_NEO_DEBUG_SYMBOL_TIMING
 *     Symbol-timing diagnostics on the decoder's own symbol grid.
 *     Values: 0 off, 1 one measurement line per accepted frame sync (sub-symbol offset,
 *     samplesPerSymbol, jitter), 2 additionally the per-sample +/-/O/X trace. Default: 0.
 * - DSD_NEO_CQPSK, DSD_NEO_CQPSK_SYNC_INV, DSD_NEO_CQPSK_SYNC_NEG
 * - DSD_NEO_FTZ_DAZ
 * - DSD_NEO_NO_BOOTSTRAP
 *
 * TCP/RTL/rigctl knobs
 * - DSD_NEO_TCP_* (autotune, waitall, stats, buffers, timeouts, prebuffer)
 * - DSD_NEO_RIGCTL_RCVTIMEO
 * - DSD_NEO_RTL_* and DSD_NEO_TUNER_* (direct/offset, xtal, testmode, autogain)
 * - DSD_NEO_AUTO_PPM* (carrier/error-based PPM correction)
 *
 * Protocol timers/holds
 * - DSD_NEO_P25_* and DSD_NEO_DMR_* (hangtimes, grace windows, holds, watchdog)
 *
 * Cache/path knobs
 * - DSD_NEO_CACHE_DIR, DSD_NEO_CC_CACHE
 */

/* Levels for DSD_NEO_DEBUG_SYMBOL_TIMING. */
enum {
    DSD_NEO_SYMBOL_TIMING_OFF = 0,
    DSD_NEO_SYMBOL_TIMING_SYNC_LINE = 1,
    DSD_NEO_SYMBOL_TIMING_TRACE = 2,
};

typedef enum DSD_ATTR_PACKED {
    DSD_NEO_DEEMPH_UNSET = 0,
    DSD_NEO_DEEMPH_OFF,
    DSD_NEO_DEEMPH_50,
    DSD_NEO_DEEMPH_75,
    DSD_NEO_DEEMPH_NFM
} dsdneoDeemphMode;

typedef struct dsdneoRuntimeConfig {
    /* Field order is chosen to minimize padding and keep clang-tidy's
     * clang-analyzer-optin.performance.Padding check quiet. */

    /* 8-byte aligned scalars */

    /* DMR / trunking timers */
    double dmr_hangtime_s;
    double dmr_grant_timeout_s;

    /* P25 timers/holds */
    double p25_hangtime_s;
    double p25_grant_timeout_s;
    double p25_cc_grace_s;
    double p25_vc_grace_s;
    double p25_mac_hold_s;
    double p25_voice_hold_s;

    /* P25 follower (UI-exposed) knobs */
    double p25_min_follow_dwell_s;
    double p25_grant_voice_to_s;
    double p25_force_release_extra_s;
    double p25_force_release_margin_s;
    double p25p1_err_hold_pct;
    double p25p1_err_hold_s;

    /* Input processing knobs */
    double input_warn_db;

    /* Supervisory tuner autogain knobs */
    double tuner_autogain_seed_db;
    double tuner_autogain_spec_snr_db;
    double tuner_autogain_inband_ratio;
    double tuner_autogain_up_step_db;

    /* Auto-PPM (carrier/tracking-based) knobs */
    double auto_ppm_snr_db;
    double auto_ppm_pwr_db;
    double auto_ppm_zerolock_ppm;

    /* CQPSK Costas loop (carrier recovery) */
    double costas_loop_bw;
    double costas_damping;

    /* DMR TIII tools (one-shot LCN calculator) */
    long dmr_t3_step_hz;
    long dmr_t3_cc_freq_hz;
    long dmr_t3_cc_lcn;
    long dmr_t3_start_lcn;

    /* Realtime scheduling and CPU affinity */
    int rt_sched_is_set;
    int rt_sched_enable;
    int rt_prio_usb_is_set;
    int rt_prio_usb;
    int rt_prio_dongle_is_set;
    int rt_prio_dongle;
    int rt_prio_demod_is_set;
    int rt_prio_demod;
    int cpu_usb_is_set;
    int cpu_usb;
    int cpu_dongle_is_set;
    int cpu_dongle;
    int cpu_demod_is_set;
    int cpu_demod;

    /* Bootstrap/system toggles */
    int ftz_daz_is_set;
    int ftz_daz_enable;
    int no_bootstrap_is_set;
    int no_bootstrap_enable;
    int no_signal_handlers_is_set;
    int no_signal_handlers_enable;

    /* Debug/tuning toggles */
    int debug_sync_is_set;
    int debug_sync_enable;
    int debug_cqpsk_is_set;
    int debug_cqpsk_enable;
    /* Level rather than a toggle: the two things this gates differ by orders of magnitude in
     * volume. 1 is one line per accepted sync; 2 adds a character per input sample. */
    int debug_symbol_timing_is_set;
    int debug_symbol_timing;

    /* CQPSK runtime toggles */
    int cqpsk_is_set;
    int cqpsk_enable;
    int cqpsk_sync_inv_is_set;
    int cqpsk_sync_inv;
    int cqpsk_sync_neg_is_set;
    int cqpsk_sync_neg;
    int sync_warmstart_is_set;
    int sync_warmstart_enable;

    /* DMR / trunking timers */
    int dmr_hangtime_is_set;
    int dmr_grant_timeout_is_set;

    /* P25 timers/holds */
    int p25_hangtime_is_set;
    int p25_grant_timeout_is_set;
    int p25_cc_grace_is_set;
    int p25_vc_grace_is_set;
    int p25_mac_hold_is_set;
    int p25_voice_hold_is_set;
    int p25_wd_ms_is_set;
    int p25_wd_ms;

    /* P25 follower (UI-exposed) knobs */
    int p25_min_follow_dwell_is_set;
    int p25_grant_voice_to_is_set;
    int p25_force_release_extra_is_set;
    int p25_force_release_margin_is_set;
    int p25p1_err_hold_pct_is_set;
    int p25p1_err_hold_s_is_set;

    /* P25 status-symbol AFC gate. Off by default because status-derived direction is advisory. */
    int p25_afc_status_gate_is_set;
    int p25_afc_status_gate_enable;

    /* P25 soft-decision recovery knobs. */
    int p25_soft_erasure_threshold_is_set;
    int p25_soft_erasure_threshold;
    int p25p1_soft_erasure_threshold_is_set;
    int p25p1_soft_erasure_threshold;
    int p25p2_soft_erasure_threshold_is_set;
    int p25p2_soft_erasure_threshold;
    int p25_soft_hard_override_is_set;
    int p25_soft_hard_override_enable;

    /* Input processing knobs */
    int input_volume_is_set;
    int input_volume_multiplier;
    int input_warn_db_is_set;

    /* DMR TIII tools (one-shot LCN calculator) */
    int dmr_t3_calc_csv_is_set;
    int dmr_t3_step_hz_is_set;
    int dmr_t3_cc_freq_is_set;
    int dmr_t3_cc_lcn_is_set;
    int dmr_t3_start_lcn_is_set;

    /* DMR TIII heuristic fill (opt-in) */
    int dmr_t3_heur_is_set;
    int dmr_t3_heur_enable;

    /* User config discovery */
    int config_path_is_set;

    /* Cache/path knobs */
    int cache_dir_is_set;
    int cc_cache_is_set;
    int cc_cache_enable;

    /* TCP/rigctl knobs */
    int tcp_bufsz_is_set;
    int tcp_bufsz_bytes;
    int tcp_waitall_is_set;
    int tcp_waitall_enable;
    int tcp_autotune_is_set;
    int tcp_autotune_enable;
    int tcp_stats_is_set;
    int tcp_stats_enable;
    int tcp_max_timeouts_is_set;
    int tcp_max_timeouts;
    int tcp_rcvbuf_is_set;
    int tcp_rcvbuf_bytes;
    int tcp_rcvtimeo_is_set;
    int tcp_rcvtimeo_ms;
    int rigctl_rcvtimeo_is_set;
    int rigctl_rcvtimeo_ms;
    int tcp_prebuf_ms_is_set;
    int tcp_prebuf_ms;

    /* RTL device/tuner knobs */
    int rtl_agc_is_set;
    int rtl_agc_enable;
    int rtl_direct_is_set;
    int rtl_direct_mode; /* 0=off, 1=I, 2=Q */
    int rtl_offset_tuning_is_set;
    int rtl_offset_tuning_enable;
    int rtl_xtal_hz_is_set;
    int rtl_xtal_hz;
    int tuner_xtal_hz_is_set;
    int tuner_xtal_hz;
    int rtl_testmode_is_set;
    int rtl_testmode_enable;
    int rtl_if_gains_is_set;
    int rtl_verify_is_set;
    int rtl_verify_enable;
    int rtl_verify_attempts_is_set;
    int rtl_verify_attempts;
    int tuner_bw_hz_is_set;
    int tuner_bw_hz; /* 0=auto */

    /* Supervisory tuner autogain knobs */
    int tuner_autogain_is_set;
    int tuner_autogain_enable;
    int tuner_autogain_probe_ms_is_set;
    int tuner_autogain_probe_ms;
    int tuner_autogain_seed_db_is_set;
    int tuner_autogain_spec_snr_db_is_set;
    int tuner_autogain_inband_ratio_is_set;
    int tuner_autogain_up_step_db_is_set;
    int tuner_autogain_up_persist_is_set;
    int tuner_autogain_up_persist;

    /* Auto-PPM (carrier/tracking-based) knobs */
    int auto_ppm_is_set;
    int auto_ppm_enable;
    int auto_ppm_snr_db_is_set;
    int auto_ppm_pwr_db_is_set;
    int auto_ppm_zerolock_ppm_is_set;
    int auto_ppm_zerolock_hz_is_set;
    int auto_ppm_zerolock_hz;
    int auto_ppm_freeze_is_set;
    int auto_ppm_freeze_enable;

    /* Rational resampler target */
    int resamp_is_set;    /* env seen */
    int resamp_disable;   /* env explicitly disables */
    int resamp_target_hz; /* >0 when enabled */

    /* CQPSK Costas loop (carrier recovery) */
    int costas_bw_is_set;
    int costas_damping_is_set;

    /* CQPSK Gardner timing recovery */
    int ted_gain_is_set;
    float ted_gain; /* CQPSK timing gain (typ 0.01-0.1) */

    /* Deemphasis */
    int deemph_is_set;
    dsdneoDeemphMode deemph_mode;

    /* Post-demod audio LPF */
    int audio_lpf_is_set;
    int audio_lpf_disable;
    int audio_lpf_cutoff_hz; /* >0 when enabled */

    /* Intra-block multithreading */
    int mt_is_set;
    int mt_enable;

    /* Frontend tuning behavior */
    int combine_rot_is_set;
    int combine_rot;
    int fs4_shift_disable_is_set;
    int fs4_shift_disable;
    int output_clear_on_retune_is_set;
    int output_clear_on_retune;
    int retune_drain_ms_is_set;
    int retune_drain_ms;
    int retune_mute_ms_is_set;
    int retune_mute_ms;

    /* TCP audio input */
    int tcpin_backoff_ms_is_set;
    int tcpin_backoff_ms;

    /* Symbol window debug/testing */
    int window_freeze_is_set;
    int window_freeze;

    /* Optional JSON emitter for P25 PDUs */
    int pdu_json_is_set;
    int pdu_json_enable;

    /* Optional SNR-based digital squelch (dB threshold). When set, frame sync
     * may skip expensive searches if estimated SNR is below this value.
     * Applies to relevant digital modes (e.g., P25 C4FM/CQPSK, GFSK family). */
    int snr_sql_is_set;
    int snr_sql_db; /* integer dB threshold */

    /* Complex DC blocker */
    int iq_dc_block_is_set;
    int iq_dc_block_enable;
    int iq_dc_shift_is_set;
    int iq_dc_shift;

    /* RTL channel complex low-pass (post-HB, complex baseband).
       Allows narrowing noise when running the RTL DSP baseband at higher
       sample rates (e.g., 24 kHz) without forcing it on for all modes. */
    int channel_lpf_is_set; /* env seen */
    int channel_lpf_enable; /* 0=off, 1=on */

    /* Inline strings */
    char dmr_t3_calc_csv[1024];
    char config_path[1024];
    char cache_dir[1024];
    char rtl_if_gains[1024];
}

dsdneoRuntimeConfig;

/* Parse environment once. Safe to call multiple times; last call wins. */
/**
 * @brief Parse environment variables and initialize the runtime configuration.
 *
 * Safe to call multiple times; the most recent call wins.
 *
 */
void dsd_neo_config_init(void);

/* Get immutable pointer to current runtime config. */
/**
 * @brief Get immutable pointer to the current runtime configuration, or NULL if
 * initialization has not been performed.
 *
 * Thread-safety: returns a process-wide immutable snapshot pointer. The
 * returned pointer remains valid for the process lifetime and may be shared
 * across threads. Call again to observe newer published snapshots.
 *
 * @return Pointer to config or NULL.
 */
const dsdneoRuntimeConfig* dsd_neo_get_config(void);

/**
 * @brief Apply runtime config values to opts/state.
 *
 * Intended to centralize env-derived operational knobs that are still stored in
 * `dsd_opts` / `dsd_state` fields.
 *
 * @param cfg Runtime config snapshot (may be NULL).
 * @param opts Decoder options to mutate (may be NULL).
 * @param state Decoder state to mutate (may be NULL).
 */
void dsd_apply_runtime_config_to_opts(const dsdneoRuntimeConfig* cfg, dsd_opts* opts, dsd_state* state);

/**
 * @brief Read an environment variable value via runtime wrappers.
 *
 * Intended for UI/debug tooling that needs generic env access without calling
 * `getenv()` directly outside runtime.
 *
 * @param name Environment variable name.
 * @return Pointer to value string (owned by the C library) or NULL if unset.
 */
const char* dsd_neo_env_get(const char* name);

/*
 * User configuration (INI file)
 *
 * Represents persisted user preferences loaded from or written to an INI-style
 * configuration file. This is a narrow subset of dsd_opts/dsd_state focusing
 * on stable, user-facing knobs (input, output, decode mode, trunking).
 */

typedef enum DSD_ATTR_PACKED {
    DSDCFG_INPUT_UNSET = 0,
    DSDCFG_INPUT_PULSE,
    DSDCFG_INPUT_RTL,
    DSDCFG_INPUT_RTLTCP,
    DSDCFG_INPUT_SOAPY,
    DSDCFG_INPUT_FILE,
    DSDCFG_INPUT_TCP,
    DSDCFG_INPUT_UDP,
    DSDCFG_INPUT_AIRSPY
} dsdneoUserInputSource;

typedef enum DSD_ATTR_PACKED {
    DSDCFG_OUTPUT_UNSET = 0,
    DSDCFG_OUTPUT_PULSE,
    DSDCFG_OUTPUT_NULL
} dsdneoUserOutputBackend;

typedef enum DSD_ATTR_PACKED {
    DSDCFG_MODE_UNSET = 0,
    DSDCFG_MODE_AUTO,
    DSDCFG_MODE_P25P1,
    DSDCFG_MODE_P25P2,
    DSDCFG_MODE_DMR,
    DSDCFG_MODE_NXDN48,
    DSDCFG_MODE_NXDN96,
    DSDCFG_MODE_X2TDMA,
    DSDCFG_MODE_YSF,
    DSDCFG_MODE_DSTAR,
    DSDCFG_MODE_EDACS_PV,
    DSDCFG_MODE_DPMR,
    DSDCFG_MODE_M17,
    DSDCFG_MODE_TDMA,
    DSDCFG_MODE_ANALOG,
    DSDCFG_MODE_DMR_MONO,
    DSDCFG_MODE_AM /* 16: the analog monitor with the AM envelope detector (IQ radio inputs only; issue #524) */
} dsdneoUserDecodeMode;

typedef enum DSD_ATTR_PACKED {
    DSDCFG_DEMOD_UNSET = 0,
    DSDCFG_DEMOD_AUTO,
    DSDCFG_DEMOD_C4FM,
    DSDCFG_DEMOD_GFSK,
    DSDCFG_DEMOD_QPSK
} dsdneoUserDemodPath;

typedef struct dsdneoUserConfig {
    /* [input] */
    int has_input;
    dsdneoUserInputSource input_source;
    char pulse_input[256];
    int rtl_device;
    char rtl_freq[64];
    int rtl_gain;
    int rtl_gain_is_set; /* distinguish explicit 0 (AGC) from omitted; see dsd_user_config_rtl_gain_is_set() */
    int rtl_ppm;
    int rtl_ppm_is_set; /* distinguish explicit 0 from omitted */
    int rtl_bw_khz;
    int rtl_sql;
    /* rtl_sql_mode (dsd_squelch_mode: 0 level, 1 auto, 2 noise) and rtl_sql_margin_db (the AUTO margin or the NOISE
       threshold, 3..30; 0 reads as the default 10). rtl_sql keeps the level under every mode. */
    int rtl_sql_mode;
    int rtl_sql_margin_db;
    /* 1 when the config names rtl_sql, rtl_sql_mode or rtl_sql_margin_db; a session's snapshot (radio or audio input)
       always sets it, so a save always writes them. A PCM source applies the keys a loaded config holds only then
       (issue #628): a config without them leaves its squelch alone. */
    int rtl_sql_is_set;
    int rtl_volume;   /* monitor/non-symbol gain; does not scale symbol streams */
    int rtl_auto_ppm; /* bool */
    char rtltcp_host[128];
    int rtltcp_port;
    dsd_airspy_config airspy;
    int airspy_invalid; /* Invalid airspy_serial; other invalid Airspy keys warn and keep prior values. */
    char soapy_args[256];
    char soapy_profile[32];
    char soapy_stream_format[16];
    char soapy_antenna[64];
    char soapy_clock[64];
    char soapy_settings[1024];
    char soapy_gains[512];
    int soapy_bandwidth_hz;
    int soapy_bandwidth_hz_is_set;
    char digital_resample[8]; /* auto|on|off */
    char file_path[1024];
    int file_sample_rate;
    char tcp_host[128];
    int tcp_port;
    char udp_addr[64];
    int udp_port;
    double input_warn_db;     /* low input-level advisory threshold in dBFS */
    int input_warn_db_is_set; /* distinguish explicit value from default */

    /* [output] */
    int has_output;
    dsdneoUserOutputBackend output_backend;
    char pulse_output[256];
    dsd_frontend_kind frontend_kind;
    int frontend_kind_is_set;

    /* [mode] */
    int has_mode;
    dsdneoUserDecodeMode decode_mode;
    int has_dmr_mono;
    int dmr_mono;
    /* Comma-separated extra UDP ports decoded as DMR LRRP; empty means not set, so a
       reload leaves a CLI-supplied list alone. Split by core/lrrp_ports.h at apply time. */
    char dmr_lrrp_ports[64];
    /* The EDACS EA/ESK variant. Applied AFTER the decode preset, which resets
       both: see apply_mode_config(). esk is a boolean over the single 0xA0 mask
       the four CLI variants and the RadioReference apply handler all use. */
    int has_edacs_variant;
    int edacs_ea;
    int edacs_esk;
    int has_demod;
    dsdneoUserDemodPath demod_path;

    /* [trunking] */
    int has_trunking;
    int trunk_enabled;
    char trunk_chan_csv[1024];
    char trunk_group_csv[1024];
    char trunk_p25_bandplan_csv[1024];
    char trunk_src_csv[1024]; // Source radio ID alias CSV path (labels only).
    int trunk_use_allow_list;
    int trunk_tune_group_calls;
    int trunk_tune_private_calls;
    int trunk_tune_data_calls;
    int trunk_tune_enc_calls;
    int trunk_persist_tg_lockouts;
    int trunk_scanner;
    int trunk_p25_prefer_candidates;
    int trunk_scan_voice_only;
    int trunk_scan_voice_qualify_ms;
    int trunk_scan_voice_hold_ms;
    int trunk_scan_max_visit_ms;

    /* [radioreference] */
    int has_radioreference;
    char rr_username[128];
    char rr_app_key[64];

    /* [trunk_scan] */
    int has_trunk_scan;
    int trunk_scan_enabled;
    char trunk_scan_targets_csv[1024];
    int trunk_scan_idle_dwell_ms;
    int trunk_scan_activity_hold_ms;

    /* [logging] */
    int has_logging;
    char event_log[1024];
    char frame_log[1024];
    char p25_sm_log[1024];

    /* [alerts] */
    int has_alerts;
    int call_alert_enabled; /* bool */
    int call_alert_events;  /* bitmask of dsd_call_alert_event_t values */

    /* [recording] */
    int has_recording;
    int per_call_wav; /* bool */
    char per_call_wav_dir[512];
    char static_wav_path[1024];
    char raw_wav_path[1024];
    int rdio_mode;
    int rdio_system_id;
    char rdio_api_url[1024];
    char rdio_api_key[256];
    int rdio_upload_timeout_ms;
    int rdio_upload_retries;
    int rdio_api_delete_after_upload; /* bool */

    /* [dsp] */
    int has_dsp;
    int iq_balance;  /* bool */
    int iq_dc_block; /* bool */

    /* [analog] (runtime/analog_channel.h). A width is the full RF channel-filter width in Hz; 0 is the kind's
       default (the key left out), which a save does not write. The loader refuses a value outside the kind's range
       and keeps the default. */
    int has_analog;
    int analog_nfm_bandwidth_hz;
    int analog_am_bandwidth_hz;
    /* The CTCSS/DCS receive policy (issue #527): tone_filter (dsd_tone_filter_mode, off when left out) and tone_list
       (the list, empty when left out; off keeps it). A refused list is left empty with analog_tone_list_refused set,
       and a refused tone_filter keeps the mode already loaded; either way the loader warns, and a list policy without
       a usable list is applied as off. */
    int analog_tone_filter;
    dsd_tone_set analog_tone_set;
    int analog_tone_list_refused;
} dsdneoUserConfig;

/**
 * @brief Resolve the platform-specific default config path (no I/O).
 *
 * Returns a pointer to an internal static buffer, or NULL when no reasonable
 * default can be determined.
 *
 * @return Pointer to default path string or NULL when unavailable.
 */
const char* dsd_user_config_default_path(void);

/**
 * @brief Resolve "<config dir>/imports" (no I/O).
 *
 * Derived by replacing the final component of dsd_user_config_default_path()
 * with "imports", using the platform separator. Recomputed on every call into
 * an internal static buffer: the value is not latched, so the pointer is only
 * valid until the next call.
 *
 * @return Pointer to the imports directory path, or NULL when no config path
 *         resolves (none of XDG_CONFIG_HOME/HOME, or APPDATA on Windows, is set).
 */
const char* dsd_user_imports_dir(void);

/**
 * @brief Create dsd_user_imports_dir() and its parents with mode 0700.
 *
 * Existing directories are accepted. The result is verified with stat, because
 * the underlying component walk reports nothing.
 *
 * @return 0 when the directory exists afterwards; -1 otherwise.
 */
int dsd_user_imports_dir_create(void);

/**
 * @brief Load a user config from the given path.
 *
 * On error (missing/unreadable file or parse error), cfg is zeroed.
 *
 * @param path Path to the INI file.
 * @param cfg [out] Destination user config.
 * @return 0 on success; non-zero on error.
 */
int dsd_user_config_load(const char* path, dsdneoUserConfig* cfg);

/**
 * @brief Atomically write cfg to the given path (for interactive save).
 *
 * @param path Destination path for the INI file.
 * @param cfg User config to persist.
 * @return 0 on success; non-zero on error.
 */
int dsd_user_config_save_atomic(const char* path, const dsdneoUserConfig* cfg);

/**
 * @brief Reset @p cfg to the state the INI loader starts every file from.
 *
 * Not all-zero: some keys default to on (group/private/encrypted call tuning,
 * persisted lockouts, ...), so a config built with dsd_user_config_apply_key()
 * must start here or an omitted key would read as "off". Safe on NULL.
 */
void dsd_user_config_init(dsdneoUserConfig* cfg);

/**
 * @brief Mark @p section present in @p cfg, as a `[section]` header in a file does.
 *
 * Some sections act even with no keys: an empty `[analog]` puts the analog
 * widths and tone policy back to their defaults. Call it for every section
 * before applying that section's keys with dsd_user_config_apply_key().
 *
 * @return 1 when @p cfg and @p section are valid and the name is shorter than
 *         64 bytes, 0 otherwise. An unknown section is accepted and ignored.
 */
int dsd_user_config_apply_section(dsdneoUserConfig* cfg, const char* section);

/**
 * @brief Apply a single user-config key/value pair in memory.
 *
 * The same `[section] key = value` mapping the INI loader uses, exposed so
 * embedders (the JSON API) can build a @ref dsdneoUserConfig from structured
 * input without a file. Start from dsd_user_config_init(). Section and key are
 * matched case-insensitively; @p value is the text an INI line would carry
 * after its quotes. An unknown section or key is ignored, as the loader
 * ignores it.
 *
 * @return 1 when @p cfg, @p section and @p key are valid handles and both
 *         names are shorter than 64 bytes, 0 otherwise.
 */
int dsd_user_config_apply_key(dsdneoUserConfig* cfg, const char* section, const char* key, const char* value);

/**
 * @brief Apply config-derived defaults to opts/state before env + CLI precedence.
 *
 * @param cfg User config to apply.
 * @param opts Decoder options to mutate.
 * @param state Decoder state to mutate.
 */
void dsd_apply_user_config_to_opts(const dsdneoUserConfig* cfg, dsd_opts* opts, dsd_state* state);

/**
 * @brief The radio input spec the config's [input] sets, without applying anything.
 *
 * What dsd_apply_user_config_to_opts() writes to opts->audio_in_dev for an `rtl` source with `rtl_freq`, an `rtltcp`
 * source with `rtltcp_host` ("rtl:dev:freq:gain:ppm:bw:sql:vol", "rtltcp:host:port[:freq:...]"), a `soapy` source
 * ("soapy" or "soapy:<soapy_args>") or an `airspy` source ("airspy"), with the values the config leaves out taken from
 * @p opts as the apply takes them. A caller compares it with the running input to know whether the apply reopens the
 * device, and which kind of device then sets the rate.
 *
 * @return 0 when the config sets such a spec (written to @p out), -1 when its [input] leaves the input spec alone or
 *         sets a non-radio input (or on bad arguments).
 */
int dsd_user_config_radio_input_spec(const dsdneoUserConfig* cfg, const dsd_opts* opts, char* out, size_t out_size);

/**
 * @brief Whether @p cfg names a tuner gain: an `rtl_gain` key that was read (0 included, which is AGC), or a nonzero
 * gain set in code. An omitted gain leaves the gain the session runs.
 */
static inline int
dsd_user_config_rtl_gain_is_set(const dsdneoUserConfig* cfg) {
    return cfg && (cfg->rtl_gain_is_set || cfg->rtl_gain != 0);
}

/**
 * @brief Apply config defaults before CLI parsing without activating file-rate timing yet.
 *
 * Bootstrap uses this to stage config-backed input/output defaults first, then
 * let CLI overrides settle before any file-input sample-rate side effects are
 * committed into decoder timing.
 *
 * @param cfg User config to apply.
 * @param opts Decoder options to mutate.
 * @param state Decoder state to mutate.
 */
void dsd_apply_user_config_to_opts_pre_cli(const dsdneoUserConfig* cfg, dsd_opts* opts, dsd_state* state);

/**
 * @brief Finalize config-file input sample-rate defaults after CLI parsing.
 *
 * Applies the configured file sample rate only when the config-file input
 * still survived CLI parsing for this run.
 *
 * @param cfg User config to finalize.
 * @param opts Decoder options to mutate.
 * @param state Decoder state to mutate.
 */
void dsd_finalize_user_config_file_input_after_cli(const dsdneoUserConfig* cfg, dsd_opts* opts, dsd_state* state);

/**
 * @brief Snapshot current opts/state into a user config (for save/print).
 *
 * @param opts Decoder options to read.
 * @param state Decoder state to read.
 * @param cfg [out] Destination user config snapshot.
 */
void dsd_snapshot_opts_to_user_config(const dsd_opts* opts, const dsd_state* state, dsdneoUserConfig* cfg);

/**
 * @brief Render a user config as INI to the given stream (stdout/stderr/file).
 *
 * @param cfg User config to render.
 * @param stream Output stream (stdout/stderr/file).
 */
void dsd_user_config_render_ini(const dsdneoUserConfig* cfg, FILE* stream);

/**
 * @brief Render a commented config template with all options and defaults.
 *
 * Generates a fully-commented INI file showing all available configuration
 * keys with their descriptions, types, and default values.
 *
 * @param stream Output stream (stdout/file).
 */
void dsd_user_config_render_template(FILE* stream);

/**
 * @brief Expand shell-like variables in a path string.
 *
 * Expands:
 *   ~       -> $HOME or platform home directory
 *   $VAR    -> environment variable VAR
 *   ${VAR}  -> environment variable VAR (braced form)
 *
 * Missing variables expand to empty string (no error).
 *
 * @param input Input path with possible variables.
 * @param output Output buffer for expanded path.
 * @param output_size Size of output buffer.
 * @return 0 on success; -1 on truncation or error.
 */
int dsd_config_expand_path(const char* input, char* output, size_t output_size);

/**
 * @brief Load a user config with optional profile overlay.
 *
 * Loads the base configuration from the INI file. If profile_name is non-NULL,
 * the named [profile.NAME] section is applied on top of the base config.
 *
 * Profile sections use dotted key syntax: section.key = value
 *
 * @param path Path to INI file.
 * @param profile_name Profile name (NULL for base config only).
 * @param cfg [out] Destination user config.
 * @return 0 on success; non-zero on error.
 */
int dsd_user_config_load_profile(const char* path, const char* profile_name, dsdneoUserConfig* cfg);

/**
 * @brief List available profile names in a config file.
 *
 * Scans the INI file for [profile.NAME] sections and returns the names.
 *
 * @param path Path to INI file.
 * @param names Output array of profile name pointers (caller provides).
 * @param names_buf Buffer to store profile name strings.
 * @param names_buf_size Size of names buffer.
 * @param max_names Maximum number of names to return.
 * @return Number of profiles found, or -1 on error.
 */
int dsd_user_config_list_profiles(const char* path, const char** names, char* names_buf, size_t names_buf_size,
                                  int max_names);

/**
 * @brief List available profile names from an already-open config stream.
 *
 * The stream must be readable and seekable. The parser rewinds it before use.
 *
 * @param stream Open INI stream.
 * @param names Output array of profile name pointers (caller provides).
 * @param names_buf Buffer to store profile name strings.
 * @param names_buf_size Size of names buffer.
 * @param max_names Maximum number of names to return.
 * @return Number of profiles found, or -1 on error.
 */
int dsd_user_config_list_profiles_stream(FILE* stream, const char** names, char* names_buf, size_t names_buf_size,
                                         int max_names);

/**
 * @brief Validate a config file and collect diagnostics.
 *
 * Parses the config file and checks for:
 *   - Unknown keys (warning)
 *   - Type mismatches (error)
 *   - Value range violations (warning)
 *
 * @param path Path to INI file.
 * @param diags [out] Diagnostic results (caller frees via dsdcfg_diags_free).
 * @return 0 if no errors; non-zero if errors present.
 */
int dsd_user_config_validate(const char* path, dsdcfg_diagnostics_t* diags);

#ifdef __cplusplus
}
#endif

#endif /* DSD_NEO_RUNTIME_CONFIG_H */
