// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief NXDN deinterleave/depunc/CRC and DCR helper APIs.
 *
 * Declares the NXDN helper APIs implemented in `src/protocol/nxdn/`.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_NXDN_NXDN_DEPERM_H_
#define DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_NXDN_NXDN_DEPERM_H_

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void nxdn_descramble_with_seed(uint8_t dibits[], int len, uint16_t seed);

void nxdn_deperm_facch_soft(dsd_opts* opts, dsd_state* state, uint8_t bits[144], const uint8_t reliab[144],
                            uint8_t frame);

void nxdn_deperm_sacch_soft(dsd_opts* opts, dsd_state* state, uint8_t bits[60], const uint8_t reliab[60]);

void nxdn_deperm_sacch2_soft(const dsd_opts* opts, dsd_state* state, uint8_t bits[60], const uint8_t reliab[60]);

void nxdn_deperm_pich_tch_soft(const dsd_opts* opts, dsd_state* state, uint8_t bits[144], const uint8_t reliab[144],
                               uint8_t lich);

void nxdn_deperm_facch2_udch_soft(dsd_opts* opts, dsd_state* state, uint8_t bits[348], const uint8_t reliab[348],
                                  uint8_t type);

void nxdn_deperm_facch3_udch2_soft(dsd_opts* opts, dsd_state* state, uint8_t bits[288], const uint8_t reliab[288],
                                   uint8_t type);

void nxdn_deperm_scch_soft(dsd_opts* opts, dsd_state* state, uint8_t bits[60], const uint8_t reliab[60],
                           uint8_t direction);

void nxdn_deperm_cac_soft(dsd_opts* opts, dsd_state* state, uint8_t bits[300], const uint8_t reliab[300]);

const char* nxdn_message_type_label(uint8_t message_type);
void nxdn_message_type(const dsd_opts* opts, dsd_state* state, uint8_t MessageType);

void NXDN_SACCH_Full_decode(dsd_opts* opts, dsd_state* state);

/**
 * @brief Decode an NXDN element content block and dispatch it by message type.
 *
 * Carries no CRC verdict of its own: callers pass CRC-verified content only. Every channel
 * decoder in `nxdn_deperm.c` checks its own CRC -- SACCH CRC-6, FACCH1 CRC-12, FACCH2/UDCH
 * CRC-15, CAC CRC-16, FACCH3/UDCH2 -- and reports it to `nxdn_confirm_note_evidence()` before
 * calling here, as does `NXDN_SACCH_Full_decode()` for an assembled superframe. The gate lives
 * in those callers; `nxdn_confirm_is_confirmed()` is the frame-level check at the sites that
 * publish a call or refresh a scan hold. The one deliberate exception is the synthesized
 * disconnect in `nxdn_vcall_run_enc_lockout()`, which fabricates a DISC element locally to drive
 * the same teardown a received one would.
 */
void NXDN_Elements_Content_decode(dsd_opts* opts, dsd_state* state, const uint8_t* ElementsContent,
                                  size_t elements_bits);
void NXDN_decode_scch(dsd_opts* opts, dsd_state* state, const uint8_t* Message, uint8_t direction);
void NXDN_decode_VCALL_ASSGN(dsd_opts* opts, dsd_state* state, const uint8_t* Message);

uint8_t crc6(const uint8_t buf[], int len);
uint16_t crc12f(const uint8_t buf[], int len);
uint16_t crc15(const uint8_t buf[], int len);
uint16_t crc16cac(const uint8_t buf[], int len);
uint8_t crc7_scch(const uint8_t bits[], int len);

/**
 * Read the 7-bit SCCH CRC check field from decoded trellis bits.
 */
uint8_t nxdn_scch_crc7_check_from_trellis(const uint8_t trellis_bits[32]);

/**
 * Read/compute FACCH-family decoded-bit CRC fields after Viterbi offset correction.
 */
uint16_t nxdn_facch_crc12_payload_from_trellis(const uint8_t trellis_bits[96]);
uint16_t nxdn_facch_crc12_check_from_trellis(const uint8_t trellis_bits[96]);

/**
 * Read/compute FACCH2/UDCH decoded-bit CRC fields after Viterbi offset correction.
 */
uint16_t nxdn_facch2_udch_crc15_payload_from_trellis(const uint8_t trellis_bits[208]);
uint16_t nxdn_facch2_udch_crc15_check_from_trellis(const uint8_t trellis_bits[208]);

/**
 * Validate the expected SACCH superframe segment order.
 */
int nxdn_sacch_segment_sequence_is_valid(uint8_t crc_ok, int previous_part_of_frame, int part_of_frame);

/**
 * Decode DCR SB0 Call Sign Memory (CSM) digits from trellis bits.
 *
 * On success, writes `CSM ddddddddd` to @p out.
 *
 * @return 1 when decode succeeds, 0 on invalid input or insufficient output space.
 */
int nxdn_dcr_decode_csm_alias(const uint8_t trellis_bits[96], char* out, size_t out_sz);

#ifdef __cplusplus
}
#endif

#endif /* DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_NXDN_NXDN_DEPERM_H_ */
