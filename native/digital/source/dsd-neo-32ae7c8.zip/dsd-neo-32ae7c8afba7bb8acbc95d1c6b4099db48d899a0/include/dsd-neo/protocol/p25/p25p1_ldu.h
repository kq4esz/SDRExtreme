// SPDX-License-Identifier: ISC
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief P25 Phase 1 Logical Data Unit helpers.
 */
#ifndef P25P1_LDU_H_a3c417fcb7804991b0e6d828066bd133
#define P25P1_LDU_H_a3c417fcb7804991b0e6d828066bd133

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>

#include <dsd-neo/protocol/p25/p25p1_soft.h>
#include <stdint.h>

/**
 * Separate imbe frames and deinterleave.
 * This important methods read the IMBE data from the stream and passes it to the vocoder to produce audio.
 * \param opts The DSD options.
 * \param state The DSD state.
 * \status_count An index that allows us to skip the status words interleaved every 36 dibit in the data
 * stream.
 * \return 1 when the frame was dispatched to the vocoder, 0 when no frame was synthesized: a non-standard c0 word
 * skipped before the vocoder, or a frame muted by the P25 crypto rule. The frame's dibits are consumed either way. A
 * caller mixes audio only for a dispatched frame (issue #654).
 */
int process_IMBE(dsd_opts* opts, dsd_state* state, int* status_count);

/**
 * Reads an hex word, its parity bits and attempts to error correct it using the Hamming FEC.
 * \param opts The DSD options.
 * \param state The DSD state.
 * \param hex Pointer where to store the read hex word. Six bytes, one per bit.
 * \param status_count An index that allows us to skip the status words interleaved every 36 dibit in the data
 * stream.
 * \param soft_dibits Pointer to a sequence of P25P1SoftDibit records.
 * \param soft_dibit_index The current index in the soft_dibits array. This value is increased on each
 * dibit read.
 */
void read_and_correct_hex_word(dsd_opts* opts, dsd_state* state, char* hex, int* status_count,
                               P25P1SoftDibit* soft_dibits, int* soft_dibit_index);

/**
 * Return the Reed-Solomon symbol reliability for a Hamming-protected 6-bit word.
 *
 * The input points at the 5 dibits captured for one Hamming(10,6,3) word; only
 * the first 3 dibits carry the RS symbol data bits.
 */
uint8_t p25p1_hamming_rs_symbol_reliability(const P25P1SoftDibit* symbol);

#endif // P25P1_LDU_H_a3c417fcb7804991b0e6d828066bd133
