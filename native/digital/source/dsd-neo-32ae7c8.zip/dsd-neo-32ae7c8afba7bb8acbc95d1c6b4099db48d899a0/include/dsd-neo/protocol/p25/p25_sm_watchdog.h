// SPDX-License-Identifier: GPL-3.0-or-later
/**
 * @file
 * @brief P25 state-machine watchdog helpers.
 */
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_P25_P25_SM_WATCHDOG_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_P25_P25_SM_WATCHDOG_H_H

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>

/*
 * Background watchdog for the P25 trunking state machine tick.
 * Ensures hangtime/CC-return logic continues even if the main
 * DSP loop is temporarily stalled by upstream I/O.
 */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Attempt to run one P25 state-machine tick when idle.
 *
 * Safe to call frequently; a tick is skipped when one is already in progress.
 *
 * @param opts Decoder options.
 * @param state Decoder state.
 */
void p25_sm_try_tick(dsd_opts* opts, dsd_state* state);

/**
 * @brief Try to enter the critical section shared with P25 SM ticks.
 *
 * Callers that temporarily restore or swap trunking state shared with the P25
 * watchdog can use this to avoid racing an in-flight tick. Returns 1 when the
 * caller owns the guard and must call p25_sm_tick_guard_leave().
 */
int p25_sm_tick_guard_try_enter(void);

/**
 * @brief Enter the critical section shared with P25 SM and trunk-scan ticks.
 *
 * This blocking form is intended for work that must not overlap a tick, such
 * as frame dispatch against one tuner target or a tuner lifecycle transition.
 */
void p25_sm_tick_guard_enter(void);

/** @brief Leave a critical section entered by either guard entry function. */
void p25_sm_tick_guard_leave(void);

/**
 * @brief Start the background 1 Hz watchdog thread.
 *
 * No-op if already started.
 *
 * @param opts Decoder options.
 * @param state Decoder state.
 */
void p25_sm_watchdog_start(dsd_opts* opts, dsd_state* state);
/** @brief Stop the background watchdog thread (safe to call when stopped). */
void p25_sm_watchdog_stop(void);

/**
 * @brief Return 1 while a P25 SM tick is executing on the current thread.
 */
int p25_sm_in_tick(void);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_P25_P25_SM_WATCHDOG_H_H */
