// SPDX-License-Identifier: ISC
/**
 * @file
 * @brief P25 Phase 1 HDU validation helpers.
 */
#ifndef P25P1_CHECK_HDU_H_f5f079faf2d64cf5831e1da1ab83b9ba
#define P25P1_CHECK_HDU_H_f5f079faf2d64cf5831e1da1ab83b9ba

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Attempts to correct an hex (6-bit) word using the Golay(24,12,8) FEC.
 * \param hex The 6-bit word to error correct, given as a char array of 6 elements, one bit each.
 * \param parity A 12-bit word with the Golay parity data, given as a char array of 12 elements.
 * \param fixed_error Output. Filled with the number of errors fixed in the input.
 * \return 1 if there were uncorrectable errors in the input, 0 otherwise.
 */
int check_and_fix_golay_24_6(char* hex, const char* parity, int* fixed_errors);

/**
 * Attempts to correct a 12-bit word using the Golay(24,12,8) FEC.
 * \param dodeca The 12-bit word to error correct, given as a char array of 12 elements, one bit each.
 * \param parity A 12-bit word with the Golay parity data, given as a char array of 12 elements.
 * \param fixed_error Output. Filled with the number of errors fixed in the input.
 * \return 1 if there were uncorrectable errors in the input, 0 otherwise.
 */
int check_and_fix_golay_24_12(char* dodeca, const char* parity, int* fixed_errors);

/**
 * Attempts to correct 20 hex words using the Reed-Solomon(36,20,17) FEC.
 * \param data The packed hex words, each of 6 chars, one after the other.
 * \param parity The corresponding 16 hex words with the parity information.
 * \return 1 if irrecoverable errors have been detected, 0 otherwise.
 */
int check_and_fix_redsolomon_36_20_17(char* data, const char* parity);

/**
 * Attempts to correct 20 hex words using Reed-Solomon(36,20,17) plus erasure positions.
 * \param data The packed 20 data hex words, corrected in place on success.
 * \param parity The corresponding 16 parity hex words.
 * \param erasures RS codeword positions, 0-15 parity and 16-35 data.
 * \param n_erasures Number of erasure positions, max 16.
 * \return 1 if irrecoverable errors have been detected, 0 otherwise.
 */
int check_and_fix_redsolomon_36_20_17_soft(char* data, const char* parity, const int* erasures, int n_erasures);

#ifdef __cplusplus
}
#endif

#endif // P25P1_CHECK_HDU_H_f5f079faf2d64cf5831e1da1ab83b9ba
