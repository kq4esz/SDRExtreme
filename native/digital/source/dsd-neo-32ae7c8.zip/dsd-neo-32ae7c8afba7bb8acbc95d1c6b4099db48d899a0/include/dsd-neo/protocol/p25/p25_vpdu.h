// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief P25 MAC VPDU handler interfaces.
 *
 * Declares VPDU processing entrypoints implemented in the P25 protocol code.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_P25_P25_VPDU_H_
#define DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_P25_P25_VPDU_H_

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief P25 Phase 2 MAC PDU type carried by an XCCH block.
 *
 * This is the outer PDU type and is a different namespace from the inner MAC
 * message opcode: PDU type 3 is IDLE, while MAC opcode 3 is Telephone
 * Interconnect Voice Channel User.
 *
 * PTT and END_PTT are listed for completeness against the standard but never
 * reach process_MAC_VPDU(): those PDUs carry no MAC message opcode, so
 * p25p2_xcch_handle_{sacch,facch}_mac_ptt/_mac_end raise the corresponding
 * state-machine events directly. Treat them as unreachable there rather than
 * as a case the voice-provenance gate has to rule on.
 */
typedef enum {
    P25_MAC_PDU_SIGNAL = 0,
    P25_MAC_PDU_PTT = 1,
    P25_MAC_PDU_END_PTT = 2,
    P25_MAC_PDU_IDLE = 3,
    P25_MAC_PDU_ACTIVE = 4,
    P25_MAC_PDU_HANGTIME = 6,
} p25_mac_pdu_type;

/**
 * @brief Process a P25 MAC VPDU block.
 *
 * @param type SACCH (1) or FACCH/bridged Phase 1 (0) transport.
 * @param pdu_type Outer Phase 2 MAC PDU type. Bridged Phase 1 callers use
 *                 P25_MAC_PDU_SIGNAL because they have no Phase 2 wrapper.
 */
void process_MAC_VPDU(dsd_opts* opts, dsd_state* state, int type, p25_mac_pdu_type pdu_type,
                      unsigned long long int mac[24]);

/**
 * @brief process_MAC_VPDU() with the PDU's CRC verdict.
 *
 * @param crc_ok 0 for a MAC_SIGNAL that failed its CRC and reaches here only
 *               because -F relaxes the check (p25p2_xcch_validate_sacch_crc()).
 *               Nothing that proves the carrier's identity -- a network status
 *               broadcast's NAC, which marks the Phase 2 seed proven
 *               (p2_cc_verified) -- is taken from such a PDU (issue #575).
 *               process_MAC_VPDU() passes 1.
 */
void process_MAC_VPDU_crc(dsd_opts* opts, dsd_state* state, int type, p25_mac_pdu_type pdu_type,
                          unsigned long long int mac[24], int crc_ok);

#ifdef __cplusplus
}
#endif

#endif /* DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_P25_P25_VPDU_H_ */
