// SPDX-License-Identifier: ISC
#ifndef GOLAY24_HPP_7a68240afda9406facf81fcad3851111
#define GOLAY24_HPP_7a68240afda9406facf81fcad3851111

#include <dsd-neo/platform/posix_compat.h>

/**
 * @file
 * @brief (23,12) Golay FEC encoder/decoder utilities.
 *
 * Based on the work of Mr Hank Wallace. Adapted from http://www.aqdi.com/golay.htm
 * because it matches expected P25 outputs where ITPP did not.
 */

#define POLY 0xAE3

class Golay24 {
  private:
    static unsigned int
    golay(unsigned int cw)
    /* This function calculates [23,12] Golay codewords.
       The format of the returned int is
       [checkbits(11),data(12)]. */
    {
        int i;
        unsigned int c;
        cw &= 0xfffl;
        c = cw;                   /* save original codeword */
        for (i = 1; i <= 12; i++) /* examine each data bit */
        {
            if (cw & 1) {   /* test data bit */
                cw ^= POLY; /* XOR polynomial */
            }
            cw >>= 1; /* shift intermediate result */
        }
        return ((cw << 12) | c); /* assemble codeword */
    }

    static int
    parity(unsigned int cw)
    /* This function checks the overall parity of codeword cw.
       If parity is even, 0 is returned, else 1. */
    {
        unsigned int p;

        /* XOR bytes together using shifts (portable, no aliasing) */
        p = cw ^ (cw >> 8) ^ (cw >> 16);

        /* XOR the halves of the intermediate result */
        p = p ^ (p >> 4);
        p = p ^ (p >> 2);
        p = p ^ (p >> 1);

        /* return the parity result */
        return (p & 1);
    }

    static unsigned int
    syndrome(unsigned int cw)
    /* This function calculates and returns the syndrome
       of a [23,12] Golay codeword. */
    {
        int i;
        cw &= 0x7fffffl;
        for (i = 1; i <= 12; i++) /* examine each data bit */
        {
            if (cw & 1) {   /* test data bit */
                cw ^= POLY; /* XOR polynomial */
            }
            cw >>= 1; /* shift intermediate result */
        }
        return (cw << 12); /* value pairs with upper bits of cw */
    }

    static unsigned int
    rotate_left(unsigned int cw, int n)
    /* This function rotates 23 bit codeword cw left by n bits. */
    {
        if (n != 0) {
            for (int i = 1; i <= n; i++) {
                if ((cw & 0x400000l) != 0) {
                    cw = (cw << 1) | 1;
                } else {
                    cw <<= 1;
                }
            }
        }

        return (cw & 0x7fffffl);
    }

    static unsigned int
    rotate_right(unsigned int cw, int n)
    /* This function rotates 23 bit codeword cw right by n bits. */
    {
        if (n != 0) {
            for (int i = 1; i <= n; i++) {
                if ((cw & 1) != 0) {
                    cw = (cw >> 1) | 0x400000l;
                } else {
                    cw >>= 1;
                }
            }
        }

        return (cw & 0x7fffffl);
    }

  public:
    static unsigned int
    correct(unsigned int cw, int* errs, unsigned int* errors_detected)
    /* This function corrects Golay [23,12] codeword cw, returning the
       corrected codeword. This function will produce the corrected codeword
       for three or fewer errors. It will produce some other valid Golay
       codeword for four or more errors, possibly not the intended
       one. *errs is set to the number of bit errors corrected. */
    {
        unsigned char w;      /* current syndrome limit weight, 2 or 3 */
        unsigned int mask;    /* mask for bit flipping */
        int i, j;             /* index */
        unsigned int cwsaver; /* saves initial value of cw */

        cwsaver = cw; /* save */
        *errs = 0;
        *errors_detected = 0;

        w = 3;  /* initial syndrome weight threshold */
        j = -1; /* -1 = no trial bit flipping on first pass */
        mask = 1;
        while (j < 23) /* flip each trial bit */
        {
            if (j != -1) /* toggle a trial bit */
            {
                if (j > 0) /* restore last trial bit */
                {
                    mask += mask; /* point to next bit */
                }
                cw = cwsaver ^ mask; /* flip next trial bit */
                w = 2;               /* lower the threshold while bit diddling */
            }

            unsigned int s = syndrome(cw); /* look for errors */
            if (s)                         /* errors exist */
            {
                (*errors_detected)++;
                for (i = 0; i < 23; i++) /* check syndrome of each cyclic shift */
                {
                    *errs = dsd_popcount64(s & 0x7fffffU);
                    if (*errs <= w) /* syndrome matches error pattern */
                    {
                        cw = cw ^ s;              /* remove errors */
                        cw = rotate_right(cw, i); /* unrotate data */
                        return cw;
                    } else {
                        cw = rotate_left(cw, 1); /* rotate to next pattern */
                        s = syndrome(cw);        /* calc new syndrome */
                    }
                }
                j++; /* toggle next trial bit */
            } else {
                return (cw); /* return corrected codeword */
            }
        }

        return (cwsaver); /* return original if no corrections */
    } /* correct */

    static unsigned int
    encode(unsigned int data) {
        unsigned int codeword = golay(data); /* make a test codeword */
        if (parity(codeword)) {
            codeword ^= 0x800000l;
        }

        return codeword;
    }

    static int
    decode(int* errs, unsigned int* cw)
    /* This function decodes codeword *cw. Here error correction is attempted,
       with *errs set to the number of
       bits corrected, and returning 0 if no errors exist, or 1 if parity errors
       exist. */
    {
        unsigned int parity_bit;
        unsigned int detected_errors;
        parity_bit = *cw & 0x800000l; /* save parity bit */
        *cw &= ~0x800000l;            /* remove parity bit for correction */

        *cw = correct(*cw, errs, &detected_errors); /* correct up to three bits */
        *cw |= parity_bit;                          /* restore parity bit */

        /* check for 4 bit errors */
        if (parity(*cw)) { /* odd parity is an error */
            return (1);
        }

        return (0); /* no errors */
    } /* decode */

    static int
    detect(int* errs, unsigned int cw)
    /* This function decodes codeword cw. Here error detection is performed on cw,
       returning 0 if no errors exist, 1 if an overall parity error exists, and
       2 if a codeword error exists. */
    {
        *errs = 0;
        if (parity(cw)) /* odd parity is an error */
        {
            *errs = 1;
            return (1);
        }
        if (syndrome(cw)) {
            *errs = 1;
            return (2);
        } else {
            return (0); /* no errors */
        }

    } /* decode */
};

/**
 * Convenience class that adapts Mr Wallace's implementation to the input/output format of DSD.
 * DSD works with data stored in char arrays where each element represents a bit (0 and 1 values).
 * The original implementation works with codewords that pack the 24 bits of information (12 data and
 * another 12 of parity) in an integer.
 */
class DSDGolay24 : public Golay24 {
  public:
    static bool
    bit_is_valid(char bit) {
        return bit == 0 || bit == 1;
    }

    static bool
    word_bits_are_valid(const char* word, unsigned int length) {
        if (!word || length > 12) {
            return false;
        }
        for (unsigned int i = 0; i < length; i++) {
            if (!bit_is_valid(word[i])) {
                return false;
            }
        }
        return true;
    }

    static bool
    parity_bits_are_valid(const char* parity) {
        if (!parity) {
            return false;
        }
        for (unsigned int i = 0; i < 12; i++) {
            if (!bit_is_valid(parity[i])) {
                return false;
            }
        }
        return true;
    }

    static unsigned int
    adapt_to_codeword(const char* word, unsigned int length, const char* parity) {
        if (!word_bits_are_valid(word, length) || !parity_bits_are_valid(parity)) {
            return 0;
        }

        unsigned int codeword = 0;

        // Data needs to be packed with the 12 bits of parity as the most significant
        // bits and 12 bits of data as the less significant. All these discovered by trial and error.
        for (unsigned int i = 0; i < 12; i++) {
            unsigned int pbit = (unsigned int)(unsigned char)parity[11 - i];
            codeword <<= 1;
            codeword |= pbit;
        }
        for (unsigned int i = 0; i < length; i++) {
            unsigned int bit = (unsigned int)(unsigned char)word[length - 1 - i];
            codeword <<= 1;
            codeword |= bit;
        }
        // We only have length bits of data. We fill up the less significant bits of codeword with zeros.
        if (length < 12) {
            codeword <<= (12 - length);
        }

        return codeword;
    }

    static void
    adapt_to_word(unsigned int codeword, char* word, unsigned int length) {
        if (!word || length > 12) {
            return;
        }

        // put back in word the bits from codeword
        for (unsigned int i = 0, mask = 1 << (12 - length); i < length; i++, mask <<= 1) {
            word[i] = (codeword & mask) != 0 ? 1 : 0;
        }
    }

    static unsigned int
    adapt_from_word(const char* word, unsigned int length) {
        if (!word_bits_are_valid(word, length)) {
            return 0;
        }

        unsigned int codeword = 0;

        // encode the hex bits into a codeword
        for (unsigned int i = 0; i < length; i++) {
            unsigned int bit = (unsigned int)(unsigned char)word[length - 1 - i];
            codeword <<= 1;
            codeword |= bit;
        }

        // We only have length bits of data. We fill up the less significant bits of codeword with zeros.
        if (length < 12) {
            codeword <<= (12 - length);
        }

        return codeword;
    }

    /**
     * Important method that takes an hex word, a 12 bit parity word and uses the Golay24 implementation
     * to error correct it.
     * \param hex The data to error correct, packed in an array of 6 chars, representing a bit each.
     * \param parity The 12 bits of parity packed in an array of chars.
     * \param fixed_errors Output argument, returns the number of errors detected and fixed.
     * \return 1 if we were unable to correct the hex word. Too many errors detected.
     *           in this case the original data remains unchanged.
     *         0 if the data was successfully error corrected.
     */
    static int
    decode_6(char* hex, const char* parity, int* fixed_errors) {
        if (fixed_errors) {
            *fixed_errors = 0;
        }
        if (!fixed_errors || !word_bits_are_valid(hex, 6) || !parity_bits_are_valid(parity)) {
            return 1;
        }

        unsigned int codeword = adapt_to_codeword(hex, 6, parity);
        // codeword now contains:
        // bits  0- 5: zeros
        // bits  6-11: hex bits
        // bits 12-23: golay (24,12) parity bits

        // bits are ordered from left to right, so bit 0 is the most significant and bit 23 is the less.

        int uncorrectable_errors = Golay24::decode(fixed_errors, &codeword);

        // codeword is now hopefully fixed

        // If there are uncorrectable errors and the fixed proposal includes ones
        // in bits 0-5 then probably the fix is not good and we discard it.
        // Bits 0-5 should always be zero, if there is a problem it's on the other bits
        // from 6 to 24.
        if (uncorrectable_errors == 1 && (codeword & 0x3f) != 0) {
            // discard, don't touch hex
        } else {
            // put it back into our hex format
            adapt_to_word(codeword, hex, 6);
            uncorrectable_errors = 0;
        }

        return uncorrectable_errors;
    }

    static int
    decode_12(char* dodeca, const char* parity, int* fixed_errors) {
        if (fixed_errors) {
            *fixed_errors = 0;
        }
        if (!fixed_errors || !word_bits_are_valid(dodeca, 12) || !parity_bits_are_valid(parity)) {
            return 1;
        }

        unsigned int codeword = adapt_to_codeword(dodeca, 12, parity);
        // codeword contains:
        // bits  0-11: dodeca bits
        // bits 12-23: golay (24,12) parity bits

        // bits are ordered from left to right, so bit 0 is the most significant and bit 23 is the less.

        int uncorrectable_errors = Golay24::decode(fixed_errors, &codeword);

        // codeword is now hopefully fixed

        // If there are uncorrectable errors and the fixed proposal includes ones
        // in bits 0-5 then probably the fix is not good and we discard it.
        // Bits 0-5 should always be zero, if there is a problem it's on the other bits
        // from 6 to 24.
        if (uncorrectable_errors == 1 && (codeword & 0x3f) != 0) {
            // discard, don't touch hex
        } else {
            // put it back into our hex format
            adapt_to_word(codeword, dodeca, 12);
            uncorrectable_errors = 0;
        }

        return uncorrectable_errors;
    }

    static void
    encode_6(const char* hex, char* out_parity) {
        if (!out_parity || !word_bits_are_valid(hex, 6)) {
            return;
        }

        unsigned int data = adapt_from_word(hex, 6);
        unsigned int codeword = Golay24::encode(data);

        // Fill up the parity
        for (unsigned int i = 0, mask = 1 << 12; i < 12; i++, mask <<= 1) {
            out_parity[i] = (codeword & mask) != 0 ? 1 : 0;
        }
    }

    static void
    encode_12(const char* dodeca, char* out_parity) {
        if (!out_parity || !word_bits_are_valid(dodeca, 12)) {
            return;
        }

        unsigned int data = adapt_from_word(dodeca, 12);
        unsigned int codeword = Golay24::encode(data);

        // Fill up the parity
        for (unsigned int i = 0, mask = 1 << 12; i < 12; i++, mask <<= 1) {
            out_parity[i] = (codeword & mask) != 0 ? 1 : 0;
        }
    }
};

#endif // GOLAY24_HPP_7a68240afda9406facf81fcad3851111
