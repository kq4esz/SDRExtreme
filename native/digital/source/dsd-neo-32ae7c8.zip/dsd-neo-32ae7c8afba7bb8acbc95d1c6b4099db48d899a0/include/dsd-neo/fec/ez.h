// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief ezpwd-style Reed-Solomon helpers used by P25 Phase 2.
 *
 * Declares the RS(63,35) and ISCH lookup helpers implemented in `src/fec/ez.cpp`
 * so callers can use them directly.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_FEC_EZ_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_FEC_EZ_H_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Decode shortened P25 RS(63,35) bit arrays with optional erasures.
 *
 * Pass NULL and zero for a decoder without erasures. At most 28 erasure
 * positions are consumed.
 */
int ez_rs28_ess(int payload[96], int parity[168], const int* erasures, int n_erasures);
int ez_rs28_facch(int payload[156], int parity[114], const int* erasures, int n_erasures);
int ez_rs28_sacch(int payload[180], int parity[132], const int* erasures, int n_erasures);

int isch_lookup(uint64_t isch);
int isch_lookup_soft(uint64_t isch, const uint8_t reliab40[40]);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_FEC_EZ_H_H */
