// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Core event logging helpers.
 *
 * Declares event-history helpers implemented in core.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_CORE_EVENTS_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_CORE_EVENTS_H_H

#include <dsd-neo/core/call_state.h>
#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state.h>
#include <dsd-neo/core/state_ext.h>
#include <dsd-neo/core/state_fwd.h>
#include <dsd-neo/core/synctype_ids.h>
#ifdef DSD_NEO_EVENT_HISTORY_TRANSACTIONS
#include <dsd-neo/platform/threading.h>
#endif

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void init_event_history(Event_History_I* event_struct, uint8_t start, uint8_t stop);
void push_event_history(Event_History_I* event_struct);

// Only the two-slot protocols annotate their log lines with a slot number. X2-TDMA belongs here for
// the same reason the other two do: it carries two timeslots and its callers attribute every
// observation through state->currentslot, so a log line without the annotation is ambiguous.
static inline int
dsd_event_systype_has_slots(int systype) {
    return DSD_SYNC_IS_DMR_BS(systype) || DSD_SYNC_IS_P25P2(systype) || DSD_SYNC_IS_X2TDMA(systype);
}

/** Opaque guard for serializing event-history mutations with telemetry snapshots. */
typedef struct {
    void* opaque;
} dsd_event_history_transaction;

static inline void
dsd_event_history_transaction_begin(dsd_state* state, dsd_event_history_transaction* transaction) {
    if (transaction == NULL) {
        return;
    }
    transaction->opaque = state != NULL ? state->state_ext[DSD_STATE_EXT_CORE_CALL_STATE] : NULL;
#ifdef DSD_NEO_EVENT_HISTORY_TRANSACTIONS
    if (transaction->opaque != NULL) {
        (void)dsd_mutex_lock((dsd_mutex_t*)transaction->opaque);
    }
#endif
}

static inline void
dsd_event_history_transaction_end(dsd_event_history_transaction* transaction) {
    if (transaction == NULL || transaction->opaque == NULL) {
        return;
    }
#ifdef DSD_NEO_EVENT_HISTORY_TRANSACTIONS
    (void)dsd_mutex_unlock((dsd_mutex_t*)transaction->opaque);
#endif
    transaction->opaque = NULL;
}

static inline void
dsd_event_history_mark_dirty(Event_History_I* event_struct) {
    if (event_struct == NULL) {
        return;
    }

    event_struct->revision++;
    if (event_struct->revision == 0U) {
        event_struct->revision = 1U;
    }
}

static inline void
dsd_event_history_item_set_metadata(Event_History* item, dsd_event_severity severity, dsd_event_category category) {
    if (item == NULL) {
        return;
    }
    item->severity = (uint8_t)severity;
    item->category = (uint8_t)category;
}

static inline void
dsd_event_history_item_copy_text(char* dst, size_t cap, const char* src) {
    if (dst == NULL || cap == 0U) {
        return;
    }
    if (src == NULL) {
        dst[0] = '\0';
        return;
    }
    size_t i = 0U;
    while (i + 1U < cap && src[i] != '\0') {
        dst[i] = src[i];
        i++;
    }
    dst[i] = '\0';
}

static inline void
dsd_event_history_item_set_message(Event_History* item, dsd_event_severity severity, dsd_event_category category,
                                   const char* summary, const char* detail) {
    dsd_event_history_item_set_metadata(item, severity, category);
    if (item == NULL) {
        return;
    }
    if (summary != NULL) {
        dsd_event_history_item_copy_text(item->event_string, sizeof item->event_string, summary);
    }
    if (detail != NULL) {
        dsd_event_history_item_copy_text(item->internal_str, sizeof item->internal_str, detail);
    }
}

/**
 * Stage a data PDU's text/GPS independently of the active call's history row.
 * Replace operations accept NULL or "" to clear; append ignores NULL. Clear resets both fields.
 * Writers are no-ops without history or for a slot outside DSD_CALL_STATE_SLOT_COUNT, and
 * getters return "" in those cases. Staging alone does not change history revisions.
 * Writers take the history transaction internally: never call them while holding a history
 * transaction (the mutex is non-recursive).
 * Getters return borrowed, decoder-thread-owned views into state, invalidated by the next
 * staging write, consumption or reset. They are not telemetry snapshot fields.
 */
void dsd_event_stage_text(dsd_state* state, uint8_t slot, const char* text);
void dsd_event_stage_text_append(dsd_state* state, uint8_t slot, const char* text);
void dsd_event_stage_gps(dsd_state* state, uint8_t slot, const char* gps);
const char* dsd_event_staged_text(const dsd_state* state, uint8_t slot);
const char* dsd_event_staged_gps(const dsd_state* state, uint8_t slot);
void dsd_event_stage_clear(dsd_state* state, uint8_t slot);

void write_event_to_log_file(const dsd_opts* opts, dsd_state* state, uint8_t slot, uint8_t swrite,
                             const char* event_string);
void watchdog_event_history(dsd_opts* opts, dsd_state* state, uint8_t slot);
/**
 * Render the slot's canonical call into its staged row, opening the call's epoch first (committing the outgoing epoch's
 * staged row as it stands) when no sync has opened it yet.
 */
void watchdog_event_current(const dsd_opts* opts, dsd_state* state, uint8_t slot);
/**
 * Attach a note (internal_str: a lockout, a skip) to the slot's canonical call and render it.
 *
 * The call's epoch is opened first, so a note written right after a protocol observed a new call lands on that call's
 * row rather than on the outgoing epoch's. The note is declined when the slot has no call to carry it: no call has been
 * observed, or the call ended and already committed its row (an ended call still finalizing takes it). Written into the
 * blank staged row instead, it would become a note-only row when the next call opened. Use this rather than writing
 * Items[0].internal_str and calling watchdog_event_current(). Callers must not hold an event-history transaction.
 */
void dsd_event_note_current_call(dsd_opts* opts, dsd_state* state, uint8_t slot, const char* note);

/** The decoded per-call detail a protocol writes into the slot's call row. */
typedef enum {
    DSD_EVENT_DETAIL_ALIAS = 0, /**< Talker alias (Event_History::alias). */
    DSD_EVENT_DETAIL_GPS = 1,   /**< Position report (Event_History::gps_s). */
    DSD_EVENT_DETAIL_TEXT = 2,  /**< Text message (Event_History::text_message). */
} dsd_event_detail_field;

/**
 * Write a protocol's decoded detail into the row of the slot's open call.
 *
 * Written only while the slot's canonical call is active and its epoch has been opened, so the staged row is that
 * call's own. Otherwise the detail is declined: decoded before any call for the transmission was observed (an RF
 * header that failed its CRC, late entry, an alias ahead of the call message), or after the call ended, it has no row
 * to go to, and written into the staged row it would become a detail-only row or land on another call's row. Slow data
 * and aliases repeat, so declined detail lands once the call is open. Callers must not hold an event-history
 * transaction.
 *
 * @return 1 when written, 0 when declined, -1 for invalid arguments.
 */
int dsd_event_set_open_call_detail(dsd_state* state, uint8_t slot, dsd_event_detail_field field, const char* value);
void dsd_event_sync_slot(dsd_opts* opts, dsd_state* state, uint8_t slot);
int dsd_event_emit_call_notice(dsd_opts* opts, dsd_state* state, uint8_t slot, const dsd_call_snapshot* call,
                               const char* detail);
/** Commit an informational call notice without call-end alerts, WAV rotation, or slot-identity reset. */
int dsd_event_emit_call_notice_nonfinalizing(dsd_opts* opts, dsd_state* state, uint8_t slot,
                                             const dsd_call_snapshot* call, const char* detail);
int dsd_event_history_copy_snapshot(const dsd_state* state, Event_History_I out[2]);
/**
 * Retire any VOICE_END alert still being held open against a possible reacquisition, on both
 * slots, without waiting for its deadline.
 *
 * For callers that know no further audio can arrive -- shutdown being the only one today. The
 * per-frame drain in dsd_event_sync_slot() only fires once the reacquisition window has elapsed,
 * so an end armed in the last half second before exit would otherwise never be heard.
 */
void dsd_event_flush_pending_alerts(dsd_opts* opts, dsd_state* state);
/**
 * Clear every history row, staged data payload and per-slot commit bookkeeping on both slots.
 *
 * Callers must not hold an event-history transaction: this opens its own. Clearing the rows
 * without clearing the bookkeeping would leave a reacquired transmission trying to merge into
 * a row that no longer exists.
 */
void dsd_event_history_reset(dsd_state* state);
/* Copy telemetry atomically, copying history slots only when forced or when their source revision changed. */
int dsd_event_state_copy_snapshot_incremental(dsd_state* dst, const dsd_state* src, Event_History_I event_history[2],
                                              const uint64_t source_revisions[2], int force_copy, uint8_t copied[2]);
int dsd_event_state_copy_snapshot(dsd_state* dst, const dsd_state* src, Event_History_I event_history[2]);
void watchdog_event_status(dsd_state* state, const char* status_string, uint8_t slot);
/**
 * Commit a data/control notice using neutral event metadata, consuming the slot's staged data payload.
 *
 * Only DSD_EVENT_CATEGORY_DATA and DSD_EVENT_CATEGORY_CONTROL are accepted.
 * Invalid categories are rejected without changing event history.
 */
int dsd_event_emit_data_notice_classified(dsd_opts* opts, dsd_state* state, uint8_t slot,
                                          const dsd_call_observation* observation, dsd_event_category category,
                                          const char* notice);
/**
 * Commit a data/control notice with GPS owned by the new event, leaving the staged payload and active row unchanged.
 *
 * Only DSD_EVENT_CATEGORY_DATA and DSD_EVENT_CATEGORY_CONTROL are accepted.
 * Invalid categories or a NULL GPS value are rejected without changing event history.
 */
int dsd_event_emit_data_notice_classified_with_gps(dsd_opts* opts, dsd_state* state, uint8_t slot,
                                                   const dsd_call_observation* observation, dsd_event_category category,
                                                   const char* notice, const char* gps);
/** Commit a data notice. Equivalent to dsd_event_emit_data_notice_classified() with the DATA category. */
int dsd_event_emit_data_notice(dsd_opts* opts, dsd_state* state, uint8_t slot, const dsd_call_observation* observation,
                               const char* notice);
/** Commit a data notice with GPS. Equivalent to the classified GPS API with the DATA category. */
int dsd_event_emit_data_notice_with_gps(dsd_opts* opts, dsd_state* state, uint8_t slot,
                                        const dsd_call_observation* observation, const char* notice, const char* gps);
/** Commit an informational system notice without attributing it to radio traffic. */
int dsd_event_emit_system_notice(dsd_opts* opts, dsd_state* state, uint8_t slot, const char* notice);
int dsd_event_enrich_alias(dsd_state* state, uint8_t slot, uint64_t epoch, const char* alias);
int dsd_event_enrich_gps(dsd_state* state, uint8_t slot, uint64_t epoch, const char* gps);
int dsd_event_enrich_text(dsd_state* state, uint8_t slot, uint64_t epoch, const char* text);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_CORE_EVENTS_H_H */
