// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Audio-domain filter helpers.
 *
 * Declares analog monitor and audio utility filters implemented in core/util.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_CORE_AUDIO_FILTERS_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_CORE_AUDIO_FILTERS_H_H

#include <dsd-neo/core/state_fwd.h>

#ifdef __cplusplus
extern "C" {
#endif

void init_audio_filters(dsd_state* state, int sample_rate_hz);
void lpf(dsd_state* state, short* input, int len);
void lpf_f(dsd_state* state, float* input, int len);
/**
 * @note Renamed from `hpf()` to avoid a collision with codec2, which exports a
 *  symbol of that name; Android links codec2 statically, so the duplicate is a
 *  link error rather than something the dynamic loader papers over. Only this one
 *  filter is prefixed on purpose -- codec2 exports none of the others below, and
 *  renaming symbols that do not collide would break out-of-tree callers for
 *  nothing. Out-of-tree callers of `hpf()` need updating; see docs/code_map.md.
 */
void dsd_hpf(dsd_state* state, short* input, int len);
void hpf_f(dsd_state* state, float* input, int len);
/**
 * @brief The digital voice high-pass (`-v 0x8`) on int16 samples, slot 1's (hpf_dL) or slot 2's (hpf_dR) filter state,
 * saturating to int16. The voice chain (dsd_voice_chain_run(), <dsd-neo/core/voice_chain.h>) runs the same filter on
 * every decoded frame before its gain; since issue #653 it is a 2nd-order Butterworth at 300 Hz with unity passband.
 */
void hpf_dL(dsd_state* state, short* input, int len);
void hpf_dR(dsd_state* state, short* input, int len);
/**
 * @note Pass-through shims since issue #518: the old one-pole 8 kHz / 12 kHz "PBF" pair they ran took 1 kHz 18 dB
 *  down. The analog monitor's voice band-pass is dsd_analog_audio_process_f() (<dsd-neo/dsp/analog_audio.h>); these
 *  stay so out-of-tree callers still link. See docs/code_map.md.
 */
void pbf(dsd_state* state, short* input, int len);
void pbf_f(dsd_state* state, float* input, int len);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_CORE_AUDIO_FILTERS_H_H */
