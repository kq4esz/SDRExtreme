// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Core decoder state structure (`dsd_state`) and helper types.
 *
 * Hosts the full `dsd_state` definition so modules needing state fields
 * can include it directly.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_CORE_STATE_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_CORE_STATE_H_H

#include <dsd-neo/platform/platform.h>

#include <dsd-neo/core/input_level.h>
#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/p25p2_playout.h>
#include <dsd-neo/core/state_ext.h>
#include <dsd-neo/core/state_fwd.h>

#include <stdint.h>
#include <time.h>

#include <dsd-neo/core/dibit.h>
#include <dsd-neo/core/dmr_key_map.h>
#include <dsd-neo/core/enc_lockout.h>
#include <dsd-neo/core/key_set.h>

#include <dsd-neo/protocol/p25/p25_cc_candidates.h>
#include <dsd-neo/protocol/p25/p25_status_symbol.h>

/* Buffer size for a human-readable channel label. Sized to hold a trunk-scan
 * target id (dsd_trunk_scan_target.id[64]) unchanged; a channel-map CSV name is
 * truncated to 63 characters plus the terminator. */
#define DSD_CHANNEL_LABEL_SIZE 64

/* The highest frequency, in Hz, a trunking channel is stored or tuned at, the same on every platform: the largest value
 * a 32-bit long holds (long is 32-bit on Windows, and trunk frequencies are stored as long), which also fits the
 * uint32_t tuner path. No trunking band comes near it. A channel-map row, an over-the-air channel computation or a
 * cached control channel past it is refused rather than stored or tuned. */
#define DSD_TRUNK_FREQ_MAX_HZ  2147483647L

enum DSD_ATTR_PACKED {
    DSD_P25_MAC_FRAGMENT_MAX_OCTETS = 256,
    DSD_TRUNK_CHAN_MAP_SIZE = 0xFFFF,
    /* Scan-list slots stored inline in dsd_state. Protocol fixed-slot writers raw-index
     * trunk_lcn_freq[] below this; longer lists spill into the trunk_lcn_freq_ext heap
     * tail behind dsd_state_trunk_lcn_slot(). */
    DSD_TRUNK_LCN_EMBEDDED = 26,
    DSD_VERTEX_KS_MAP_MAX = 64,
    DSD_RTL_SYMBOL_CACHE_CAP = 512,
};

/** Authoritative per-slot P25 voice crypto classification. */
typedef enum DSD_ATTR_PACKED {
    DSD_P25_CRYPTO_UNKNOWN = 0,
    DSD_P25_CRYPTO_CLEAR = 1,
    DSD_P25_CRYPTO_ENCRYPTED_PENDING = 2,
    DSD_P25_CRYPTO_DECRYPTABLE = 3,
    DSD_P25_CRYPTO_BLOCKED = 4,
} dsd_p25_crypto_state;

/** Phase 1 traffic crypto tuple awaiting corroboration against clear service options. */
typedef struct {
    uint16_t keyid;
    uint8_t algid;
    uint8_t active;
} dsd_p25_p1_crypto_conflict_state;

/** Phase 2 per-slot ESS crypto tuple awaiting corroboration against clear service context. */
typedef struct {
    uint16_t keyid;
    uint8_t algid;
    uint8_t active;
} dsd_p25_p2_crypto_conflict_state;

/** Phase 1 carrier/call epoch whose post-lockout ESS repeats may be ignored. */
typedef struct {
    uint64_t call_epoch;
    int64_t frequency_hz;
    double recorded_m;
    uint32_t grant_generation;
    uint8_t valid;
} dsd_p25_p1_lockout_epoch_state;

/** Phase 2 ESS identity change held until boundary voice has drained. */
typedef struct {
    uint64_t mi;
    uint16_t keyid;
    uint8_t algid;
    uint8_t pending;
} dsd_p25_p2_rekey_state;

typedef struct {
    uint8_t active;
    uint8_t opcode;
    uint8_t data_len;
    uint8_t collected;
    uint8_t data[DSD_P25_MAC_FRAGMENT_MAX_OCTETS];
} p25_mac_fragment_state_t;

typedef struct {
    uint8_t valid;
    uint8_t sequence;
    uint8_t block_count;
    uint8_t next_block;
} p25_apx_alias_rx_state_t;

typedef struct {
    uint8_t mask;
    char last_alias[40];
    char last_saved_alias[40];
    uint32_t src;
    uint32_t tg;
    uint64_t epoch; //call epoch that was ACTIVE when block 0 keyed this fragment set; 0 when none was
    uint8_t fragment[4][8];
} p25_l3h_alias_phase1_state_t;

typedef enum DSD_ATTR_PACKED {
    DSD_EVENT_SEVERITY_UNKNOWN = 0,
    DSD_EVENT_SEVERITY_DEBUG = 1,
    DSD_EVENT_SEVERITY_INFO = 2,
    DSD_EVENT_SEVERITY_WARNING = 3,
    DSD_EVENT_SEVERITY_ERROR = 4
} dsd_event_severity;

typedef enum DSD_ATTR_PACKED {
    DSD_EVENT_CATEGORY_UNKNOWN = 0,
    DSD_EVENT_CATEGORY_STATUS = 1,
    DSD_EVENT_CATEGORY_VOICE = 2,
    DSD_EVENT_CATEGORY_DATA = 3,
    DSD_EVENT_CATEGORY_CONTROL = 4,
    DSD_EVENT_CATEGORY_SYSTEM = 5
} dsd_event_category;

//event history (each item)
// NOLINTBEGIN(clang-analyzer-optin.performance.Padding)
// The dsd_state structure is intentionally organized by functional groups for clarity
// and cross-module stability rather than by strict padding minimization. Reordering
// hundreds of fields as suggested by the analyzer would be high-risk and harm
// readability/maintainability without measurable benefit. Suppress the padding
// warning for this aggregate while keeping all other clang-tidy checks active.
typedef struct {
    uint8_t write;       // If this event needs to be written to a log file
    uint8_t color_pair;  //this value corresponds to which color pair the line should be in ncurses
    uint8_t severity;    // neutral event severity for non-terminal frontends
    uint8_t category;    // neutral event category for non-terminal frontends
    uint8_t crc_invalid; // DSD_CRC_* provenance bits (crc_provenance.h); zero does not imply verification.
    int8_t systype;      //indentifier of which decoded system type this is from (P25, DMR, etc)
    int8_t subtype;      //subtype of systpe (VLC, TLC, PDU data, System Event, etc)
    uint32_t sys_id1;    //sys_id1 through 5 will be a hierarchy of system identifiers
    uint32_t sys_id2;    // For example, trunked P25 has WACN:SYS:CC:SITE_ID:RFSS_ID
    uint32_t sys_id3;    //conventional may only use NAC, RAN, or Color Codes
    uint32_t sys_id4;    //
    uint32_t sys_id5;    //
    int8_t gi;           //group or individual
    uint8_t emergency;   // emergency indication observed during this call
    uint8_t priority;    // observed service priority
    uint8_t enc;         //clear or encrypted
    uint8_t enc_alg;     //alg if encrypted
    uint16_t enc_key;    //enc key id value, if encrypted (not key value or key variable)
    uint64_t mi;         //mi, or iv base value from OTA if provided
    uint16_t svc;        //other relevant svc opts if applicable
    uint32_t source_id;  //source radio id or other source value
    uint32_t target_id;  //group or individual target, or destination value
    char src_str[200];   //source, expressed as a string for M17, YSF, DSTAR, dPMR
    char tgt_str[200];   //target, expressed as a string for M17, YSF, DSTAR, dPMR
    char t_name[200];    //this is the string present from any csv groupName import
    char s_name[200];    //same as above, but if loaded from a src value and not tg value
    char t_mode[200];    //mode, or A,B,D,DE from csv group import file
    char s_mode[200];    //mode, or A,B,D,DE from csv group import file
    // Name of the scan channel this transmission was heard on, or "" when the receiver was not
    // scanning a named channel. Resolved once per call epoch, on the epoch's first render, and
    // rendered as a bracketed prefix between the row's timestamp and its protocol token.
    char channel_label[DSD_CHANNEL_LABEL_SIZE];
    // Whether channel_label above has been resolved for this row. An unnamed channel resolves to
    // an empty label, which is an answer and not a missing one -- a -Y list with only some rows
    // named is ordinary -- so the emptiness alone cannot serve as "ask again", or a later render
    // of the same epoch would stamp whichever channel the scanner has since hopped to.
    uint8_t channel_label_resolved;
    uint32_t channel; // If this occurs on a trunking channel, which channel
    // Frequency in Hz the call was heard on, or 0 when unknown. The call's own frequency (a grant's
    // channel, the followed voice channel) whenever the call has one; otherwise the receiver's tuned
    // frequency, taken once, on the epoch's first render while the call is active, and kept for the
    // rest of the epoch. A row is never given the tuner reading after its call has ended.
    int64_t freq_hz;
    // Which access code access_code is, a dsd_access_code_kind (<dsd-neo/core/access_code.h>);
    // DSD_ACCESS_CODE_NONE (0) when none is known. Refreshed from the decoder while the call is
    // active, never erased there by an unknown reading, and frozen once the call has ended.
    uint8_t access_code_kind;
    // The colour code, NAC, RAN or CAN the call was heard with; meaningful only when
    // access_code_kind is not DSD_ACCESS_CODE_NONE.
    uint16_t access_code;
    time_t event_time; //time event occurred
    // Wall-clock time the transmission this row describes began, or 0 when unknown.
    // event_time is restamped as last-activity on every render pass, so by commit it
    // reads as the call's end; the pair is what gives a frontend a real duration.
    time_t event_start_time;

    uint8_t pdu[128 * 24];   //relevant link control, or full PDU if data call (in bytes)
    char sysid_string[200];  //string comprised of system unique identifiers
    char alias[2000];        // If this event has a source radio talker alias or similar
    char gps_s[2000];        //gps, if returned, expressed as a string
    char text_message[2000]; // If this event is a decoded text message, then it goes here
    char event_string[2000]; //user legible and printable string for the event that happened
    char internal_str[2000]; //string that relates to a DSD-neo generated event (ENC LO, error notices, etc)
} Event_History;

//event history for number of each items above
// Ring length, shared with every consumer that walks the items: index 0 is the active
// call's row, retaining its enrichment until commit; indexes 1..DSD_EVENT_HISTORY_LEN-1
// are committed rows. Data-PDU payloads for notices live separately in staged.
#define DSD_EVENT_HISTORY_LEN 255

typedef struct {
    char gps_s[2000];
    char text_message[2000];
} Event_History_Staged;

typedef struct Event_History_I {
    Event_History Event_History_Items[DSD_EVENT_HISTORY_LEN];
    uint64_t revision;
    // Count of push_event_history() calls on this slot. Every push -- call commits,
    // data and system notices, the startup banner -- shifts the ring by one, so a
    // row's depth can be recovered as 1 + (push_seq - the push_seq it was pushed at),
    // and a committed row's push stamp as push_seq - (its index - 1). That stamp is
    // stable for the row's whole life in the ring, which makes it the identity
    // frontends key their own mirrors on.
    uint64_t push_seq;
    // Count of mutations to the committed rows (indexes >= 1): pushes, reacquisition
    // merges, late enrichment, and full resets. Staged-row renders bump only
    // `revision`, so a consumer that mirrors committed rows only (the Qt call
    // history) can skip rescanning the ring while this is unchanged.
    uint64_t commit_rev;
    // Which ring this is: a nonzero nonce drawn once, when initState() allocates the ring, and shared by
    // its two slots. A state an embedding host reuses for another run keeps it, and its push_seq goes on
    // counting; a new state draws another. A frontend that keys its mirror on push stamps tells by it the
    // rows it already read from a new ring that repeats their stamps and content, as a capture replayed in
    // a fresh state does.
    uint64_t instance;
    // Decoder-thread scratch consumed by next data notice; snapshots incidental, no dirty marks; frontends never render
    Event_History_Staged staged;
} Event_History_I;

//new audio filter stuff from: https://github.com/NedSimao/FilteringLibrary
typedef struct {
    float coef[2];
    float v_out[2];
} LPFilter;

typedef struct {
    float coef;
    float v_out[2];
    float v_in[2];

} HPFilter;

/* One slot's digital voice high-pass (`-v 0x8`, issue #653): the transposed direct form II state of the 2nd-order
   Butterworth section dsd_voice_hpf_process() runs on 8 kHz vocoder frames, and the reception it last ran for, so a new
   call or protocol on the slot starts from clear state (<dsd-neo/core/voice_chain.h>). */
typedef struct {
    double s1;
    double s2;
    uint64_t call_epoch; /* The last nonzero call epoch the slot's frames belonged to; 0 before the first. */
    int protocol_family; /* dsd_call_state_protocol_family() of the last frame; 0 before the first. */
} dsd_voice_hpf_state;

//end new filters

/**
 * @brief Post-filter sample trace used only by the symbol-timing diagnostic.
 *
 * `samples` holds the samples the symbol grid consumed, in order; `spans` holds
 * how many of them each completed symbol took, so a reader can walk real symbol
 * boundaries rather than assume a fixed samplesPerSymbol stride (the pre-sync
 * timing nudge makes symbols consume samplesPerSymbol +/- 1). Decoder-state setup
 * and teardown own both buffers, as they do the symbol history's; nothing is
 * written to them unless DSD_NEO_DEBUG_SYMBOL_TIMING is on.
 */
typedef struct {
    float* samples;
    uint8_t* spans;
    int sample_head;
    int sample_count;
    int span_head;
    int span_count;
} dsd_symbol_timing_trace;

/** Raw samples the symbol grid keeps behind it: enough to prime the longest
 *  matched filter (DSD_SPS_FILTER_MAX_TAPS) after a switch-off has handed back
 *  the samples the previous filter still had in flight. */
#define DSD_MATCHED_FILTER_HISTORY 2048

/**
 * The matched filter the symbol grid is reading through, and what it takes to
 * change it without moving the grid (issue #444).
 *
 * The grid reads the raw discriminator until a sync names a protocol and the
 * filter's output afterwards, which describes the signal one group delay in the
 * past. A change of `kind` or `sps` is therefore a discontinuity in the content
 * the grid samples, and `src/dsp/dsd_symbol.c` pays for it here: a filter
 * switching on is primed from `raw` and fed its delay's worth of samples whose
 * outputs are discarded; one switching off hands back the samples it still had
 * in flight, which the grid re-reads from `raw` (`replay` of them) before live
 * input resumes. Zeroed by initState() and again by
 * dsd_symbol_matched_filter_reset() alongside init_rrc_filter_memory(), since a
 * cleared filter with this saying it is primed would be the transient all over.
 */
typedef struct {
    int kind;  /**< A dsd_sps_filter_kind; an int because core does not see dsp headers. 0 is unfiltered. */
    int sps;   /**< Samples per symbol `kind` was designed for. */
    int delay; /**< Group delay of `kind` at `sps`, in samples; 0 when unfiltered. */
    float raw[DSD_MATCHED_FILTER_HISTORY]; /**< Raw samples the grid consumed, newest last; a ring. */
    int raw_head;                          /**< Next write index into `raw`. */
    int raw_count;                         /**< Samples held, saturating at the ring size. */
    int replay;                            /**< Samples still to be re-read from `raw` before live input. */
} dsd_matched_filter_seam;

typedef struct {
    uint8_t F1;
    uint8_t F2;
    uint8_t MessageType;

    /****************************/
    /***** VCALL parameters *****/
    /****************************/
    uint8_t CCOption;
    uint8_t CallType;
    uint8_t VoiceCallOption;
    uint16_t SourceUnitID;
    uint16_t DestinationID; /* May be a Group ID or a Unit ID */
    uint8_t CipherType;
    uint8_t KeyID;

    /*******************************/
    /***** VCALL_IV parameters *****/
    /*******************************/
    uint8_t IV[8];

    /*****************************/
    /***** Custom parameters *****/
    /*****************************/

    /* Used on DES and AES encrypted frames */
    uint8_t PartOfCurrentEncryptedFrame; /* Could be 1 or 2 */
    uint8_t PartOfNextEncryptedFrame;    /* Could be 1 or 2 */
    uint8_t CurrentIVComputed[8];
    uint8_t NextIVComputed[8];
} NxdnElementsContent_t;

//dPMR
/* Could only be 2 or 4 */
#define NB_OF_DPMR_VOICE_FRAME_TO_DECODE 2

typedef struct {
    unsigned char RawVoiceBit[NB_OF_DPMR_VOICE_FRAME_TO_DECODE * 4][72];
    unsigned int errs1[NB_OF_DPMR_VOICE_FRAME_TO_DECODE
                       * 4]; /* 8 x errors #1 computed when demodulate the AMBE voice bit of the frame */
    unsigned int errs2[NB_OF_DPMR_VOICE_FRAME_TO_DECODE
                       * 4]; /* 8 x errors #2 computed when demodulate the AMBE voice bit of the frame */
    unsigned char AmbeBit[NB_OF_DPMR_VOICE_FRAME_TO_DECODE * 4][49]; /* 8 x 49 bit of AMBE voice of the frame */
    unsigned char CCHData[NB_OF_DPMR_VOICE_FRAME_TO_DECODE][48];
    unsigned int CCHDataHammingOk[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned char CCHDataCRC[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int CCHDataCrcOk[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int FrameNumbering[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int CommunicationMode[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int Version[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    /* Per half (dpmr_resolve_half_scrambling(), issue #655): DPMR_HALF_CLEAR, DPMR_HALF_SCRAMBLED (Version 3), by the
       half's own Version when its CRC-7 passed, else by the transmission's last verified half or this frame's other
       one; DPMR_HALF_UNVERIFIED when no half has verified since the transmission's boundary: the bridge plays none of
       it. Version itself is the raw field. */
    unsigned int Scrambled[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int CommsFormat[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int EmergencyPriority[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int Reserved[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned char SlowData[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int ColorCode[NB_OF_DPMR_VOICE_FRAME_TO_DECODE / 2];
} dPMRVoiceFS2Frame_t;

/**
 * @brief Consolidated per-slot IDEN entry for P25 frequency resolution.
 *
 * Each entry holds the complete set of parameters needed to resolve a 16-bit
 * channel number to a frequency. Two arrays of this type exist in dsd_state:
 * one for FDMA/non-TDMA identifiers and one for TDMA identifiers. This
 * separation prevents multi-mode systems from cycling incompatible parameters
 * in a single slot.
 */
typedef struct {
    long int base_freq;       // base frequency in 5 Hz units (per IDEN_UP encoding)
    int chan_type;            // 4-bit channel type (TDMA: slots-per-carrier; 1 for FDMA default)
    int chan_spac;            // 10-bit channel spacing (in 0.125 kHz units)
    int trans_off;            // transmit offset
    uint8_t bw_vu;            // 4-bit VHF/UHF bandwidth (0=standard/not VHF-UHF, nonzero=VHF/UHF BW)
    uint8_t trust;            // 0=unknown, 1=unconfirmed, 2=confirmed on matching CC
    uint8_t populated;        // 0=empty, 1=has valid complete data from LCW/TSBK/MAC/PDU
    unsigned long long wacn;  // WACN provenance (system context when IDEN was learned)
    unsigned long long sysid; // SysID provenance
    unsigned long long rfss;  // RFSS ID provenance
    unsigned long long site;  // Site ID provenance
} p25_iden_entry_t;

/** Capacity of the user-supplied P25 band plan: four systems' worth of 16 identifiers. */
#define DSD_P25_BANDPLAN_MAX_ROWS 64

/**
 * @brief One row of a user-supplied P25 band plan (docs/csv-formats.md, "P25 Band Plan CSV").
 *
 * `entry` is a ready-to-copy IDEN entry (trust 1, populated, rfss/site 0); `entry.wacn`/`sysid`
 * are the system the row applies to, both 0 for a row that applies everywhere. `is_tdma`
 * selects the table the row seeds, by the same rule p25_channel_type_slots_per_carrier() uses.
 */
typedef struct p25_bandplan_row {
    uint8_t iden;    // identifier 0-15
    uint8_t is_tdma; // 1 seeds p25_iden_tdma, 0 seeds p25_iden_fdma
    p25_iden_entry_t entry;
} p25_bandplan_row_t;

/** Voice-gated scan phase for -Y (issue #381). OFF = gate disabled; QUALIFY = synced
 * but no policy-allowed voice yet; VOICE = voice media active; TAIL = holding past
 * the last voice frame. */
typedef enum {
    DSD_SCAN_VOICE_GATE_OFF = 0,
    DSD_SCAN_VOICE_GATE_QUALIFY = 1,
    DSD_SCAN_VOICE_GATE_VOICE = 2,
    DSD_SCAN_VOICE_GATE_TAIL = 3,
} dsd_scan_voice_gate_phase;

/** Why the receiver is staying on the scanner's current row (issue #508). Frontend-neutral:
 * the decoder owns every deadline and the UI only renders what is published. NONE means
 * nothing holds the row -- for --trunk-scan that is exactly the old "not held" verdict. */
typedef enum {
    DSD_SCAN_STAY_NONE = 0,
    DSD_SCAN_STAY_RETUNE_PENDING = 1, /**< a backend retune request has not resolved */
    DSD_SCAN_STAY_RETUNE_RETRY = 2,   /**< retune failed; cooling down before retrying in place */
    DSD_SCAN_STAY_CC_ACQUIRE = 3,     /**< trunking SM is acquiring a control channel */
    DSD_SCAN_STAY_CALL_FOLLOW = 4,    /**< trunking SM is following a call, hangtime included */
    DSD_SCAN_STAY_VOICE = 5,          /**< conventional row: voice media is active */
    DSD_SCAN_STAY_ACTIVITY_HOLD = 6,  /**< conventional row: activity hold / voice tail running */
    DSD_SCAN_STAY_MANUAL_HOLD = 7,    /**< operator hold (Y): the dwell is paused, not expired */
    DSD_SCAN_STAY_IDLE_DWELL = 8,     /**< nothing holds it; the idle dwell / qualify window runs */
    DSD_SCAN_STAY_HANGTIME = 9,       /**< -Y legacy rule: waiting out -t since the last sync */
    DSD_SCAN_STAY_CARRIER = 10,       /**< analog row: its carrier is open (issue #526) */
    DSD_SCAN_STAY_TONE_PENDING = 11,  /**< analog row: carrier open, the tone policy still checking (issue #527) */
} dsd_scan_stay_reason;

/** Live scan timing for the frontends' Scan Timing row (issue #508). Plain inline
 * scalars: it rides the vertex_ks_count..ui_msg snapshot copy range (ui_snapshot.c static
 * assert) and must never grow a pointer, or the byte-range copy would alias decoder memory. */
struct dsd_scan_timing_publication {
    double started_m;  /**< monotonic start of the live window; < 0 when there is none */
    double deadline_m; /**< monotonic expiry; < 0 = no live timer (suspended/paused/unanchored) */
    /** Monotonic expiry of the per-visit cap (issue #507); < 0 = no live cap, whether it is
     * disabled, not yet anchored, or suspended by a hold. Never zeroed into place: 0.0 would
     * read as a deadline at monotonic 0, which is long past. */
    double visit_deadline_m;
    uint32_t span_ms;  /**< full width of the live window; 0 when there is no timer */
    uint32_t dwell_ms; /**< effective idle dwell (or -Y qualify) for the row on air; 0 = n/a */
    uint32_t hold_ms;  /**< effective activity hold; 0 on trunked rows and when n/a */
    /** Effective per-visit cap for the row on air in ms; 0 = off (issue #507). */
    uint32_t visit_limit_ms;
    uint32_t hang_ms;     /**< active protocol's effective hangtime budget; 0 when n/a */
    uint8_t reason;       /**< dsd_scan_stay_reason */
    uint8_t conventional; /**< 1 = conventional / -Y row, so hold_ms means something */
};

/** Which sub-audible signalling the analog receiver has identified: a CTCSS tone (issue #522)
 * or a DCS code (issue #523). */
typedef enum {
    DSD_ANALOG_TONE_KIND_NONE = 0,
    DSD_ANALOG_TONE_KIND_CTCSS = 1,
    DSD_ANALOG_TONE_KIND_DCS = 2,
} dsd_analog_tone_kind;

/** Where received-tone detection stands (issue #522).
 * INACTIVE: nothing has been processed since the last reset (a retune, row or target change,
 * input switch, mode change or stop), or detection is not running at all. It does not by
 * itself mean detection is off: whether detection runs is dsd_analog_tone_detection_active()
 * (runtime/analog_tones.h), which frontends and receive policy ask instead.
 * IDLE: detection runs but there is no carrier. ACQUIRING: carrier present, no verdict yet.
 * LOCKED: a supported tone is confirmed. NONE: carrier present and no supported tone found
 * (or the tone was lost). UNAVAILABLE: detection is on, but the input rate is one the
 * sub-audible front end cannot use (below 2400 Hz or above 320 kHz), so nothing can be
 * detected until the rate changes. */
typedef enum {
    DSD_ANALOG_TONE_STATE_INACTIVE = 0,
    DSD_ANALOG_TONE_STATE_IDLE = 1,
    DSD_ANALOG_TONE_STATE_ACQUIRING = 2,
    DSD_ANALOG_TONE_STATE_LOCKED = 3,
    DSD_ANALOG_TONE_STATE_NONE = 4,
    DSD_ANALOG_TONE_STATE_UNAVAILABLE = 5,
} dsd_analog_tone_state;

/** The configured tone policy's verdict on the reception (issue #527; src/dsp/analog_tone_policy.c).
 * OFF: no policy is in force (none configured, or detection is not running: the AM monitor, a digital mode), and
 * the ordinary carrier squelch alone decides. PENDING: a list policy is in force and nothing is decided yet --
 * no carrier, or a carrier inside its acquisition window. ALLOWED / REJECTED: decided, and re-evaluated for as long
 * as the transmission lasts. The monitor plays only OFF and ALLOWED, and only they are scan activity: a PENDING
 * carrier holds a scan row only while it lasts, leaving no tail, and a REJECTED one holds none. */
typedef enum {
    DSD_ANALOG_TONE_GATE_OFF = 0,
    DSD_ANALOG_TONE_GATE_PENDING = 1,
    DSD_ANALOG_TONE_GATE_ALLOWED = 2,
    DSD_ANALOG_TONE_GATE_REJECTED = 3,
} dsd_analog_tone_gate;

/** What the analog receiver hears below the voice band, for every frontend (issue #522).
 * Written only by the DSP tap on the decoder thread (src/dsp/analog_rx.c). Plain int
 * scalars: it rides the vertex_ks_count..ui_msg snapshot copy range (ui_snapshot.c static
 * assert), so it must never grow a pointer, and it holds no float, so the semgrep float-field
 * list does not change. The detector's working state lives in DSD_STATE_EXT_DSP_ANALOG_RX. */
struct dsd_analog_rx_publication {
    /** 1 while a carrier is open, held through the 200 ms hangover. On stdin, UDP and TCP input
     * and on a live radio stream the tap cannot clear it while no samples arrive, so a reader of
     * carrier_open or tone_state must also honour stale_after_ms, as dsd_app_rx_tone_view()
     * does. Kept on the AM monitor too, where no detection runs and tone_state stays INACTIVE
     * (issue #524). */
    int carrier_open;
    int tone_kind;       /**< dsd_analog_tone_kind; NONE unless tone_state is LOCKED */
    int tone_state;      /**< dsd_analog_tone_state */
    int ctcss_tenths_hz; /**< locked CTCSS tone in tenths of a hertz (1000 = 100.0 Hz); 0 = none */
    /** 1 while the locked CTCSS tone was confirmed only by allowing for transmitter tone error, off its table value by
        more than the detector's 0.5 Hz on-value gate (issue #643; 150.6 Hz read as 150.0). The tone policy may pass the
        reception on it at once, but rejects on it only when its window ends. 0 otherwise. */
    int ctcss_off_value;
    int dcs_code;     /**< locked DCS code as its value (023 octal = 19); 0 = none */
    int dcs_inverted; /**< 1 = the locked code is named in inverted polarity (the canonical member
                              of its alias class, runtime/analog_tones.h: never, for the standard set) */
    /** 1 while, with a carrier and nothing locked -- or only an off-value CTCSS tone (ctcss_off_value) -- the DCS
        detector holds a candidate code it has not confirmed: some slicer read a supported code's word once (issue
        #527). The tone policy waits past its window for it. Not tone_state's ACQUIRING, which turns NONE 500 ms into a
        carrier with nothing locked. */
    int dcs_candidate;
    int gate; /**< dsd_analog_tone_gate: the configured tone policy's verdict (issue #527) */
    /** 1 when gate was decided because no tone or code was confirmed within the acquisition window (an allow list's
        "no tone" rejection, a block list's "no tone" pass); 0 when a confirmed value decided it, or nothing is
        decided. */
    int gate_no_tone;
    /** 1 once a reception the policy rejected has ended -- its carrier's 200 ms hangover ran out, or its input paused,
        with gate REJECTED -- until the next carrier opens, the policy changes or the tap resets for any other reason
        (a retune, a row or target change, an input switch, a mode change). gate is back to PENDING by then; this keeps
        the rejection for the scanners (issue #527), so that traffic rejected between two of their passes does not hold
        the row on a window still running from before it (-t since the row landed or since traffic the policy passed, a
        trunk-scan activity hold). */
    int gate_rejected_ended;
    /** Bumped on every reset (retune, row or target change, input switch, mode change, stop,
     * input-rate change, carrier hangover, stream pause), so a reader can tell a new reception
     * from the one it last saw. */
    uint32_t generation;
    /** Real monotonic ms (dsd_realtime_mono_ms()) after which this publication no longer describes
     * the channel if the tap has not run again since. Set only on input that may pause: stdin,
     * UDP and TCP, whose producer may stop sending between transmissions, and live RTL-family
     * radio streams, which stop when their source does (an rtl_tcp server that went away, a
     * stalled device). Then no samples arrive for the sample-time hangover to count, and a
     * frontend reads the publication past this point as no carrier
     * (app_control/rx_tone_view.h). 0 = never stale (files, Pulse and IQ replay deliver
     * continuously). */
    uint64_t stale_after_ms;
};

// dsd_state is a C aggregate, not a C++ class: it is allocated once and zeroed by
// initState() before anything reads it, and C code — which is most of its users —
// has no constructors to write. A C++ TU that includes this header would otherwise
// report every one of its ~600 members, one finding per field of a struct nobody
// default-constructs. Scoped to this struct rather than to the file, which is what
// a --suppress on the command line could only do: the seventeen other types
// declared here, and every real C++ class in the tree, still get checked.
//
// Inert on cppcheck 2.21 — the check does not fire on a struct with no member
// functions at all — so this is insurance against a version that does, not a live
// carve-out. Unmatched suppressions are already suppressed tree-wide.
// cppcheck-suppress-begin uninitMemberVarNoCtor
struct dsd_state {
    int* dibit_buf;
    int* dibit_buf_p;
    int* dmr_payload_buf;
    int* dmr_payload_p;
    // Per-dibit signed soft metrics. Aligned with dmr_payload_buf.
    dsd_dibit_soft_t* dmr_soft_buf;
    dsd_dibit_soft_t* dmr_soft_p;
    int repeat;
    short* audio_out_buf;
    short* audio_out_buf_p;
    short* audio_out_bufR;
    short* audio_out_buf_pR;
    float* audio_out_float_buf;
    float* audio_out_float_buf_p;
    float* audio_out_float_bufR;
    float* audio_out_float_buf_pR;
    float* aout_max_buf_p;
    float* aout_max_buf_pR;
    struct mbe_parameters* cur_mp;
    struct mbe_parameters* prev_mp;
    struct mbe_parameters* prev_mp_enhanced;
    struct mbe_parameters* cur_mp2;
    struct mbe_parameters* prev_mp2;
    struct mbe_parameters* prev_mp_enhanced2;
    // 64-bit state placed early to reduce padding
    unsigned long long int payload_mi;
    unsigned long long int payload_miR;
    unsigned long long int payload_miN;
    unsigned long long int payload_miP;
    unsigned long long int K;
    unsigned long long int K1;
    unsigned long long int K2;
    unsigned long long int K3;
    unsigned long long int K4;
    uint8_t hytera_key_segments;
    unsigned long long int R;
    unsigned long long int RR;
    uint8_t scalar_key_present[2];
    uint8_t basic_key_present;
    unsigned long long int H;
    unsigned long long int HYTL;
    unsigned long long int HYTR;
    long int bit_counterL;
    long int bit_counterR;
    unsigned long long int p2_wacn;
    unsigned long long int p2_sysid;
    unsigned long long int p2_cc; //p1 NAC
    /* 1 once p2_cc is proven on the carrier being decoded: a burst descrambled with it (a scrambled FACCH or SACCH, or an
     * ESS) passed its Reed-Solomon check, or a CRC-checked network status broadcast named it. Only then is p2_cc a
     * Phase 2 call's received NAC (issue #575): a call carried by unscrambled FACCH/SACCH never tests the seed, which
     * -X or another carrier may have left. 0 at every carrier boundary and whenever p2_cc changes; p2_cc itself, the
     * descrambling key, is never reset for it. */
    uint8_t p2_cc_verified;
    unsigned long long int p2_siteid;
    unsigned long long int p2_rfssid;
    long int p25_cc_freq;        // P25 control-channel frequency from network status
    long int trunk_cc_freq;      // generic trunk-owner control-channel frequency
    int trunk_recovery_protocol; // validated owner; runtime trunk-scan recovery enum, survives raw sync loss
    unsigned long long int edacs_site_id;
    time_t last_cc_sync_time;    //use this to start hunting for CC after signal lost
    time_t p25_last_cc_msg_time; //last decoded P25 control-channel message
    time_t last_vc_sync_time;    //flag for voice activity bursts, tune back on con+ after more than x seconds no voice
    // Timestamp of last tune to a VC (used to provide a short startup grace
    // window so we don't bounce back to CC before MAC_PTT/ACTIVE/audio arrives)
    time_t p25_last_vc_tune_time;
    // Monotonic twins for SM timing (seconds)
    double last_cc_sync_time_m;
    double p25_last_cc_msg_time_m;
    double last_vc_sync_time_m;
    double p25_last_vc_tune_time_m;
    time_t rtl_fsk_reacquire_last_sync_time;
    double rtl_fsk_reacquire_last_sync_m;
    double rtl_fsk_reacquire_gap_start_m;
    double rtl_fsk_reacquire_last_request_m;
    time_t last_t3_tune_time;   // last time a DMR T3 grant was received (wall clock)
    double last_t3_tune_time_m; // same as above, monotonic seconds
    // DMR: rate-limit for single-fragment SLCO logging per slot
    time_t slco_sfrag_last[2];
    //event history itemized per slot
    Event_History_I* event_history_s;
    // Decoder-thread-only scoped DSD_CRC_* provenance bits (crc_provenance.h) for the content being decoded;
    // dispatch ORs its bits in and must save and restore each slot.
    uint8_t event_crc_invalid[2];
    // DMR header-chain DSD_CRC_* bits (failed, or RAS-accepted), retained until the protocol resets the assembly.
    uint8_t data_header_crc_invalid[2];
    // Codec2 contexts (NULL when codec2 unavailable; unconditional for ABI stability)
    struct CODEC2* codec2_3200; // M17 fullrate
    struct CODEC2* codec2_1600; // M17 halfrate
    void* rc2_context;
    struct RtlSdrContext* rtl_ctx; // RTL-SDR stream context (NULL when unused; unconditional for ABI stability)
    time_t ui_msg_expire;          // epoch seconds when ui_msg should stop displaying
    // AES key segments
    unsigned long long int A1[2];
    unsigned long long int A2[2];
    unsigned long long int A3[2];
    unsigned long long int A4[2];
    // DMR LRRP 64-bit values
    unsigned long long int dmr_lrrp_source[2];
    unsigned long long int dmr_lrrp_target[2];
    // 1 when the slot's last data header addressed a talkgroup (G/I bit set). The header's G/I
    // bit is gone by the time the assembled PDU decrypts, and DMR radio ids share the
    // talkgroup's 24-bit space, so the --dmr-tg-key-csv lookup needs this recorded alongside
    // the target it qualifies.
    uint8_t dmr_data_target_is_group[2];
    // P25 trunking freq storage
    long int p25_vc_freq[2];
    /* With trunking off, the voice channel frequency a grant update named for the target of a call active on this
       carrier, kept per slot with that target (issue #575): a call takes it only when it has that target, never another
       call's (p25_conventional_grant_frequency()). */
    long int p25_conventional_grant_freq[2];
    uint32_t p25_conventional_grant_target[2];
    long int trunk_vc_freq[2]; // generic trunk-owner voice-channel frequencies
    // Trunking LCNs and maps
    long int trunk_lcn_freq[DSD_TRUNK_LCN_EMBEDDED];
    long int trunk_chan_map[DSD_TRUNK_CHAN_MAP_SIZE];
    uint16_t trunk_chan_map_used[DSD_TRUNK_CHAN_MAP_SIZE];
    uint32_t trunk_chan_map_used_count;
    uint64_t trunk_chan_map_seq;
    /* Scan-list tail beyond the DSD_TRUNK_LCN_EMBEDDED inline slots (NULL until a longer list is
     * imported). dsd_state_trunk_lcn_slot() abstracts both segments. Never inside
     * a UI_SNAPSHOT_COPY_RANGE: the first range ends at trunk_lcn_freq and members
     * from trunk_chan_map on are copied explicitly. */
    long int* trunk_lcn_freq_ext;
    size_t trunk_lcn_freq_ext_capacity;
    /* Optional operator-supplied name per scan-list row, indexed by LCN row index the
     * way dsd_state_trunk_lcn_slot() indexes the frequencies. NULL until a channel-map
     * CSV opts in with a `name` header column, and shorter than the list when only the
     * first rows are named -- read it through dsd_state_trunk_lcn_name_get(). Never
     * inside a UI_SNAPSHOT_COPY_RANGE, for the same reason as trunk_lcn_freq_ext above:
     * a byte copy of the pointer would alias the decoder's buffer into the snapshot. */
    char (*trunk_lcn_name)[DSD_CHANNEL_LABEL_SIZE];
    size_t trunk_lcn_name_capacity;
    /* Session-only "avoid" flag per scan-list row, indexed like trunk_lcn_name. NULL until
     * the operator avoids a row, and shorter than the list is normal -- read it through
     * dsd_state_trunk_lcn_avoid_get(). Never persisted; chan_map_adopt(),
     * svc_clear_channel_map() and DSD_APP_CMD_SCAN_AVOID_CLEAR drop it. Never inside a
     * UI_SNAPSHOT_COPY_RANGE, for the same reason as the two stores above. */
    uint8_t* trunk_lcn_avoid;
    size_t trunk_lcn_avoid_capacity;
    /* Sparse per-row key set per scan-list row, indexed like trunk_lcn_name. NULL until a
     * channel-map CSV opts in with a key-file or direct-key header column. Read it through
     * dsd_state_trunk_lcn_keys_get(); returned pointers are decoder-thread-only and invalidated
     * by later store growth. Never inside a UI_SNAPSHOT_COPY_RANGE, for the same reason as the
     * stores above -- and additionally because key material is never deep-copied into the
     * snapshot. */
    dsd_key_set* trunk_lcn_keys;
    size_t trunk_lcn_keys_capacity;
    /* Scan key swap state: the lazily captured global keys plus the active row set copy.
     * Sits in the same uncopied gap as the stores above. */
    dsd_key_set scan_keys_baseline;
    dsd_key_set scan_keys_active;
    uint8_t scan_keys_active_set;
    // DMR Tier III: simple provenance/trust for learned LCN->freq mappings
    // 0=unset, 1=learned (unconfirmed), 2=trusted (confirmed on-current-site CC)
    uint8_t dmr_lcn_trust[0x1000];
    // DMR late entry MI
    uint64_t late_entry_mi_fragment[2][8][3];
    // Multi-key array
    unsigned long long int rkey_array[0x1FFFF];
    unsigned char rkey_array_loaded[0x1FFFF];
    // DMR talkgroup -> key ID override map (--dmr-tg-key-csv): a mapped talkgroup
    // selects its key id in place of the OTA-signaled one at key-activation time.
    // payload_keyid* stay the OTA truth; the map only steers the keyring lookup.
    //
    // Declared beside the keyring it indexes rather than beside the other DMR crypto state, for the
    // same reason rkey_array lives here: ui_snapshot.c copies positional byte ranges of dsd_state on
    // every telemetry publish and consume, and this write-once CLI table is not something the UI
    // renders. This region falls between two of those ranges, so it costs the snapshot nothing.
    uint32_t dmr_tg_key_map_tg[DSD_DMR_TG_KEY_MAP_MAX];
    uint8_t dmr_tg_key_map_kid[DSD_DMR_TG_KEY_MAP_MAX];
    int dmr_tg_key_map_count;
    // Per-slot applied-notice latch: one notice per call epoch. Epoch 0 is never a live call
    // (dsd_call_state_get only reports a hit for a non-zero epoch), so it doubles as "never noted".
    uint64_t dmr_tg_key_note_epoch[2];
    /* Own latch, not shared with dmr_tg_key_note_epoch: the applied and skipped notices report
       opposite outcomes, so one latch let whichever fired first silence the other for the whole
       epoch -- even after the situation changed (a key imported mid-call, for instance). */
    uint64_t dmr_tg_key_skip_epoch[2];
    // Temporary audio buffers
    float audio_out_temp_buf[160];
    float* audio_out_temp_buf_p;
    float audio_out_temp_bufR[160];
    float* audio_out_temp_buf_pR;
    //analog/raw signal audio buffers (float path for better SNR, convert to int16 at output)
    float analog_out_f[960]; // float buffer for analog monitor path
    short analog_out[960];   // int16 buffer for analog monitor output
    int analog_sample_counter;
    /* The auto squelch's gate flag for each sample of analog_out_f (DSD_SQUELCH_FLAG_CLOSED, 0 open), as the RTL stream
       read it with the sample, and the monitor sink's gain, which ramps between closed and open samples. */
    uint8_t analog_out_flags[960];
    float analog_sink_gain;
    /* The rate the analog block being collected runs at, and what it started under: the PCM input rate and stream
       generations and, on RTL input, the stream generation of its samples (issue #633). A sample collected at another
       rate marks the block mixed: it neither plays nor goes to the -6 WAV. */
    int analog_block_rate_hz;
    uint32_t analog_block_rate_gen;
    uint32_t analog_block_pcm_gen;
    uint32_t analog_block_rtl_gen;
    uint8_t analog_block_mixed;
    /* The rate the analog sinks last said they had no memory to convert, so that is said once per rate. */
    int analog_sink_nomem_hz;
    //new stereo short sample storage
    short s_l[160]; //single sample left
    short s_r[160]; //single sample right
    /* Per slot: 1 when the vocoder left the current frame's short samples out of s_l/s_r (it staged silence, or
       skipped short staging), 0 when dsd_voice_stage_short_left/right() staged them there. The P25 Phase 2 playout
       reads it to tell decoded audio from silence (issue #651). */
    uint8_t mbe_short_silenced[2];
    /* Per slot: the vocoder's verdict on the slot's last voice frame (issue #655), 1 when it is muted: by encryption
       (judged by the protocol that owns the call, after the frame's keystream), the user's encrypted-audio mute,
       reverse mute (-q), or DMR mono not playing the slot. Short staging, the per-call WAV, MBE capture and the DMR
       mixes all read it, so they agree; see dsd_voice_crypto_audible() in <dsd-neo/core/audio.h>. */
    uint8_t mbe_slot_muted[2];
    short s_l4[18][160]; //quad sample for up to a P25p2 4V
    short s_r4[18][160]; //quad sample for up to a P25p2 4V
    //new stereo short sample storage tapped from 48_k internal upsampling
    short s_lu[160 * 6];     //single sample left
    short s_ru[160 * 6];     //single sample right
    short s_l4u[4][160 * 6]; //quad sample for up to a P25p2 4V
    short s_r4u[4][160 * 6]; //quad sample for up to a P25p2 4V
    int audio_out_idx;
    int audio_out_idx2;
    int audio_out_idxR;
    int audio_out_idx2R;
    float center;
    int jitter;
    int synctype;
    float min;
    float max;
    float lmid;
    float umid;
    float minref;
    float maxref;
    float lastsample;
    float sbuf[128];
    int sidx;
    float maxbuf[1024];
    float minbuf[1024];
    double maxbuf_sum;
    double minbuf_sum;
    int minmax_sum_window;
    int midx;
    char err_str[64];
    char err_buf[64];
    char err_strR[64];
    char err_bufR[64];
    char fsubtype[16];
    char ftype[16];
    /* Free-running count of symbols getSymbol() has produced. Unsigned because it is only
     * ever incremented and differenced modulo 2^32: a signed counter overflowed after about
     * 5.2 days at 4800 symbols/s, which is undefined behaviour and aborts a UBSan build
     * (#395). Readers must treat it as wrapping -- compare differences, never magnitudes. */
    uint32_t symbolcnt;
    uint32_t
        datascope_symbolcnt_mark; /* symbolcnt at the datascope's last refresh: the refresh never resets symbolcnt */
    int symbolc;
    uint8_t symbol_replay_format;         /* DSD_SYMBOL_REPLAY_FORMAT_* */
    uint8_t symbol_replay_header_checked; /* header probe already done for current symbol file */
    uint8_t symbol_replay_has_soft;       /* current replay record supplied soft metrics */
    dsd_dibit_soft_t symbol_replay_soft;
    float symbol_replay_soft_symbol;
    /* The symbol the replay reader (soft capture or float symbol file) just gave had no usable stored amplitude
       (NaN, infinite, out of range, or past the end) and stands in as 0: an erasure, whatever the thresholds. */
    uint8_t symbol_replay_symbol_unusable;
    unsigned int symbol_replay_soft_records;
    unsigned int symbol_capture_soft_records;

    /* RTL DSP direct-output cache. The RTL demod thread produces direct FSK/CQPSK
       blocks; this lets getSymbol() consume them without one ring read per sample. */
    float rtl_symbol_cache[DSD_RTL_SYMBOL_CACHE_CAP];
    int rtl_symbol_cache_pos;
    int rtl_symbol_cache_len;
    int rtl_symbol_cache_output_kind;
    int rtl_symbol_cache_channel_profile;
    int rtl_symbol_cache_symbol_rate_hz;
    int rtl_symbol_cache_levels;
    uint32_t rtl_symbol_cache_generation;
    int rtl_symbol_cache_published_pending;
    /* The I/Q replay batch the cached samples come from: the capture time it spans, its sample count, and the batch
       index of rtl_symbol_cache[0]. Each sample the cache hands out runs the decode clock's media time to its own
       capture time (issue #572); a count of 0, as after a live read, runs nothing. */
    uint64_t rtl_symbol_cache_media_start_ns;
    uint64_t rtl_symbol_cache_media_duration_ns;
    uint32_t rtl_symbol_cache_media_count;
    uint32_t rtl_symbol_cache_media_first_index;
    /* The centre in Hz that batch was captured on, which each sample the cache hands out publishes as
       dsd_opts::iq_replay_center_freq (issue #575); 0, as after a live read, publishes nothing. */
    uint32_t rtl_symbol_cache_center_hz;
    int rtl_fsk_sps_num;
    int rtl_fsk_sps_den;
    int rtl_fsk_sps_accum;

    /* C4FM timing assist (clock loop hinting). Lightweight EL/M&M error drives
       occasional ±1 nudges of symbolCenter; disabled by default. */
    int rf_mod;
    /* M17 polarity auto-detection: 0=unknown, 1=normal, 2=inverted.
     * Set when preamble detected; overridden if user specifies -xz. */
    int m17_polarity;
    /* Multi-rate sync hunting: cycle through symbol-rate candidates when no sync found.
     * The hunt spends a symbol budget rather than counting sync attempts, because an
     * isolated sync that no protocol turns into a frame must not buy the profile more
     * time (see frame_sync_no_sync_sps_hunt()).
     * sps_hunt_counter: symbols the search burned that no frame handler claimed. Symbols
     *   spent looking for a sync count up; symbols a handler consumed on one sync are
     *   debited back, floored at zero, so a profile carrying traffic sits at zero and a
     *   profile matching nothing reaches its dwell. The budget belongs to the profile, so
     *   zeroing this alone is not a complete reset: a profile change owes this and
     *   sps_hunt_symbolcnt_mark together. frame_sync_apply_sps_hunt_profile() does both
     *   whenever it moves the index, so its callers need not -- but it is not the only way
     *   sps_hunt_idx moves, and the sites that assign the index directly still owe both
     *   themselves (#394). Most of them still do not: the app-control and engine
     *   retune paths (svc_publish_symbol_profile(), set_cc_symbol_timing(),
     *   dsd_engine_select_p25_sps_profile(), no_carrier_apply_p25_cc_symbolrate() and the
     *   two trunk-scan target helpers) zero the counter and leave the anchor where it was,
     *   which is harmless only because whatever that anchor then credits is debited from the
     *   counter they just zeroed and floored there; the -m2/-m3/-m4 branches of the CLI 'm'
     *   case do neither, and are benign only because they run before the first
     *   getFrameSync(). dsd_frame_sync_sps_hunt_restart_dwell() is the one that pays in
     *   full, and is what a new direct assigner should call.
     * sps_hunt_counter_at_entry: sps_hunt_counter as this search cycle began, so a frame
     *   the engine declined to dispatch can hand back exactly what that cycle's search
     *   charged and nothing else (DSD_FRAME_VERDICT_WITHHELD, #392). Restoring to a
     *   snapshot rather than subtracting a count keeps it exact without a second counter:
     *   charging happens only inside frame_sync_advance_sync_window(), between this being
     *   stamped and the verdict being read. The restore is clamped so it can only lower the
     *   counter, which is what makes it safe against the resets that fire in between -- a
     *   profile change, a retune, a trunk-scan target switch -- none of which this can undo.
     * sps_hunt_symbolcnt_mark: dsd_state::symbolcnt as getFrameSync() last returned, so
     *   the next call can measure what the handler consumed in between. It shares that
     *   field's unsigned wrapping type, so the difference stays exact across the counter's
     *   2^32 rollover. Credit is per sync and only counts once it reaches a frame's worth,
     *   which is what keeps the dwell independent of how often an unproductive matcher fires.
     *   Re-anchored alongside the counter whenever frame_sync_apply_sps_hunt_profile() moves
     *   the index, so a fresh budget is never paired with an anchor taken under the outgoing
     *   profile. Inside getFrameSync() the mark is already current at every such call, so that
     *   half is contract rather than repair; it is what a direct assigner would have to do for
     *   itself.
     * sps_hunt_last_frame_verdict: what the last frame handler made of what it consumed,
     *   as a dsd_frame_verdict (engine/protocol_dispatch.h). A field rather than a return
     *   value because frame sync reads it at the next getFrameSync() entry, not at the
     *   call site. Zero is DSD_FRAME_VERDICT_PRODUCTIVE, so a handler that reports nothing
     *   -- and a zeroed dsd_state -- is credited as having decoded a frame; only a
     *   protocol that ran a check and failed it debits nothing (#391), and only one whose
     *   check proves the profile restarts the dwell outright (#400). A frame the engine
     *   declined to dispatch at all is neither, and refunds its own search instead (#392).
     *   Strictly per frame,
     *   so unlike the two fields above it owes a profile change nothing: processFrame()
     *   re-stamps it on every dispatch and
     *   frame_sync_sps_hunt_note_handler_consumption() clears it on every read, so it
     *   cannot survive into the profile that follows.
     * sps_hunt_idx: current rate/profile index
     * (0=4800/4-level, 1=2400/4-level, 2=9600/binary, 3=6000/4-level, 4=4800/binary) */
    int sps_hunt_counter;
    uint32_t sps_hunt_symbolcnt_mark;
    int sps_hunt_last_frame_verdict;
    int sps_hunt_counter_at_entry;
    int sps_hunt_idx;
    /* Parity toggle for the P25p1 modulation probe: which modulation the next hunt re-entry
     * into the 4800/4-level profile watches. Zero-init keeps the first re-entry on C4FM.
     * p25_p1_mod_probe_active marks the one dwell a probe is on trial for, so the modulation
     * votes cannot take the demodulator back before the trial has had a chance to decode
     * anything -- entering GFSK needs a single vote, which is a few dozen symbols. */
    int p25_p1_mod_probe_next_qpsk;
    int p25_p1_mod_probe_active;
    /* Where the last accepted dPMR FS2 sync sat in dsd_state::symbolcnt, and whether one has
     * been seen at all. dPMR and NXDN48 are the two candidates on the 2400/4 profile, and their
     * matchers are not comparable: FS2 is one exact 12-symbol pattern, while the NXDN matcher
     * takes five variants per polarity over ten sign-sliced symbols and so fires on about 1% of
     * arbitrary windows. The 372 dibits behind an accepted FS2 are dPMR's frame, and an NXDN
     * accept inside them consumes symbols that frame needed and warm-starts the slicer from ten
     * symbols of dPMR payload -- which is what left AUTO decoding corrupted dPMR identities that
     * the native preset reads cleanly (#374). The span is read by src/dsp only, through
     * dsd_frame_sync_suppress_nxdn48_sync(); the stamp wraps with symbolcnt and is compared as a
     * modular difference, so a rollover mid-frame stays exact. */
    uint32_t dpmr_fs2_frame_symbolcnt;
    uint8_t dpmr_fs2_frame_valid;
    /* The same idea one profile up, where 4800/4 carries P25p1, DMR, NXDN96, YSF and M17 at once.
     * P25p1's sync is one of two exact 24-symbol patterns, so it fires on noise about once per
     * 8.4 million windows; NXDN96's takes five variants per polarity over ten sign-sliced symbols
     * and fires on roughly 1%, and M17's preamble is any alternating run at all. Inside the frame
     * a P25p1 sync opened, those two are wrong by construction, and what they cost is measurable:
     * on tests/fixtures/iq/p25p1_c4fm_cc.iq.json the native preset decodes 26 NIDs and AUTO
     * decoded none, every sync reading NAC 000 duid:EE, because the false accepts consume the
     * symbols the frame needed, warm-start the slicer from P25 payload, and clobber the
     * lastsynctype that keeps use_symbol()'s C4FM threshold tracker engaged between syncs (#388).
     * Stamped only when the C4FM chain carried the sync: on CQPSK the NID is sliced by the QPSK
     * chain and the NXDN matcher's level blend is the wideband tracker that chain relies on, so a
     * CQPSK accept clears the span instead of opening one. A GFSK vote landing mid-span leaves it
     * standing -- the flap is what the span exists to survive. Read by src/dsp only, through
     * dsd_frame_sync_suppress_4800_4_for_p25p1_frame(); compared as a modular difference, so a
     * symbolcnt rollover mid-frame stays exact. */
    uint32_t p25_p1_c4fm_frame_symbolcnt;
    uint8_t p25_p1_c4fm_frame_valid;
    /* Which SPS profile a protocol last passed a content check on, when, and whether any has
     * been recorded at all. The two spans above cover a frame another protocol is in the middle
     * of; this one covers the transmission a protocol has been decoding, which is the case
     * neither of them reaches: under AUTO the hunt rotates off 2400/4 while an NXDN48 call is
     * still on air, and by the time it comes round to 4800/4 the NXDN96 and M17 matchers there
     * claim the transmission that never stopped (#445).
     *
     * The flag, not the index, says whether anything is armed -- profile index 0 is 4800/4, so a
     * zeroed state would otherwise read as a proof on that profile at symbol zero. Protocol-blind
     * on purpose: dPMR's CCH CRC-7 and NXDN's confirmation CRCs both prove 2400/4, and a live
     * transmission of either faces the same claimants on the profile the hunt steps to.
     *
     * Written by the protocol handlers through dsd_frame_sync_note_profile_proof(), deliberately
     * not derived from DSD_FRAME_VERDICT_PROFILE_PROVEN: that verdict restarts the hunt's dwell,
     * and measurement on the #445 capture showed doing so for NXDN costs more decoded calls than
     * it wins (see src/engine/dispatch/dispatch_nxdn.c). Recording the proof is separable from
     * acting on it, and only the recording is wanted here.
     *
     * Not cleared with the carrier, and must not be: every step of the hunt runs noCarrier(), so
     * clearing it there would erase the stamp exactly when the transmission it vouches for is
     * still on air. It expires on its own instead. Read by src/dsp only, through
     * dsd_frame_sync_suppress_4800_4_for_2400_4_transmission(); compared as a modular difference,
     * so a symbolcnt rollover stays exact. */
    int profile_proof_idx;
    uint32_t profile_proof_symbolcnt;
    uint8_t profile_proof_valid;
    int lastsynctype;
    int lastp25type;
    int offset;
    int carrier;
    char tg[25][16];
    int tgcount;
    uint8_t eh_index;
    uint8_t eh_slot;
    int nac;
    int errs;
    int errs2;
    int errsR;
    int errs2R;
    int mbe_file_type;
    int optind;
    // CLI argv/argc snapshot for file playback modes (set by frontend)
    int cli_argc_effective;
    char** cli_argv;
    // User config autosave state (set by frontend when config is active)
    int config_autosave_enabled;
    char config_autosave_path[1024];
    int numtdulc;
    int firstframe;
    char slot0light[8];
    float aout_gain;
    float aout_gainR;
    float aout_gainA;
    float aout_max_buf[200];
    float aout_max_bufR[200];
    int aout_max_buf_idx;
    int aout_max_buf_idxR;
    int samplesPerSymbol;
    int symbolCenter;
    char algid[9];
    char keyid[17];
    int currentslot;
    int hardslot;
    int p25kid;
    int payload_algid;
    int payload_algidR;
    int payload_keyid;
    int payload_keyidR;
    int payload_mfid;
    int payload_mfidR;
    int p25vc;
    int M;

    //AES Key Segments
    int aes_key_loaded[2];
    uint8_t aes_key_segments[2];

    //xl specific, we need to know if the ESS is from HDU, or from LDU2
    int xl_is_hdu;

    unsigned int debug_audio_errors;
    unsigned int debug_audio_errorsR;
    unsigned int debug_header_errors;
    unsigned int debug_header_critical_errors;

    // NID BCH correction statistics (P25 Phase 1)
    unsigned int nid_corrections_total; /**< Running total of NID BCH corrections applied */
    unsigned int nid_failures_total;    /**< Running total of NID decode failures */
    unsigned int nid_parity_overrides;  /**< Count of accepted final parity-bit mismatches */

    int debug_mode; //debug misc things

    // Last dibit read
    int last_dibit;
    uint8_t p25_cqpsk_dibit_map_idx; // OP25-compatible CQPSK orientation map

    //input sample buffer for monitoring Input
    short input_sample_buffer;  //HERE HERE
    short pulse_raw_out_buffer; //HERE HERE

    unsigned int dmr_color_code;
    unsigned int dmr_t3_syscode;
    unsigned int nxdn_last_ran;
    /* 1 while nxdn_last_ran holds a value that is not a decoded RAN, which the terminal shows in its place: an IDAS
     * (Type-D) carrier's SCCH area bit or site type, or the fixed 7 a DCR transmission is given. 0 once a RAN field
     * (CAC, FACCH2/UDCH, SACCH, site information) writes it. Every write of a value sets it (the (unsigned)-1 resets
     * need not), and only a RAN is read as the carrier's access code (issue #575). */
    uint8_t nxdn_last_ran_stand_in;
    unsigned int nxdn_cipher_type;
    unsigned int nxdn_key;

    /* NXDN cipher-classification hysteresis (src/protocol/nxdn/nxdn_enc_class.c). The cipher
     * field reaches the decoder from several channels (VCALL, SACCH-2, SCCH) whose FEC/CRC can
     * accept a miscorrected payload, and under --enc-lockout a single non-clear observation
     * used to write a session-permanent blocking talkgroup entry and force the channel
     * released. Observations apply tentatively and must repeat before they can flip an
     * established classification or arm the lockout; user-forced scrambler modes and the
     * keyloader apply as authoritative. Values are the observed cipher plus one; 0 = none. */
    uint8_t nxdn_cipher_class;         /* applied cipher observation + 1; 0 = unclassified */
    uint8_t nxdn_cipher_class_est;     /* classification corroborated (authoritative or repeat) */
    uint8_t nxdn_cipher_class_pending; /* quarantined contradicting candidate + 1; 0 = none */

    /* NXDN frame-content confirmation (src/protocol/nxdn/nxdn_confirm.c). A sync word plus
     * a LICH is not enough to believe a frame: both are weak enough that receiver noise
     * clears them regularly. Until the frame body passes a CRC, the decoder holds back
     * everything a listener would read as a real transmission -- the scanner hold, voice,
     * the RAN, the call record. See issue #398.
     * nxdn_confirmed: this transmission has produced CRC-verified content.
     * nxdn_confirm_weak_streak: consecutive frames carrying only short-CRC evidence.
     * nxdn_confirm_frame_evidence: strongest nxdn_evidence seen since begin_frame(). */
    uint8_t nxdn_confirmed;
    uint8_t nxdn_confirm_weak_streak;
    uint8_t nxdn_confirm_frame_evidence;

    NxdnElementsContent_t NxdnElementsContent;

    char ambe_ciphered[49];
    char ambe_deciphered[49];

    unsigned int color_code;
    unsigned int color_code_ok;
    uint8_t dmr_confidence_locked;
    uint8_t dmr_confidence_color_code;
    uint8_t dmr_confidence_candidate_cc;
    uint8_t dmr_confidence_candidate_count;
    uint8_t dmr_confidence_voice_sync_seen[2];
    uint8_t dmr_confidence_voice_open[2];
    uint8_t dmr_confidence_voice_count[2];
    uint8_t dmr_confidence_mismatch_count;
    unsigned int PI;
    unsigned int PI_ok;
    unsigned int LCSS;
    unsigned int LCSS_ok;

    unsigned int dmr_fid;
    unsigned int dmr_so;
    unsigned int dmr_flco;

    unsigned int dmr_fidR;
    unsigned int dmr_soR;
    unsigned int dmr_flcoR;

    /* Live slot crypto captured by the DMR terminator handler just before its reset, so the
     * heal of a voice burst mis-typed as a terminator can restore exactly what the vocoder was
     * decrypting with. Deliberately limited to what the canonical dsd_call_snapshot cannot
     * supply -- the FID and service options the Basic Privacy gates require, the MI as the
     * superframe machinery last advanced it (the snapshot's MI can lag it), and the vendor
     * late-entry mode (dmr_le_vendor); ALGID and key id
     * are read back from the snapshot the reacquire hook receives, so they have one source of
     * truth. Indexed by slot; epoch ties each capture to the ended epoch it belongs to, so a
     * stale stash can never be applied to a later call, and the engine's retune/no-carrier
     * resets clear dmr_heal_valid alongside the payload crypto so no stash outlives the channel
     * it was captured on. Owned by src/protocol/dmr; the canonical layer never touches it. */
    unsigned long long int dmr_heal_mi[2];
    unsigned long long int dmr_heal_epoch[2];
    unsigned int dmr_heal_fid[2];
    unsigned int dmr_heal_so[2];
    uint8_t dmr_heal_le_vendor[2];
    uint8_t dmr_heal_valid[2];

    /* Per-slot DMR encryption-classification hysteresis (src/protocol/dmr/dmr_enc_class.c).
     * The service-option privacy bit arrives through channels of very different reliability --
     * a voice LC header behind a 16-bit masked CRC, an embedded LC behind a 5-bit checksum, and
     * on RAS systems no verifiable CRC at all -- so the classification the enc lockout and the
     * audio gate act on is corroborated here: strong evidence applies at once, weak evidence
     * applies tentatively and must repeat before it can flip an established classification or
     * arm the lockout. Indexed by slot. */
    uint8_t dmr_enc_class[2];         /* applied classification: 0 none, 1 clear, 2 encrypted */
    uint8_t dmr_enc_class_est[2];     /* classification corroborated (strong LC or matching repeat) */
    uint8_t dmr_enc_class_pending[2]; /* quarantined contradicting candidate (0 none, 1 clear, 2 enc) */

    /* Per-slot, per-call DMR vendor late-entry mode (DMR_LE_VENDOR_* in <dsd-neo/protocol/dmr/dmr.h>, 0 none), set
     * from verified Kirisun/Hytera Enhanced signalling. The user's late-entry setting stays in opts->dmr_le, which
     * decoding never writes (issue #657). */
    uint8_t dmr_le_vendor[2];

    char slot1light[8];
    char slot2light[8];
    int directmode;

    int dmr_stereo_payload[144];    //load up 144 dibit buffer for every single DMR TDMA frame
    uint8_t dmr_stereo_reliab[144]; //parallel reliability for stereo cache (0..255)
    int data_header_blocks[2];      //collect number of blocks to follow from data header per slot
    int data_block_counter[2];      //counter for number of data blocks collected
    uint8_t data_header_valid[2];   //flag for verifying the data header if still valid (in case of tact/burst fec errs)
    uint8_t data_header_padding[2]; //collect number of padding octets in last block per slot
    uint8_t data_header_format[2];  //collect format of data header (conf or unconf) per slot
    uint8_t data_header_sap[2];     //collect sap info per slot
    uint8_t data_p_head[2];         //flag for dmr proprietary header to follow
    uint8_t data_header_dd_format[2];   //transient per-slot DMR Defined Data format
    uint8_t data_header_bit_padding[2]; //transient per-slot DMR short-data padding in bits

    //new stuff below here
    uint8_t data_conf_data[2];   //flag for confirmed data blocks per slot
    uint8_t data_block_poc[2];   //padding octets in the header (needed for Data PDU Decryption)
    uint16_t data_byte_ctr[2];   //number of bytes acculumated
    uint8_t data_ks_start[2];    //where the start of the keystream should be applied to PDU data
    uint8_t udt_uab_reserved[2]; //UDT: header UAB indicates reserved/unknown count (use CRC-based EOM)
    uint8_t dmr_pdu_sf
        [2][24 * 128]; //unified pdu 'superframe' //[slot][byte] -- increased capacity to 127(+1) full rate blocks
    uint8_t cap_plus_csbk_bits[2][12 * 8 * 8]; //CSBK Cap+ FL initial and appended block bit storage, by slot
    uint8_t cap_plus_block_num[2];             //received block number storage -- per timeslot
    // Per-block CRC verdict on confirmed data: 1 good, 0 failed, DMR_DATA_BLOCK_CRC_RAS (2) a confirmed block whose
    // CRC9 failed but the RAS heuristic accepted under -F. Block 0 is the header and only ever holds 0 or 1.
    uint8_t data_block_crc_valid[2][127];
    // Confirmed data sequence tracking (DBSN expected per slot)
    uint8_t data_dbsn_expected[2];
    uint8_t data_dbsn_have[2];
    char dmr_embedded_signalling
        [2][7]
        [48]; //embedded signalling 2 slots by 6 vc by 48 bits (replacing TS1SuperFrame.TimeSlotRawVoiceFrame.Sync structure)

    char dmr_cach_fragment[4][17]; //unsure of size, will need to check/verify
    int dmr_cach_counter;          //counter for dmr_cach_fragments 0-3; not sure if needed yet.

    //dmr talker alias new/fixed stuff
    uint8_t dmr_alias_format[2];    //per slot
    uint8_t dmr_alias_block_len[2]; //per slot
    uint8_t dmr_alias_char_size[2]; //per slot
    char dmr_alias_block_segment[2][4][7]
                                [16]; //2 slots, by 4 blocks, by up to 7 alias bytes that are up to 16-bit chars
    char dmr_embedded_gps[2][600];    //2 slots by 99 char string for string embedded gps
    char dmr_lrrp_gps[2][600];        //2 slots by 99 char string for string lrrp gps
    char dmr_site_parms[200];         //string for site/net info depending on type of DMR system (TIII or Con+)

    //Generic Talker Alias String
    char generic_talker_alias[2][500];

    dPMRVoiceFS2Frame_t dPMRVoiceFS2Frame;

    /* dPMR frame-content confirmation (src/protocol/dpmr/dpmr_confirm.c). The 12-symbol
     * FS2 word matches about one noise window in 2048, and what stood behind it was not a
     * check: identity publishing accepted a CCH whose two leading Hamming(12,8) blocks
     * merely reported correctable, which 44% of noise superframes do. Until a CCH half
     * passes its CRC-7 the decoder publishes no identity, no call row and no voice.
     * See issue #407.
     * dpmr_confirmed: this transmission has produced a CRC-verified CCH.
     * dpmr_confirm_weak_streak: consecutive frames carrying one passing half only.
     * dpmr_confirm_frame_evidence: strongest dpmr_evidence seen since begin_frame(). */
    uint8_t dpmr_confirmed;
    uint8_t dpmr_confirm_weak_streak;
    uint8_t dpmr_confirm_frame_evidence;
    /* The scrambling the current dPMR transmission's last CRC-verified CCH half signalled (issue #655): 0 none yet,
       1 clear, 2 scrambled (Version 3). A half whose CRC-7 failed takes it; a transmission boundary forgets it. */
    uint8_t dpmr_scrambled;

    /* How recently a dPMR CCH CRC-7 passed, for the SPS hunt's profile accounting
     * (src/engine/dispatch/dispatch_dpmr.c). The flag, not the stamp, opens the window,
     * so a zeroed state reads as no evidence rather than evidence at symbol zero. */
    int dpmr_cch_evidence;
    uint32_t dpmr_cch_evidence_symbolcnt;

    //new audio filter structs
    LPFilter RCFilter;
    HPFilter HRCFilter;
    LPFilter RCFilterL;
    LPFilter RCFilterR;
    /* The digital voice high-pass per slot (0 left, 1 right); see dsd_voice_hpf_state. */
    dsd_voice_hpf_state voice_hpf[2];

    int dpmr_color_code;

    short int dmr_stereo;    //need state variable for upsample function
    short int dmr_mono_slot; //mono output slot: -1=unknown, 0=TS1/left, 1=TS2/right
    short int dmr_ms_mode;
    unsigned int dmrburstL;
    unsigned int dmrburstR;
    int dropL;
    int dropR;
    int DMRvcL;
    int DMRvcR;

    //keystream octet and bit arrays
    uint8_t ks_octetL[129 * 18];         //arbitary size, but large enough for the largest packed PDUs
    uint8_t ks_octetR[129 * 18];         //arbitary size, but large enough for the largest packed PDUs
    uint8_t ks_bitstreamL[128 * 18 * 8]; //arbitary size, but large enough for the largest PDUs
    uint8_t ks_bitstreamR[129 * 18 * 8]; //arbitary size, but large enough for the largest PDUs
    int octet_counter;

    //AES Specific Variables
    uint8_t aes_key[32]; //was 64 for some reason
    uint8_t aes_iv[16];
    uint8_t aes_ivR[16];

    //NXDN DES and AES, signal new VCALL_IV and new IV
    uint8_t nxdn_new_iv; //1 when a new IV comes in, else 0
    uint16_t nxdn_pn95_seed;

    /* NXDN's (and P25 Phase 1's) own "encrypted and no key" flag for slot 0, kept for NXDN's lockout. The audio,
       recording and capture verdict is mbe_slot_muted (issue #655); the vocoder no longer writes these. */
    short int dmr_encL;
    short int dmr_encR;

    //P2 variables
    int p2_hardset;         //flag for checking whether or not P2 wacn and sysid are hard set by user
    int p2_scramble_offset; //offset counter for scrambling application
    int p2_vch_chan_num;    //vch channel number (0 or 1, not the 0-11 TS)
    int ess_b[2][96];       //external storage for ESS_B fragments
    int16_t ess_b_llr[2][96];
    int fourv_counter[2]; //external reference counter for ESS_B fragment collection
    /* The slot's ESS_B is the carrier left's (issue #575): set by p25p2_frame_forget_carrier(), cleared when the slot's
       next 4V burst collects a fragment. A 2V burst decodes no ESS while it is set. */
    uint8_t p25_p2_ess_b_stale[2];
    int p2_is_lcch; //flag to tell us when a frame is lcch and not sacch
    // Authoritative P25 voice crypto classification. Slot 0 is also used by P25 Phase 1.
    dsd_p25_crypto_state p25_crypto_state[2];
    // Retained Phase 1 carrier requires the next transmission's LCW identity before media or lockout.
    int p25_p1_identity_pending;
    // Canonical anonymous epoch opened for the retained-carrier transmission awaiting identity.
    int p25_p1_identity_epoch_started;
    // Definitive Phase 1 HDU crypto arrived after the last authoritative LCW identity.
    int p25_p1_hdu_crypto_fresh;
    // One non-clear HDU/LDU2 tuple contradicted explicit-clear Phase 1 service options.
    dsd_p25_p1_crypto_conflict_state p25_p1_crypto_conflict;
    // One non-clear Phase 2 ESS tuple contradicted explicit-clear service context.
    dsd_p25_p2_crypto_conflict_state p25_p2_crypto_conflict[2];
    // Exact carrier/canonical epoch ended by Phase 1 encryption lockout.
    dsd_p25_p1_lockout_epoch_state p25_p1_lockout_epoch;
    // Sticky Phase 2 media rejection, cleared only after the slot receives an accepted assignment/activity.
    int p25_p2_media_rejected[2];
    // ESS identity changes staged until the paired-timeslot audio drain completes.
    dsd_p25_p2_rekey_state p25_p2_rekey[2];
    // P25p2 per-slot audio gating (set on MAC_PTT/ACTIVE, cleared on MAC_END/IDLE/SIGNAL)
    int p25_p2_audio_allowed[2];
    /* P25 Phase 2 voice playout: per-slot queues played per burst pair in both output formats (issue #651).
       Decoder-thread private; ui_snapshot skips it. */
    dsd_p25p2_playout p25p2_playout;
    // P25p2 currently active voice slot (0 or 1), -1 when unknown/idle
    int p25_p2_active_slot;
    // P25p2 recent MAC_ACTIVE/PTT timestamps per slot (guards early bounce)
    time_t p25_p2_last_mac_active[2];
    // Monotonic twins for last MAC_ACTIVE/PTT per slot
    double p25_p2_last_mac_active_m[2];
    // P25p2 recent MAC_END_PTT timestamps per slot (transmission boundaries)
    time_t p25_p2_last_end_ptt[2];
    // P25p1 recent TDU/TDULC transmission-boundary timestamp
    double p25_p1_last_tdu_m;

    // P25 Phase 2 RS(63,35) metrics (hexbits, t=14)
    unsigned int p25_p2_rs_facch_ok;
    unsigned int p25_p2_rs_facch_err;
    unsigned int p25_p2_rs_facch_corr; // total corrected symbols over accepts
    unsigned int p25_p2_rs_sacch_ok;
    unsigned int p25_p2_rs_sacch_err;
    unsigned int p25_p2_rs_sacch_corr; // total corrected symbols over accepts
    unsigned int p25_p2_rs_ess_ok;
    unsigned int p25_p2_rs_ess_err;
    unsigned int p25_p2_rs_ess_corr;     // total corrected symbols over accepts
    unsigned int p25_p2_soft_erasure_ok; // soft-decision RS successful recoveries
    // P25P1 soft decision counters
    unsigned int p25_p1_soft_hamming_ok; // soft Hamming corrections
    unsigned int p25_p1_soft_golay_ok;   // soft Golay corrections (hard would have failed)
    unsigned int p25_p1_soft_rs_ok;      // soft RS erasure corrections (hard would have failed)
    unsigned int p25_p2_soft_ess_ok;     // soft ESS corrections
    unsigned int p25_p2_soft_ess_max_depth;
    unsigned int p25_p1_soft_combined_ok;
    //iden freq storage for frequency calculations
    // Bitmask per IDEN slot indicating which modulation classes have been seen:
    //   bit 0x01 marks an FDMA/non-TDMA entry
    //   bit 0x02 marks a TDMA entry for channel types 3, 4, or 5
    // Values: 0=unknown, 1=FDMA only, 2=TDMA only, 3=both FDMA and TDMA
    uint8_t p25_chan_tdma_explicit[16];
    uint8_t p25_lcw_retune_disabled_warned; // 1 once "LCW retune disabled" warning emitted
    int p25_chan_iden;

    // Dual-array IDEN storage: separate FDMA and TDMA entries per slot.
    // This prevents multi-mode systems from cycling incompatible parameters
    // in a single slot when both TDMA and FDMA IDEN updates share the same
    // 4-bit identifier ID.
    p25_iden_entry_t p25_iden_fdma[16]; // FDMA/non-TDMA frequency-band entries
    p25_iden_entry_t p25_iden_tdma[16]; // TDMA frequency-band entries

    // User-supplied band plan (--p25-bandplan, [trunking] p25_bandplan_csv, a trunk-scan
    // target's p25_bandplan_csv, or the terminal/Qt import). Rows seed empty IDEN slots at
    // trust 1 through dsd_state_p25_bandplan_seed(); p25_update_system_identity() re-applies
    // them after a WACN/SYS change wipes the tables, and an over-the-air IDEN_UP still
    // overwrites a seeded slot. Under trunk scan each target's snapshot carries its own.
    p25_bandplan_row_t p25_bandplan_rows[DSD_P25_BANDPLAN_MAX_ROWS];
    int p25_bandplan_row_count;

    //p25 frequency storage for trunking and display in ncurses
    int p25_cc_is_tdma;  // control channel modulation: 0=FDMA (C4FM), 1=TDMA (QPSK)
    int p25_sys_is_tdma; // system hint: 1 when P25p2 voice observed (TDMA present)

    /* P25 trunk (RTL): CQPSK DSP chain selection for TDMA voice channels.
     *
     * - p25_vc_cqpsk_pref: learned preference (-1=unknown/auto,
     *   1=prefer OP25-style CQPSK+TED chain). Value 0 is treated as no learned
     *   TDMA preference so automatic retry logic does not force P25p2 through
     *   the FM/QPSK slicer.
     * - p25_vc_cqpsk_override: one-shot retry override applied on next VC tune (-1=none).
     *
     * These are ignored when the user explicitly forces CQPSK via env/config (DSD_NEO_CQPSK).
     */
    int p25_vc_cqpsk_pref;
    int p25_vc_cqpsk_override;

    /* Which demodulator last carried a P25p1 frame whose 63-bit NID BCH decoded, and when:
     * -1 never validated, 0 the C4FM path, 1 the CQPSK path. A validated frame is the only
     * direct evidence of what the signal actually is -- the SNR and sync-hamming heuristics
     * that drive the modulation votes are indirect -- so this outranks them while it is fresh.
     * System knowledge like p25_cc_is_tdma rather than acquisition state, so
     * dsd_frame_sync_reset_mod_state(), retunes and no-carrier resets leave it alone; only
     * initState(), the trunk-scan per-target snapshot and a CQPSK dwell that decodes nothing
     * reset it. Freshness is measured in symbols because the hold it feeds only applies on the
     * fixed-rate 4800/4-level profile. Ignored whenever opts->mod_cli_lock is set. */
    int p25_p1_validated_rf_mod;
    uint32_t p25_p1_validated_symbolcnt;

    /* That the signal on the current SPS profile is P25p1 at all, and when it last proved it:
     * a decoded 63-bit NID BCH, whatever the DUID turned out to be. A separate stamp from the
     * pair above rather than a reuse of it, because that pair answers a different question and
     * is scoped to it -- it is gated on opts->mod_cli_lock and on the frame having arrived
     * through the C4FM or CQPSK path, and a CQPSK dwell that decodes nothing withdraws it --
     * and none of that applies to a profile that has demonstrably carried P25p1. Stamped
     * unconditionally by every decoded NID, never by a failing one.
     *
     * What it buys is a bounded benefit of the doubt for the failures around a reception
     * (dsd_dispatch_handle_p25p1()): a P25p1 sync whose NID fails inside a window of one that
     * decoded is still evidence the profile is right, and the SPS hunt takes it as such (#400).
     * p25_p1_nid_evidence is what opens the window, not the stamp, so a zeroed dsd_state reads
     * as no evidence rather than as evidence at symbol zero. Acquisition state, so noCarrier()
     * clears it: evidence is per transmission, and the next carrier proves itself again. Left
     * alone by retunes, unlike a confirm module's flag, because a retune zeroes the hunt's
     * budget anyway -- the most a stale window can do there is re-zero a counter already at
     * zero, for at most the window's length. */
    int p25_p1_nid_evidence;
    uint32_t p25_p1_nid_evidence_symbolcnt;

    // Candidate evaluation tracking (current freq and start time in monotonic seconds)
    long p25_cc_eval_freq;
    double p25_cc_eval_start_m;
    // Persisted CC cache bookkeeping
    uint8_t p25_cc_cache_loaded; // 1 once we attempted to load per-system cache

    // Trunk SM metrics (shared by P25 and DMR trunking)
    unsigned int p25_sm_tune_count;      // number of VC tunes via SM
    unsigned int p25_sm_release_count;   // number of release requests via SM
    unsigned int p25_sm_cc_return_count; // number of actual returns to CC via SM
    unsigned int p25_sm_queued_count;    ///< number of Queued Response (QUE_RSP) messages received
    unsigned int p25_sm_deny_count;      ///< number of Deny Response (DENY_RSP) messages received
    // One-shot flag to force immediate return-to-CC on physical/policy release;
    // cleared by the SM after handling.
    int p25_sm_force_release;
    int trunk_sm_force_release; // protocol-agnostic force-release latch
    // Timestamp of last p25_sm_release() (0 when none yet)
    time_t p25_sm_last_release_time;
    // Last SM status/reason tag (e.g., "after-tune", "release-deferred-gated") and timestamp
    char p25_sm_last_reason[32];
    time_t p25_sm_last_reason_time;
    // Ring buffer of recent SM tags (for ncurses diagnostics)
    int p25_sm_tag_count;      // number of valid entries (<= 8)
    int p25_sm_tag_head;       // next write index (monotonic)
    char p25_sm_tags[8][32];   // recent tags (text)
    time_t p25_sm_tag_time[8]; // per-tag timestamp
    // Watchdog start time for prolonged post-hang gating on P25p2 VCs
    time_t p25_sm_posthang_start;
    // Monotonic twin for post-hang watchdog (seconds)
    double p25_sm_posthang_start_m;

    // High-level SM mode for UI/telemetry. A retained traffic carrier is ARMED
    // before first voice, FOLLOW while either slot is active, and HANG between
    // transmissions until the inactivity timer expires.
    int p25_sm_mode;

    // Encrypted-target lockout ledger (session-permanent; core/enc_lockout.h).
    // Entries at the current key epoch block encrypted voice-grant tuning;
    // key imports bump the epoch so each target re-verifies with one probe.
    dsd_enc_lockout_entry enc_lockout_entries[DSD_ENC_LOCKOUT_MAX];
    uint64_t enc_lockout_key_epoch;
    // Monotonic confirmation ticket handed to each armed/refreshed entry; the
    // eviction LRU orders on this rather than on one-second wall clock.
    uint64_t enc_lockout_seq;
    // P25 Phase 1 control/data channel FEC/CRC telemetry (for BER display)
    // NOTE: This does not reflect IMBE voice quality. Voice frames have their own
    // Golay/Hamming/RS protection and IMBE ECC; see P1 Voice metrics and
    // debug_{audio,header}_* counters.
    unsigned int p25_p1_fec_ok;  // count of TSBK/MDPU header CRC/FEC successes
    unsigned int p25_p1_fec_err; // count of TSBK/MDPU header CRC/FEC failures
    // P25 Phase 1 voice/header FEC telemetry (Reed-Solomon outcome for HDU/LDU/TDULC)
    unsigned int p25_p1_voice_fec_ok;  // count of successful RS decodes (HDU/LDU/TDULC)
    unsigned int p25_p1_voice_fec_err; // count of failed RS decodes (HDU/LDU/TDULC)
    // P25 Phase 1 DUID/frame-type histogram (since last tune/reset)
    unsigned int p25_p1_duid_hdu;
    unsigned int p25_p1_duid_ldu1;
    unsigned int p25_p1_duid_ldu2;
    unsigned int p25_p1_duid_tdu;
    unsigned int p25_p1_duid_tdulc;
    unsigned int p25_p1_duid_tsbk;
    unsigned int p25_p1_duid_mpdu;

    // P25 Phase 1 voice error moving average (last N IMBE frames)
    uint8_t p25_p1_voice_err_hist[64];
    int p25_p1_voice_err_hist_len;          // ring capacity (<=64), default 50
    int p25_p1_voice_err_hist_count;        // populated frames this call (<=capacity)
    int p25_p1_voice_err_hist_pos;          // ring head
    unsigned int p25_p1_voice_err_hist_sum; // sum of values in window

    // P25 Phase 1 session-lifetime voice telemetry (not reset on retune/no-carrier)
    uint64_t p25_p1_accepted_frames;
    uint64_t p25_p1_clean_frames;
    uint64_t p25_p1_corrected_frames;
    uint64_t p25_p1_concealed_frames;
    uint64_t p25_p1_accepted_corrections;
    uint64_t p25_p1_suppressed_tail_frames;
    uint64_t p25_p1_excluded_tail_corrections;

    /*
     * P25 status symbol classification.
     *
     * Accumulates 2-bit status symbol values during P25 Phase 1 frame
     * processing and produces a classification (infrastructure vs subscriber)
     * for diagnostics and optional auto-PPM gating. Status-derived direction is
     * advisory by default because some systems do not emit reliable direction
     * hints. See <dsd-neo/protocol/p25/p25_status_symbol.h> for the accumulator
     * API.
     */

    /** Accumulated status symbol values for the current data unit (2-bit each). */
    uint8_t p25_ss_buf[P25_STATUS_ACCUM_MAX];
    /** Number of status symbols collected so far in current data unit. */
    uint8_t p25_ss_count;
    /** Current data unit has an active accumulator; preserves NID status handoff from dispatcher. */
    uint8_t p25_ss_frame_active;
    /** Classification of the most recently completed data unit (p25_ss_classification_t). */
    uint8_t p25_ss_classification;
    /** Advisory AFC gate decision: 1 = allow PPM update, 0 = suppress if opt-in gate is enabled. */
    uint8_t p25_afc_gate_allow;
    /** A completed data unit has populated the advisory AFC gate decision. */
    uint8_t p25_afc_gate_valid;
    /** Count of frames classified as AFC-allowable (infrastructure). */
    unsigned int p25_afc_allowed_count;
    /** Count of frames classified as AFC-suppressible (subscriber/unknown). */
    unsigned int p25_afc_suppressed_count;

    /*
     * P25 Protection Parameter state (from TSBK 0x3F, LCW 0x65)
     *
     * Stores the most recently announced encryption algorithm and key ID on
     * the control channel.
     */
    uint8_t p25_prot_valid; ///< 1 once an announcement has been received
    uint8_t p25_prot_algid; ///< Active encryption Algorithm ID (0 = none received)
    uint16_t p25_prot_kid;  ///< Active encryption Key ID (0 = none received)

    /*
     * P25 protected-control-channel state (from MBT 0x3E Protection Parameter
     * Broadcast). This is intentionally separate from voice/call protection
     * state above.
     */
    uint8_t p25_cc_prot_valid; ///< 1 once a protected CC broadcast has been received
    uint8_t p25_cc_prot_algid; ///< Control-channel protection Algorithm ID

    /*
     * P25 Time and Date Announcement state (TSBK 0x35 bridged as MAC-like 0x75)
     *
     * Stores the most recently decoded system UTC time and local time offset.
     */
    uint8_t p25_sys_time_valid;        ///< 1 once a valid date/time has been received
    time_t p25_sys_time;               ///< Decoded UTC time
    uint8_t p25_sys_time_offset_valid; ///< 1 once a local time offset has been received
    int16_t p25_sys_time_offset;       ///< Local time offset in minutes from UTC

    /*
     * P25 System Service Broadcast and current-site status metadata.
     */
    uint8_t p25_sys_services_valid;
    uint32_t p25_sys_services_available;
    uint32_t p25_sys_services_supported;
    uint8_t p25_sys_services_request_priority;
    uint8_t p25_site_lra_valid;
    uint8_t p25_site_lra;
    uint8_t p25_site_network_active_valid;
    uint8_t p25_site_network_active;

    // P25 Phase 2 voice error moving average per slot (errs2 from AMBE decode)
    uint8_t p25_p2_voice_err_hist[2][64];
    int p25_p2_voice_err_hist_len;      // ring capacity (<=64), default 50
    int p25_p2_voice_err_hist_count[2]; // populated frames per slot this call
    int p25_p2_voice_err_hist_pos[2];
    unsigned int p25_p2_voice_err_hist_sum[2];

    // P25 regroup/patch tracking (active super group IDs)
    // Tracks up to 8 concurrent SGIDs; updates come from MFID A4/90 regroup PDUs.
    int p25_patch_count;
    uint16_t p25_patch_sgid[8];
    uint8_t p25_patch_is_patch[8]; // 1=two-way patch, 0=simulselect
    uint8_t p25_patch_active[8];   // 1=active, 0=inactive
    time_t p25_patch_last_update[8];
    // Membership (best-effort): WGIDs and WUIDs per SG
    uint8_t p25_patch_wgid_count[8];
    uint16_t p25_patch_wgid[8][8];
    uint8_t p25_patch_wuid_count[8];
    uint32_t p25_patch_wuid[8][8];
    // Optional crypt/state context from GRG commands
    uint16_t p25_patch_key[8]; // Key ID
    uint8_t p25_patch_alg[8];  // ALG (vendor-specific)
    uint8_t p25_patch_ssn[8];  // SSN
    // Whether p25_patch_key[i] has been explicitly set by a GRG command
    uint8_t p25_patch_key_valid[8];

    // P25 affiliated RIDs tracking (simple fixed-size table)
    // Tracks up to 256 recent unit registrations (RIDs) with last-seen time for aging.
    // Entries are added on Unit Registration Accept and removed on Deregistration Ack
    // or when the last-seen exceeds an aging threshold.
    int p25_aff_count;             // number of active entries
    uint32_t p25_aff_rid[256];     // RID values
    time_t p25_aff_last_seen[256]; // last seen timestamp per RID

    // P25 Group Affiliation tracking: RID↔TG observations with aging
    int p25_ga_count;
    uint32_t p25_ga_rid[512];
    uint16_t p25_ga_tg[512];
    time_t p25_ga_last_seen[512];

    // P25 neighbors seen via Adjacent Status (best-effort)
    // Track a small set of recently announced neighbor/control candidates for UI purposes.
    // Uses p25_nb_entry_t struct with per-neighbor site metadata (CFVA, SysID, RFSS, Site).
    int p25_nb_count;                          // number of active neighbor entries
    p25_nb_entry_t p25_nb_entries[P25_NB_MAX]; // neighbor entries with metadata

    // P25 current-site secondary control channels seen via SCCB.
    int p25_secondary_cc_count;
    p25_secondary_cc_entry_t p25_secondary_cc_entries[P25_SECONDARY_CC_MAX];

    // P25 channel announcements that arrived before their IDEN table.
    int p25_pending_announcement_count;
    p25_pending_announcement_t p25_pending_announcements[P25_PENDING_ANNOUNCEMENT_MAX];

    // P25 source unit WACN from LCW 0x49 (Source ID Extension)
    uint32_t p25_src_nid; // 20-bit WACN from SUID extension

    // P25 Phase 2 standard MAC multi-fragment assembly, one in-flight message per TDMA slot.
    p25_mac_fragment_state_t p25_mac_frag[2];
    // P25 OTA alias receive sequencing, kept with decoder state to avoid cross-instance mixing.
    p25_apx_alias_rx_state_t p25_apx_alias_rx[2];
    p25_l3h_alias_phase1_state_t p25_l3h_alias_phase1[2];

    //experimental symbol file capture read throttle
    int use_throttle;                        //only use throttle if set to 1
    uint64_t symbol_replay_next_deadline_ns; //0 when uninitialized

    /* Input switches on the decoder thread (issue #634).
       input_interrupted: a frame-sync hunt read gave way to a queued command once its input had been silent for a
       stream pause; getFrameSync() returns at once and the engine loop applies the command. A Signal search also sets
       it inside a frame, when it leaves the frame or a live read gives up on a stalled input: getSymbol() then stands
       erasures in for every symbol until the engine loop consumes it, and the frame decoders drop the frame
       (dsd_state_frame_read_lost()).
       input_boundary: the stream the decoder read was replaced (a switch, a rollback that restarted it, a loss, a
       fallback); the engine ends the reception (noCarrier() and an explicit end of every call) before it decodes the
       new stream.
       input_fallback_pending: the file or TCP input ended; the frame being decoded reads zeros until it ends, and the
       engine loop then switches to the Pulse input, unless a command replaced the ended input meanwhile. */
    int input_interrupted;
    int input_boundary;
    /* The carrier boundary's count (issue #575): dsd_engine_carrier_boundary() bumps it whenever the receiver leaves a
       carrier. A decoder that buffers several bursts or frames before it decodes them notes it when collection starts,
       and drops what it buffered, as on a sync loss, when it moved meanwhile: those bursts belong to the carrier left.
       It drops them as well when an input interruption cut them (dsd_state_frame_read_lost()). */
    uint32_t carrier_seq;
    /* The frame processFrame() is dispatching (issue #661): its synctype, which a decoder borrowing another protocol's
       vocoder (YSF, scrambled dPMR) leaves alone while it changes synctype, and carrier_seq when dispatch began.
       frame_dispatch_active is 0 outside a dispatch. MBE capture attributes a frame to this protocol, and refuses one
       read across a carrier boundary. */
    int frame_dispatch_active;
    int frame_dispatch_synctype;
    uint32_t frame_dispatch_carrier_seq;
    /* The radio source the stream last started on, as dsd_engine_note_stream_source() keys it; 0 before any start. */
    uint64_t carrier_source_key;
    int input_fallback_pending;

    //dmr trunking stuff
    int dmr_rest_channel;
    int dmr_mfid;     //just when 'fid' is used as a manufacturer ID and not a feature set id
    uint32_t tg_hold; //single TG to hold on when enabled

    //edacs
    int ea_mode;

    /* ProVoice frame-content confirmation (src/protocol/provoice/provoice_confirm.c). Nothing
     * in a ProVoice frame can fail a check -- no CRC, no BCH, no parity -- so the evidence is
     * that the stream keeps arriving: each frame sits behind its own exact 32-symbol sync
     * word, and two in a row confirm the transmission (issues #391, #421).
     *
     * provoice_confirmed: this transmission has produced verified content.
     * provoice_confirm_weak_streak: consecutive frames decoded behind their own sync word.
     * provoice_confirm_frame_evidence: strongest provoice_evidence seen since begin_frame(). */
    uint8_t provoice_confirmed;
    uint8_t provoice_confirm_weak_streak;
    uint8_t provoice_confirm_frame_evidence;

    unsigned short esk_mask;
    uint32_t edacs_sys_id;
    uint32_t edacs_area_code;
    int edacs_lcn_count; //running tally of lcn's observed on edacs system
    int edacs_cc_lcn;    //current lcn for the edacs control channel
    int edacs_tuned_lcn; //the vc we are currently tuned to...above variable is for updating all in the matrix
    int edacs_a_bits;    //  Agency Significant Bits
    int edacs_f_bits;    //   Fleet Significant Bits
    int edacs_s_bits;    //Subfleet Significant Bits
    int edacs_a_shift;   //Calculated Shift for A Bits
    int edacs_f_shift;   //Calculated Shift for F Bits
    int edacs_a_mask;    //Calculated Mask for A Bits
    int edacs_f_mask;    //Calculated Mask for F Bits
    int edacs_s_mask;    //Calculated Mask for S Bits

    //trunking lcn freq list
    int lcn_freq_count;
    int lcn_freq_roll; //number we have 'rolled' to in search of the CC
    int is_con_plus;   //con_plus flag for knowing its safe to skip payload channel after x seconds of no voice sync

    //new nxdn stuff
    int nxdn_part_of_frame;
    int nxdn_ran;
    int nxdn_sf;
    uint8_t
        nxdn_sacch_non_superframe; //flag to indicate whether or not a sacch is a part of a superframe, or an individual piece
    uint8_t nxdn_sacch_frame_segment[4][18]; //part of frame by 18 bits
    uint8_t nxdn_sacch_frame_segcrc[4];
    uint8_t nxdn_alias_block_number;
    char nxdn_alias_block_segment[4][4][8];
    uint8_t nxdn_alias_arib_total_segments;
    uint8_t nxdn_alias_arib_seen_mask;
    uint8_t nxdn_alias_arib_segments[4][6];
    uint8_t nxdn_dcr_sf_message_type; // DCR SACCH2 SF message type; 0xFF means unknown.

    //site/srv/cch info

    char nxdn_location_category[14];
    uint32_t nxdn_location_sys_code;
    uint16_t nxdn_location_site_code;

    //channel access information
    uint8_t nxdn_rcn;
    uint8_t nxdn_base_freq;
    uint8_t nxdn_step;
    uint8_t nxdn_bw;

    // NXDN trunking: last observed call grant mapping (for UI/logging)
    uint16_t nxdn_grant_chan;
    long int nxdn_grant_freq;

    //multi-key array
    int keyloader;            //let us know the keyloader is active
    char key_profile_ref[64]; /**< Opaque material-source identity, safe for frontend metadata. */

    //dmr late entry mi

    //dmr manufacturer branding and sub_branding (i.e., Motorola and Con+)
    char dmr_branding[20];
    char dmr_branding_sub[80];

    //Bitmap Filtering Options
    int audio_smoothing;

    //YSF Fusion Call Strings and Info
    uint8_t ysf_dt; //data type -- VD1, VD2, Full Rate, etc.
    uint8_t ysf_fi; //frame information -- HC, CC, TC
    uint8_t ysf_cm; //group or private call
    /* Sticky for the transmission: set once a FICH passes its Golay+CRC-16, cleared with the
     * rest of the YSF strings on noCarrier(). A later FICH failure still lays the payload out
     * from the previous frame's dt/fi and still synthesizes voice from it, so once one FICH
     * has confirmed the transmission those frames are decoding, not validating nothing (#391). */
    uint8_t ysf_fich_confirmed;
    char ysf_rm1[6];
    char ysf_rm2[6];
    char ysf_rm3[6];
    char ysf_rm4[6];
    char ysf_txt[21][21]; //text storage blocks

    //DSTAR Call Strings and Info
    char dstar_txt[60];
    char dstar_gps[60];

    /* D-STAR frame-content confirmation (src/protocol/dstar/dstar_confirm.c). A voice sync
     * commits 1992 symbols, and nothing inside them is checkable on its own: the AMBE error
     * counts are soft corrections, not a verdict. A CRC-16/X.25 -- the RF header, or the
     * header rebroadcast in slow data -- proves the transmission; a superframe that carries
     * only filler has to repeat instead (issues #391, #421).
     *
     * dstar_confirmed: this transmission has produced verified content.
     * dstar_confirm_weak_streak: consecutive superframes carrying no check of their own.
     * dstar_confirm_frame_evidence: strongest dstar_evidence seen since begin_frame(). */
    uint8_t dstar_confirmed;
    uint8_t dstar_confirm_weak_streak;
    uint8_t dstar_confirm_frame_evidence;

    //M17 Storage
    uint8_t m17_lsf[360];
    uint8_t m17_pkt[850];

    // Soft symbol buffer for Viterbi decoding (M17, NXDN, etc.)
    // Stores raw float symbol values alongside dibits for soft-decision FEC
    float soft_symbol_buf[512];  // Ring buffer for soft symbols
    int soft_symbol_head;        // Write index (wraps at 512)
    int soft_symbol_frame_start; // Index where current frame started
    uint8_t m17_pbc_ct;          //pbc packet counter
    uint8_t m17_str_dt;          //stream contents
    uint8_t m17_bert_locked;
    uint16_t m17_bert_lfsr;
    uint16_t m17_bert_lock_count;
    uint16_t m17_bert_window_bits;
    uint16_t m17_bert_window_errors;
    uint32_t m17_bert_bits;
    uint32_t m17_bert_errors;
    uint32_t m17_bert_resyncs;

    /* M17 preamble candidate (src/dsp/dsd_frame_sync.c). A preamble is an alternating symbol
     * run and nothing more, so matching one only latches a candidate here; the LSF or BERT sync
     * word that must follow it within DSD_FRAME_SYNC_M17_CANDIDATE_TTL evaluations is what the
     * decoder acts on (issue #399).
     *
     * m17_pre_run: consecutive windows that matched a preamble marker at either polarity.
     * m17_pre_candidate: 0 none, 1 normal polarity, 2 inverted.
     * m17_pre_candidate_ttl: M17 evaluations left before the candidate lapses. */
    uint8_t m17_pre_run;
    uint8_t m17_pre_candidate;
    uint8_t m17_pre_candidate_ttl;

    /* M17 frame-content confirmation (src/protocol/m17/m17_confirm.c). The preamble that opens
     * the sync chain is only an alternating symbol run, so the frame body has to prove itself
     * before the decoder acts on it (issue #399).
     *
     * m17_confirmed: this transmission has produced CRC-verified content.
     * m17_confirm_weak_streak: consecutive frames carrying only a clean LICH.
     * m17_confirm_frame_evidence: strongest m17_evidence seen since begin_frame(). */
    uint8_t m17_confirmed;
    uint8_t m17_confirm_weak_streak;
    uint8_t m17_confirm_frame_evidence;

    uint8_t m17_can; //can value that was decoded from signal
    int m17_can_en;  //can value supplied to the encoding side
    int m17_rate;    //sampling rate for audio input
    int m17_vox;     //vox enabled via PWR value

    uint8_t m17_meta[16]; //packed meta
    uint8_t m17_text_meta_control_or;
    uint8_t m17_text_meta_expected_bitmap;
    uint8_t m17_text_meta_received_bitmap;
    uint8_t m17_text_meta[52];
    uint8_t m17_enc;               //enc type
    uint8_t m17_enc_st;            //scrambler or data subtye
    uint8_t m17_payload_decrypted; //current encrypted payload was successfully decrypted
    uint8_t m17_signature_advertised;
    uint8_t m17_signature_digest[16];
    uint8_t m17_signature[64];
    uint8_t m17_signature_received_mask;
    uint8_t m17_signature_complete;
    uint8_t m17_signature_bad_sequence;
    uint8_t m17_signature_public_key[64];
    uint8_t m17_signature_public_key_loaded;
    uint8_t m17_signature_verification_status;
    int m17encoder_tx;  // If TX (encode + decode) M17 Stream is enabled
    int m17encoder_eot; //signal if we need to send the EOT frame

    //misc str storage
    char str50a[50];
    char str50b[50];
    char str50c[50];
    char m17dat[50];  //user supplied m17 data input string
    char m17sms[824]; //user supplied sms text string

    // tyt_ap value 1 means active
    int tyt_ap;
    int tyt_bp;
    int tyt_ep;
    int baofeng_ap;
    int csi_ee;
    uint8_t csi_ee_key[9];
    // retrevis rc2
    int retevis_ap;

    //kenwood scrambler on DMR with forced application
    int ken_sc;

    //anytone bp
    int any_bp;

    //generic ks
    int straight_ks;
    int straight_mod;
    int straight_frame_mode; // 0=continuous bitstream, 1=frame-aligned (offset/step)
    int straight_frame_off;  //frame-aligned start offset (bits)
    int straight_frame_step; //frame-aligned per-frame step (bits)

    uint8_t static_ks_bits[2][882];
    int static_ks_counter[2];

    // Vertex ALG 0x07 interim key->keystream mapping table.
    unsigned long long vertex_ks_key[DSD_VERTEX_KS_MAP_MAX];
    uint8_t vertex_ks_bits[DSD_VERTEX_KS_MAP_MAX][882];
    int vertex_ks_mod[DSD_VERTEX_KS_MAP_MAX];
    int vertex_ks_frame_mode[DSD_VERTEX_KS_MAP_MAX];
    int vertex_ks_frame_off[DSD_VERTEX_KS_MAP_MAX];
    int vertex_ks_frame_step[DSD_VERTEX_KS_MAP_MAX];
    int vertex_ks_count;
    int vertex_ks_active_idx[2];
    int vertex_ks_counter[2];
    uint8_t vertex_ks_warned[2];

    // DMR: consecutive EMB decode failures per slot (hysteresis for robustness)
    uint8_t dmr_emb_err[2];

    /* ─────────────────────────────────────────────────────────────────────────
     * Symbol History and DMR Resample-on-Sync Support
     *
     * Implements SDRTrunk-style threshold calibration and CACH resampling to
     * improve first-frame decode accuracy. See dmr_sync.h for details.
     * ───────────────────────────────────────────────────────────────────────── */

    /** Symbol history circular buffer for retrospective resampling.
     *  Stores symbol-rate floats (one per dibit decision), not raw audio samples. */
    float* symbol_history;
    int symbol_history_size;  /**< Circular-buffer size in symbols */
    int symbol_history_head;  /**< Write index into circular buffer */
    int symbol_history_count; /**< Symbols written (for underflow check) */

    /** Post-filter sample trace backing the symbol-timing diagnostic;
     *  written only while DSD_NEO_DEBUG_SYMBOL_TIMING is on.
     *  See dsp/symbol_timing_debug.h. */
    dsd_symbol_timing_trace timing_trace;

    /** The matched filter the symbol grid reads through and the raw history a
     *  switch is paid from; see dsd_matched_filter_seam. */
    dsd_matched_filter_seam matched_filter;

    // Advisory-only input level health for ncurses/status snapshots.
    dsd_input_level_snapshot input_level;
    // Decode time of the last input-level warning, which its cooldown runs against (dsd_input_level_publish()).
    time_t input_level_last_toast_time;
    dsd_input_level_status input_level_last_toast_status;
    dsd_input_level_source input_level_last_toast_source;

    /* Which --trunk-scan target the receiver is parked on, published for the frontends.
     * Zeroed while trunk scan is off or before the first target is selected. */
    char trunk_scan_active_id[DSD_CHANNEL_LABEL_SIZE];
    uint16_t trunk_scan_active_ordinal; /**< 1-based position in the target list; 0 = none */
    uint16_t trunk_scan_target_count;   /**< Targets in the list, for an "n of m" readout */

    /* On-the-fly scan controls (issue #380), published beside the target id so they ride
     * the same snapshot range. lcn_scan_hold is authoritative for -Y: app_control writes
     * it and the scanner rotation reads it. lcn_avoid_count mirrors the avoid store for the
     * status line and is maintained by dsd_state_trunk_lcn_avoid_set()/_clear(). The
     * trunk_scan_* trio is written by the trunk-scan coordinator, which owns the truth. */
    uint8_t lcn_scan_hold;             /**< 1 = -Y rotation paused on the row on air */
    uint16_t lcn_avoid_count;          /**< Avoided -Y rows within lcn_freq_count */
    uint8_t trunk_scan_hold;           /**< 1 = --trunk-scan dwell paused on the active target */
    uint8_t trunk_scan_active_avoided; /**< 1 = the parked target is itself avoided (fallback) */
    uint16_t trunk_scan_avoided_count; /**< Avoided --trunk-scan targets */
    /* The tuner gain a --trunk-scan target without its own rtl_gain runs, which the gain controls edit and a save
     * writes, and whether the parked target's own rtl_gain overrides it; written by the coordinator beside the trio
     * above. Valid while trunk_scan_target_count > 0. */
    int16_t trunk_scan_configured_gain;     /**< dB in driver units; 0 = AGC */
    uint8_t trunk_scan_gain_override;       /**< 1 = the parked target runs its own rtl_gain */
    uint8_t trunk_scan_configured_autogain; /**< 1 = the configured tuner autogain is on */
    /* The scan row on air, for the "this channel" editors (issue #518): the scanner that owns it (dsd_scan_row_scanner,
     * 0 = none), the scan session (a new one for every trunk-scan coordinator and -Y scan, so an edit opened on one never
     * lands on the next), the row (a --trunk-scan target's index, a -Y channel map row), the session-edit fields
     * (DSD_SCAN_ROW_FIELD_*, runtime/scan_row_edit.h) it can take, those it runs a session edit of, and those its list
     * row sets itself. Written by the trunk-scan coordinator and the -Y channel scan beside the fields above. */
    uint32_t scan_row_session;
    int32_t scan_row_index;
    uint8_t scan_row_scanner;
    uint8_t scan_row_editable;
    uint8_t scan_row_edited;
    uint8_t scan_row_listed;
    /* The number dsd_opts::scan_row_scope_seq took when the row's options were installed (dsd_scan_mode_options()). */
    uint32_t scan_row_scope_seq;
    /* Voice-gated scan (issue #381): per-visit gate memory for -Y. Arrive/sync/voice
     * anchors are monotonic seconds (-1 = unset this visit); roll_seen restarts the
     * visit on external lcn_freq_roll changes; hold_seen is lcn_scan_hold as of the
     * previous tick, so a release can restart the qualify window; phase is a
     * dsd_scan_voice_gate_phase for the status line, owned by the -Y tick or, under
     * --trunk-scan, by the coordinator (OFF on trunked targets). Rides the
     * vertex_ks_count..ui_msg snapshot range (see ui_snapshot.c static assert). */
    double scan_voice_gate_arrive_m;
    double scan_voice_gate_sync_m;
    double scan_voice_gate_voice_m;
    int scan_voice_gate_roll_seen;
    uint8_t scan_voice_gate_hold_seen;
    uint8_t scan_voice_gate_phase;
    /* Per-visit cap bookkeeping for -Y (issue #507). scan_visit_since_m is the monotonic instant
     * the row on air was tuned (-1.0 = no visit anchored, so the cap cannot fire) and
     * scan_visit_roll_seen is the lcn_freq_roll this bookkeeping last saw, so an untyped `L` or
     * avoid that moves the row without a retune note re-anchors. Deliberately separate from the
     * scan_voice_gate_* anchors above: the cap applies under the voice gate and under the legacy
     * hangtime rule alike, so it must not depend on gate-only code running -- the gate tick
     * returns early with the gate off. Rides the vertex_ks_count..ui_msg range. */
    double scan_visit_since_m;
    int scan_visit_roll_seen;
    uint8_t scan_visit_rearm_pending; /**< resume a suspended visit at the next eligible tick */
    /* Scan state + live timing for the Scan Timing row (issue #508). Written by the
     * --trunk-scan coordinator for its parked target, or by the -Y timing tick when trunk
     * scan is off; the two never both write it. Rides the vertex_ks_count..ui_msg range. */
    dsd_scan_timing_publication scan_timing;
    /* Received sub-audible tone (issue #522), published by the analog tap for every frontend.
     * Rides the vertex_ks_count..ui_msg range; see dsd_analog_rx_publication. */
    dsd_analog_rx_publication analog_rx;
    /* The dynamic squelch (issue #518 follow-up) as the RTL stream last showed it, for every frontend
     * (dsd_squelch_publish_status()): whether one runs (an AUTO or NOISE setting on the analog monitor), whether that is
     * the noise squelch (0: the floor tracker, under AUTO or as NOISE's stand-in), the tracker's floor's state
     * (dsd_squelch_floor_state), whether the gate is open, whether the channel plan could be designed (0: the gate
     * stays open), the floor in hundredths of a dB on rtl_squelch_level's scale (0 while learning), whether the noise
     * squelch has measured a window yet, and its quieting in hundredths of a dB. On audio input the PCM noise squelch
     * (issue #628) writes them itself on the decoder thread, with what it knows (dsd_squelch_noise_state; 0 on radio
     * input). Rides the vertex_ks_count..ui_msg range. */
    uint8_t squelch_auto_active;
    uint8_t squelch_auto_state;
    uint8_t squelch_auto_gate_open;
    uint8_t squelch_auto_plan_valid;
    int32_t squelch_auto_floor_cdb;
    uint8_t squelch_noise_active;
    uint8_t squelch_noise_measured;
    int32_t squelch_noise_quieting_cdb;
    uint8_t squelch_noise_state;
    /* 1 while EDACS plays an analog voice call (edacs_analog(), issue #625), which ends on the dynamic squelch's gate:
       the readout shows the tracker during a call and what it is for between calls. Written on the decoder thread;
       rides the vertex_ks_count..ui_msg range. */
    uint8_t squelch_edacs_call;

    // Transient UI message (shown briefly in ncurses printer)
    char ui_msg[128];

    // Extension slots for module-owned per-state allocations (see core/state_ext.h).
    void* state_ext[DSD_STATE_EXT_MAX];
    dsd_state_ext_cleanup_fn state_ext_cleanup[DSD_STATE_EXT_MAX];

    /* 1 from initState() until an engine run starts on this state, which clears it (dsd_engine_run_with_lifecycle()).
     * A state an earlier run used keeps that run's decode-domain stamps, which no rebase reaches, so a run moves the
     * decode clock onto an I/Q replay's capture clock only on a fresh one (dsd_engine_decode_clock_enter_replay()). */
    uint8_t engine_fresh;
};

// cppcheck-suppress-end uninitMemberVarNoCtor

// NOLINTEND(clang-analyzer-optin.performance.Padding)

/* Whether a frame decoder that noted @p carrier_seq when it began reading must drop what it read, as on a sync loss:
   the carrier boundary moved the carrier count meanwhile (issue #575), or an input interruption cut the frame
   (input_interrupted: a Signal search left it, or a live read gave up on a stalled input), after which getSymbol()
   stood erasures in for every symbol. Either way part of the frame is not the transmission's, so nothing of it may
   decode, play or publish. */
static inline int
dsd_state_frame_read_lost(const dsd_state* state, uint32_t carrier_seq) {
    return state->carrier_seq != carrier_seq || state->input_interrupted != 0;
}

static inline int
dsd_state_trunk_chan_valid(uint32_t channel) {
    return channel < DSD_TRUNK_CHAN_MAP_SIZE;
}

static inline int
dsd_state_trunk_chan_tracked(uint32_t channel) {
    return channel > 0U && dsd_state_trunk_chan_valid(channel);
}

static inline void
dsd_state_track_trunk_chan(dsd_state* state, uint16_t channel) {
    if (!state || !dsd_state_trunk_chan_tracked(channel)) {
        return;
    }

    uint32_t count = state->trunk_chan_map_used_count;
    if (count > DSD_TRUNK_CHAN_MAP_SIZE) {
        count = DSD_TRUNK_CHAN_MAP_SIZE;
    }

    uint32_t insert = count;
    for (uint32_t i = 0; i < count; i++) {
        if (state->trunk_chan_map_used[i] == channel) {
            state->trunk_chan_map_used_count = count;
            return;
        }
        if (state->trunk_chan_map_used[i] > channel) {
            insert = i;
            break;
        }
    }

    if (count >= DSD_TRUNK_CHAN_MAP_SIZE) {
        state->trunk_chan_map_used_count = count;
        return;
    }

    for (uint32_t i = count; i > insert; i--) {
        state->trunk_chan_map_used[i] = state->trunk_chan_map_used[i - 1];
    }
    state->trunk_chan_map_used[insert] = channel;
    state->trunk_chan_map_used_count = count + 1U;
}

static inline void
dsd_state_untrack_trunk_chan(dsd_state* state, uint16_t channel) {
    if (!state || !dsd_state_trunk_chan_tracked(channel)) {
        return;
    }

    uint32_t count = state->trunk_chan_map_used_count;
    if (count > DSD_TRUNK_CHAN_MAP_SIZE) {
        count = DSD_TRUNK_CHAN_MAP_SIZE;
    }

    for (uint32_t i = 0; i < count; i++) {
        if (state->trunk_chan_map_used[i] != channel) {
            continue;
        }
        for (uint32_t j = i + 1U; j < count; j++) {
            state->trunk_chan_map_used[j - 1U] = state->trunk_chan_map_used[j];
        }
        state->trunk_chan_map_used[count - 1U] = 0;
        state->trunk_chan_map_used_count = count - 1U;
        return;
    }
    state->trunk_chan_map_used_count = count;
}

static inline void
dsd_state_set_trunk_chan_freq(dsd_state* state, uint32_t channel, long int freq) {
    if (!state || !dsd_state_trunk_chan_valid(channel)) {
        return;
    }

    const long int old_freq = state->trunk_chan_map[channel];
    if (old_freq == freq) {
        return;
    }

    state->trunk_chan_map[channel] = freq;
    if (!dsd_state_trunk_chan_tracked(channel)) {
        state->trunk_chan_map_seq++;
        return;
    }
    if (old_freq == 0) {
        dsd_state_track_trunk_chan(state, (uint16_t)channel);
    } else if (freq == 0) {
        dsd_state_untrack_trunk_chan(state, (uint16_t)channel);
    }
    state->trunk_chan_map_seq++;
}

/**
 * Address the scan-list LCN slot at index i. The first DSD_TRUNK_LCN_EMBEDDED slots
 * live in the embedded trunk_lcn_freq array (protocol fixed-slot writers keep
 * raw-indexing those); higher slots live in the heap tail trunk_lcn_freq_ext. Callers
 * must guarantee 0 <= i < lcn_freq_count for reads, or that the index is addressable
 * (trunk_lcn_freq_ext_capacity > i - DSD_TRUNK_LCN_EMBEDDED) for writes into the tail.
 */
static inline long int*
dsd_state_trunk_lcn_slot(dsd_state* state, int i) {
    return i < DSD_TRUNK_LCN_EMBEDDED ? &state->trunk_lcn_freq[i]
                                      : &state->trunk_lcn_freq_ext[i - DSD_TRUNK_LCN_EMBEDDED];
}

/** Const-qualified dsd_state_trunk_lcn_slot() for read-only contexts. */
static inline const long int*
dsd_state_trunk_lcn_slot_const(const dsd_state* state, int i) {
    return i < DSD_TRUNK_LCN_EMBEDDED ? &state->trunk_lcn_freq[i]
                                      : &state->trunk_lcn_freq_ext[i - DSD_TRUNK_LCN_EMBEDDED];
}

/**
 * Ensure scan-list indices 0..count_needed-1 are addressable via
 * dsd_state_trunk_lcn_slot(): grows the heap tail by doubling and zero-fills
 * the new tail; no-op when count_needed <= DSD_TRUNK_LCN_EMBEDDED. Returns 0 on
 * success, -1 on allocation failure (state left valid, contents preserved).
 */
int dsd_state_trunk_lcn_reserve(dsd_state* state, size_t count_needed);

/**
 * Free the scan-list heap tail, the per-row name, avoid and key stores, and the
 * scan key swap state, and zero their pointers/capacities. The embedded
 * DSD_TRUNK_LCN_EMBEDDED slots are part of dsd_state and need no release.
 */
void dsd_state_trunk_lcn_free(dsd_state* state);

/**
 * Seed the live IDEN tables from the stored band plan (p25_bandplan_rows).
 *
 * Only empty slots are filled, never an over-the-air entry. Rows that name the
 * current WACN/SYS go first and may take over a slot a global row of the same
 * plan seeded earlier; rows that name another system are skipped, and rows that
 * name any system wait until the identity is known. Each seeded slot gets trust
 * 1, zero rfss/site, and its FDMA or TDMA bit in p25_chan_tdma_explicit[].
 * Returns the number of slots written.
 */
int dsd_state_p25_bandplan_seed(dsd_state* state);

/**
 * Append every ready entry (populated, base and spacing set) of two IDEN tables
 * to `rows` as band-plan rows, skipping an identifier/table/system already in
 * the list, so several targets' tables can be merged into one export. Either
 * table may be NULL. Returns the new row count (never above `cap`).
 */
int dsd_p25_bandplan_append_tables(p25_bandplan_row_t* rows, int count, int cap, const p25_iden_entry_t* fdma,
                                   const p25_iden_entry_t* tdma);

/**
 * Ensure name-store indices 0..count-1 are addressable: grows by doubling and
 * zero-fills the new entries. Returns 0 on success, -1 on allocation failure
 * (state left valid, existing names preserved).
 */
int dsd_state_trunk_lcn_name_reserve(dsd_state* state, size_t count);

/** Free the per-row name store and zero its pointer/capacity. */
void dsd_state_trunk_lcn_name_free(dsd_state* state);

/**
 * Store the name of scan-list row @p index. The name is truncated to
 * DSD_CHANNEL_LABEL_SIZE - 1 bytes without splitting a UTF-8 character, has
 * control characters replaced with spaces (so a stray tab or CR never reaches
 * the terminal), and is trimmed of leading and trailing ASCII whitespace --
 * including whatever that substitution and truncation leave at either end. A
 * NULL or blank name clears the entry, allocating nothing when the store does
 * not already reach @p index. Returns 0 on success, -1 on allocation failure or
 * a NULL state.
 */
int dsd_state_trunk_lcn_name_set(dsd_state* state, size_t index, const char* name);
/**
 * Name of scan-list row @p index, or "" when the row is unnamed, the store is
 * shorter than @p index, or no name column was ever imported. Never NULL.
 */
const char* dsd_state_trunk_lcn_name_get(const dsd_state* state, size_t index);

/**
 * Ensure avoid-store indices 0..count-1 are addressable: grows by doubling and
 * zero-fills the new entries. Returns 0 on success, -1 on allocation failure
 * (state left valid, existing flags preserved).
 */
int dsd_state_trunk_lcn_avoid_reserve(dsd_state* state, size_t count);

/** Free the per-row avoid store and zero its pointer/capacity. lcn_avoid_count is not touched. */
void dsd_state_trunk_lcn_avoid_free(dsd_state* state);

/**
 * Ensure key-store indices 0..count-1 are addressable: grows by doubling and
 * zero-fills the new entries. Returns 0 on success, -1 on allocation failure
 * (state left valid, existing sets preserved).
 */
int dsd_state_trunk_lcn_keys_reserve(dsd_state* state, size_t count);

/** Free the per-row key store and zero its pointer/capacity. */
void dsd_state_trunk_lcn_keys_free(dsd_state* state);

/**
 * Move @p ks into the store at @p index, freeing any previous entry there.
 * Takes ownership of the entries pointer; the caller must not free it after a
 * successful call. Returns 0 on success, -1 on allocation failure or NULL state.
 */
int dsd_state_trunk_lcn_keys_set(dsd_state* state, size_t index, dsd_key_set* ks);

/**
 * Key set of scan-list row @p index, or NULL when the row carries no keys.
 * Decoder thread only; the pointer is invalidated by subsequent key-store growth.
 */
const dsd_key_set* dsd_state_trunk_lcn_keys_get(const dsd_state* state, size_t index);

/** Non-zero when any row in the store carries a key set. */
int dsd_state_trunk_lcn_keys_present(const dsd_state* state);

/**
 * Flag scan-list row @p index as avoided (@p avoided != 0) or put it back. Setting a
 * flag grows the store on demand; clearing a row the store does not reach allocates
 * nothing. Recounts lcn_avoid_count over the rows within lcn_freq_count. Returns 0 on
 * success, -1 on allocation failure or a NULL state.
 */
int dsd_state_trunk_lcn_avoid_set(dsd_state* state, size_t index, int avoided);

/** 1 when row @p index is avoided; 0 otherwise, including past the store or with no store. */
int dsd_state_trunk_lcn_avoid_get(const dsd_state* state, size_t index);

/**
 * Put every avoided row back. Returns how many rows within lcn_freq_count were
 * avoided; the store keeps its capacity. lcn_avoid_count is zeroed.
 */
int dsd_state_trunk_lcn_avoid_clear(dsd_state* state);

/** Rows below lcn_freq_count that carry a frequency and are not avoided. */
int dsd_state_trunk_lcn_usable_count(const dsd_state* state);

/**
 * First row index at or after @p from (wrapping through the list) that is not avoided.
 * A @p from outside 0..lcn_freq_count-1 starts at row 0. Placeholder (0 Hz) rows are
 * not skipped: the scanner parks on them deliberately. Returns -1 when the list is
 * empty or every row is avoided.
 */
int dsd_state_trunk_lcn_next_unavoided(const dsd_state* state, int from);

/**
 * Whether the scan list is operator-supplied rather than learned over the air.
 *
 * A `-C`/`-Y` channel map, or a per-target chan_csv under trunk scan, is
 * positional: index i is LCN i+1, and an unparseable row deliberately stores 0
 * to keep that numbering. Protocol site broadcasts must therefore neither write
 * into such a list nor lower lcn_freq_count to the handful of slots they know
 * about. Trunk scan rejects a global chan_in_file at init and seeds slot 0 with
 * the target's park frequency, so under -Y a count above 1 is the only evidence
 * a per-target map was imported.
 */
int dsd_state_trunk_lcn_user_list_present(const dsd_opts* opts, const dsd_state* state);

static inline int
dsd_state_minmax_window_size(int requested) {
    if (requested < 1) {
        return 1;
    }
    if (requested > 1024) {
        return 1024;
    }
    return requested;
}

static inline void
dsd_state_invalidate_minmax_sums(dsd_state* state) {
    if (!state) {
        return;
    }
    state->minmax_sum_window = 0;
}

static inline void
dsd_state_recompute_minmax_sums(dsd_state* state, int requested_window) {
    if (!state) {
        return;
    }

    const int window = dsd_state_minmax_window_size(requested_window);
    double min_sum = 0.0;
    double max_sum = 0.0;
    for (int i = 0; i < window; i++) {
        min_sum += (double)state->minbuf[i];
        max_sum += (double)state->maxbuf[i];
    }

    state->minbuf_sum = min_sum;
    state->maxbuf_sum = max_sum;
    state->minmax_sum_window = window;
    if (state->midx < 0 || state->midx >= window) {
        state->midx = 0;
    }
}

static inline void
dsd_state_push_minmax_window(dsd_state* state, int requested_window, float min_value, float max_value) {
    if (!state) {
        return;
    }

    const int window = dsd_state_minmax_window_size(requested_window);
    if (state->minmax_sum_window != window) {
        dsd_state_recompute_minmax_sums(state, window);
    }

    int idx = state->midx;
    if (idx < 0 || idx >= window) {
        idx = 0;
    }

    state->minbuf_sum += (double)min_value - (double)state->minbuf[idx];
    state->maxbuf_sum += (double)max_value - (double)state->maxbuf[idx];
    state->minbuf[idx] = min_value;
    state->maxbuf[idx] = max_value;

    idx++;
    state->midx = (idx >= window) ? 0 : idx;
    state->min = (float)(state->minbuf_sum / (double)window);
    state->max = (float)(state->maxbuf_sum / (double)window);
}

/**
 * @brief Rescale symbol timing state between two effective PCM rates.
 *
 * This helper updates only timing-related state. Callers that also need analog
 * filter coefficients rebuilt should do that separately.
 *
 * @param state Decoder state to update.
 * @param old_rate_hz Previous effective PCM rate.
 * @param new_rate_hz New effective PCM rate.
 */
static inline void
dsd_state_rescale_symbol_timing(dsd_state* state, int old_rate_hz, int new_rate_hz) {
    if (!state) {
        return;
    }

    if (old_rate_hz <= 0) {
        old_rate_hz = 48000;
    }
    if (new_rate_hz <= 0) {
        new_rate_hz = old_rate_hz;
    }
    if (old_rate_hz == new_rate_hz) {
        return;
    }

    int old_sps = state->samplesPerSymbol > 0 ? state->samplesPerSymbol : 10;
    long long scaled = (long long)old_sps * (long long)new_rate_hz;
    int new_sps = (int)((scaled + (old_rate_hz / 2)) / old_rate_hz);
    if (new_sps < 2) {
        new_sps = 2;
    } else if (new_sps > 64) {
        new_sps = 64;
    }

    int new_center = (new_sps - 1) / 2;
    if (new_sps > 2) {
        int min_c = 1;
        int max_c = new_sps - 2;
        long long ratio_num = state->symbolCenter;
        long long ratio_den = old_sps;
        if ((ratio_num * 20LL) < ratio_den) {
            ratio_num = 1;
            ratio_den = 20;
        } else if ((ratio_num * 20LL) > (19LL * ratio_den)) {
            ratio_num = 19;
            ratio_den = 20;
        }
        const long long center_scaled = ratio_num * (long long)new_sps;
        new_center = (int)((center_scaled + (ratio_den / 2LL)) / ratio_den);
        if (new_center < min_c) {
            new_center = min_c;
        } else if (new_center > max_c) {
            new_center = max_c;
        }
    }

    state->samplesPerSymbol = new_sps;
    state->symbolCenter = new_center;
    state->jitter = -1;
}
#endif /* DSD_NEO_INCLUDE_DSD_NEO_CORE_STATE_H_H */
