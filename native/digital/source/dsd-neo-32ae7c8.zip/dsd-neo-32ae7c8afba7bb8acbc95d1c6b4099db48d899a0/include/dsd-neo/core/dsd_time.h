// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Helpers to stamp CC/VC sync times on `dsd_state`.
 *
 * Both stamps read the decode clock (`<dsd-neo/runtime/decode_clock.h>`).
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_CORE_DSD_TIME_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_CORE_DSD_TIME_H_H

#include <dsd-neo/core/state_fwd.h>

#ifdef __cplusplus
extern "C" {
#endif

/** @brief Stamp the decode clock's current time as control-channel sync (monotonic + wall clock). */
void dsd_mark_cc_sync(dsd_state* state);

/** @brief Stamp the decode clock's current time as voice-channel sync (monotonic + wall clock). */
void dsd_mark_vc_sync(dsd_state* state);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_CORE_DSD_TIME_H_H */
