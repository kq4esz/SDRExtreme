// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Forward declaration of core decoder state type (`dsd_state`).
 *
 * Provides an incomplete type for headers that only need pointers/
 * references.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_CORE_STATE_FWD_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_CORE_STATE_FWD_H_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct dsd_state dsd_state;
typedef struct Event_History_I Event_History_I;
typedef struct dsd_scan_timing_publication dsd_scan_timing_publication;
typedef struct dsd_analog_rx_publication dsd_analog_rx_publication;

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_CORE_STATE_FWD_H_H */
