// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Embedded alias decoder interfaces.
 *
 * Declares embedded alias helpers implemented in `src/core/util/dsd_alias.c`
 * as a standalone API.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_CORE_EMBEDDED_ALIAS_H_
#define DSD_NEO_INCLUDE_DSD_NEO_CORE_EMBEDDED_ALIAS_H_

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void dmr_talker_alias_lc_header(dsd_opts* opts, dsd_state* state, uint8_t slot, uint8_t* lc_bits);
/**
 * @brief Abandon a slot's partly assembled DMR talker alias after a fragment failed its checksum.
 *
 * Clears the header's format and character size, so later blocks are refused until a checked header arrives, and
 * zeroes the alias bits already assembled, so a later decode cannot pick up text from before the failure. The alias
 * already displayed and recorded on the call is kept.
 */
void dmr_talker_alias_lc_invalidate(dsd_state* state, uint8_t slot);
void dmr_talker_alias_lc_blocks(dsd_opts* opts, dsd_state* state, uint8_t slot, uint8_t block_num,
                                const uint8_t* lc_bits);
void dmr_talker_alias_lc_decode(dsd_opts* opts, dsd_state* state, uint8_t slot, uint8_t block_num, uint8_t char_size,
                                uint16_t max_chars);

void apx_embedded_alias_header_phase1(dsd_opts* opts, dsd_state* state, uint8_t slot, uint8_t* lc_bits);
void apx_embedded_alias_header_phase2(dsd_opts* opts, dsd_state* state, uint8_t slot, uint8_t* lc_bits);
void apx_embedded_alias_blocks_phase1(dsd_opts* opts, dsd_state* state, uint8_t slot, uint8_t* lc_bits);
void apx_embedded_alias_blocks_phase2(dsd_opts* opts, dsd_state* state, uint8_t slot, uint8_t* lc_bits);
void apx_embedded_alias_decode(dsd_opts* opts, dsd_state* state, uint8_t slot, int16_t num_bits, uint8_t* input);
/**
 * @brief Unscramble Motorola APX embedded alias octets.
 *
 * Pure inverse of the over-the-air scrambling: @p decoded[i] depends on @p encoded[0..i] and on
 * @p num_bytes. Both spans are stated because @p num_bytes is measured off the air: it reads and
 * writes at most min(@p num_bytes, @p encoded_size, @p decoded_size) octets. Note that a
 * @p num_bytes that does not match the record produces different octets throughout rather than a
 * correct prefix, because the count seeds the descrambler.
 */
void apx_embedded_alias_unscramble(const uint8_t* encoded, size_t encoded_size, uint16_t num_bytes, uint8_t* decoded,
                                   size_t decoded_size);
void apx_embedded_alias_dump(const dsd_opts* opts, dsd_state* state, uint8_t slot, uint16_t num_bytes,
                             const uint8_t* input, const uint8_t* decoded);

void l3h_embedded_alias_blocks_phase1(const dsd_opts* opts, dsd_state* state, uint8_t slot, uint8_t* lc_bits);
/**
 * @brief Decode an L3Harris embedded talker alias.
 *
 * @param len   Index of the LAST readable octet of @p input, not a count. Callers must
 *              cap it at the final element of their buffer.
 * @param input Alias octets; must span at least @p len + 1 elements.
 */
void l3h_embedded_alias_decode(const dsd_opts* opts, dsd_state* state, uint8_t slot, int16_t len, const uint8_t* input);
void tait_iso7_embedded_alias_decode(const dsd_opts* opts, dsd_state* state, uint8_t slot, int16_t len,
                                     const uint8_t* input);

#ifdef __cplusplus
}
#endif

#endif /* DSD_NEO_INCLUDE_DSD_NEO_CORE_EMBEDDED_ALIAS_H_ */
