// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/* UI command actions — audio domain */

#include <dsd-neo/core/audio.h>
#include <dsd-neo/core/opts.h>
#include <dsd-neo/core/state.h>
#include <dsd-neo/dsp/analog_audio.h>
#include <dsd-neo/runtime/decode_clock.h>
#include <stddef.h>
#include <stdint.h>
#include "../command_dispatch.h"
#include "dsd-neo/app_control/commands.h"
#include "dsd-neo/core/opts_fwd.h"
#include "dsd-neo/core/safe_api.h"
#include "dsd-neo/core/state_fwd.h"

static int
ui_handle_toggle_mute(dsd_opts* opts, dsd_state* state, const struct dsd_app_command* c) {
    (void)c;
    opts->audio_out = (opts->audio_out == 0) ? 1 : 0;
    const char* msg = (opts->audio_out == 0) ? "Output: Muted" : "Output: On";
    if (opts->audio_out == 1) {
        if (opts->audio_out_type == 0) {
            closeAudioOutput(opts);
            if (openAudioOutput(opts) != 0) {
                opts->audio_out = 0;
                msg = "Output: open failed";
            }
        }
    }
    if (state) {
        DSD_SNPRINTF(state->ui_msg, sizeof state->ui_msg, "%s", msg);
        state->ui_msg_expire = dsd_realtime_time() + 3;
    }
    return 1;
}

static inline void
apply_gain_delta(dsd_opts* opts, dsd_state* state, int d) {
    /* In 64 bits: a delta can be any int32 (the control API sends what its client asked for). */
    int64_t g = (int64_t)opts->audio_gain + d;
    if (g < 0) {
        g = 0;
    }
    if (g > 50) {
        g = 50;
    }
    opts->audio_gain = (int)g;
    state->aout_gain = opts->audio_gain;
    state->aout_gainR = opts->audio_gain;
    opts->audio_gainR = opts->audio_gain;
    if (opts->audio_gain == 0) {
        state->aout_gain = 25;
        state->aout_gainR = 25;
    }
}

static int
ui_handle_gain_delta(dsd_opts* opts, dsd_state* state, const struct dsd_app_command* c) {
    int delta = 0;
    if (c->n >= (int)sizeof(int32_t)) {
        int32_t d = 0;
        DSD_MEMCPY(&d, c->data, sizeof(int32_t));
        delta = d;
    }
    apply_gain_delta(opts, state, delta);
    return 1;
}

/* Analog output gain (-n, the menu prompt and the * and / keys alike): 0 is auto (the AGC), 1..100 a fixed gain, 50
   the reference level. Anything under 1 is auto. */
static float
clamp_analog_gain(float g) {
    if (!(g >= 1.0f)) {
        return 0.0f;
    }
    if (g > 100.0f) {
        return 100.0f;
    }
    return g;
}

static int
ui_handle_again_delta(dsd_opts* opts, dsd_state* state, const struct dsd_app_command* c) {
    (void)state;
    int32_t d = 0;
    if (c->n >= (int)sizeof(int32_t)) {
        DSD_MEMCPY(&d, c->data, sizeof(int32_t));
    }
    /* From auto a step starts at the reference setting; a step below 1 goes back to auto. In float, so a fractional
       -n value moves by the step instead of being truncated first. */
    const float from = dsd_analog_gain_is_auto(opts->audio_gainA) ? 50.0f : opts->audio_gainA;
    opts->audio_gainA = clamp_analog_gain(from + (float)d);
    return 1;
}

static int
ui_handle_gain_set(dsd_opts* opts, dsd_state* state, const struct dsd_app_command* c) {
    int32_t g = 0;
    if (c->n >= (int)sizeof(int32_t)) {
        DSD_MEMCPY(&g, c->data, sizeof g);
    }
    if (g < 0) {
        g = 0;
    }
    if (g > 50) {
        g = 50;
    }
    opts->audio_gain = g;
    state->aout_gain = opts->audio_gain;
    state->aout_gainR = opts->audio_gain;
    opts->audio_gainR = opts->audio_gain;
    if (opts->audio_gain == 0) {
        state->aout_gain = 25;
        state->aout_gainR = 25;
    }
    return 1;
}

static int
ui_handle_again_set(dsd_opts* opts, dsd_state* state, const struct dsd_app_command* c) {
    (void)state;
    int32_t g = 0;
    if (c->n >= (int)sizeof(int32_t)) {
        DSD_MEMCPY(&g, c->data, sizeof g);
    }
    opts->audio_gainA = clamp_analog_gain((float)g);
    return 1;
}

static int
ui_handle_input_warn_db_set(dsd_opts* opts, dsd_state* state, const struct dsd_app_command* c) {
    (void)state;
    double v = 0.0;
    if (c->n >= (int)sizeof(double)) {
        DSD_MEMCPY(&v, c->data, sizeof v);
    }
    if (v < -200.0) {
        v = -200.0;
    }
    if (v > 0.0) {
        v = 0.0;
    }
    opts->input_warn_db = v;
    return 1;
}

static int
ui_handle_input_monitor_toggle(dsd_opts* opts, dsd_state* state, const struct dsd_app_command* c) {
    (void)state;
    (void)c;
    opts->monitor_input_audio = opts->monitor_input_audio ? 0 : 1;
    return 1;
}

static int
ui_handle_cosine_filter_toggle(dsd_opts* opts, dsd_state* state, const struct dsd_app_command* c) {
    (void)state;
    (void)c;
    opts->use_cosine_filter = opts->use_cosine_filter ? 0 : 1;
    return 1;
}

static int
ui_handle_input_vol_cycle(dsd_opts* opts, dsd_state* state, const struct dsd_app_command* c) {
    (void)c;
    if (opts->audio_in_type == AUDIO_IN_RTL) {
        if (opts->rtl_volume_multiplier == 1 || opts->rtl_volume_multiplier == 2) {
            opts->rtl_volume_multiplier++;
        } else {
            opts->rtl_volume_multiplier = 1;
        }
        if (state) {
            DSD_SNPRINTF(state->ui_msg, sizeof state->ui_msg, "RTL Monitor Gain: %dX", opts->rtl_volume_multiplier);
            state->ui_msg_expire = dsd_realtime_time() + 2;
        }
    } else {
        if (opts->input_volume_multiplier == 1 || opts->input_volume_multiplier == 2) {
            opts->input_volume_multiplier++;
        } else {
            opts->input_volume_multiplier = 1;
        }
        if (state) {
            DSD_SNPRINTF(state->ui_msg, sizeof state->ui_msg, "Input Volume: %dX", opts->input_volume_multiplier);
            state->ui_msg_expire = dsd_realtime_time() + 2;
        }
    }
    return 1;
}

static int
ui_handle_input_vol_set(dsd_opts* opts, dsd_state* state, const struct dsd_app_command* c) {
    (void)state;
    if (opts && c->n >= (int)sizeof(int32_t)) {
        int32_t v = 1;
        DSD_MEMCPY(&v, c->data, sizeof v);
        if (v < 1) {
            v = 1;
        }
        if (v > 16) {
            v = 16;
        }
        opts->input_volume_multiplier = v;
    }
    return 1;
}

// Public registry
const struct dsd_app_command_reg dsd_app_actions_audio[] = {
    {DSD_APP_CMD_TOGGLE_MUTE, ui_handle_toggle_mute},
    {DSD_APP_CMD_GAIN_DELTA, ui_handle_gain_delta},
    {DSD_APP_CMD_AGAIN_DELTA, ui_handle_again_delta},
    {DSD_APP_CMD_GAIN_SET, ui_handle_gain_set},
    {DSD_APP_CMD_AGAIN_SET, ui_handle_again_set},
    {DSD_APP_CMD_INPUT_WARN_DB_SET, ui_handle_input_warn_db_set},
    {DSD_APP_CMD_INPUT_MONITOR_TOGGLE, ui_handle_input_monitor_toggle},
    {DSD_APP_CMD_COSINE_FILTER_TOGGLE, ui_handle_cosine_filter_toggle},
    {DSD_APP_CMD_INPUT_VOL_CYCLE, ui_handle_input_vol_cycle},
    {DSD_APP_CMD_INPUT_VOL_SET, ui_handle_input_vol_set},
    {0, NULL},
};
